# LINEAGE / ANCESTOR DNA - never delete, only add (Nasif, 2026-10-13)
Keep: EA sources, .set files, reports, winners registry, TEST_LOG, memory notes, history (.hst). This file maps ancestors to descendants and the latest verdict.

Lineage (from hst_out/winners/WINNERS_REGISTRY.txt):
b22_thu (base, 8-period +45,664) -> GEN0_zgate (b25+) -> GEN0_dailyrange (b27+) -> GEN1_ZGate_DailyRange (b31) = CURRENT BEST (backtest only)
b22 -> b32/33 -> CAND_GEN3_B1 (Fd+AHRate) ; b33+ -> CAND_G4_1..4 (ER + daily range / volregime)
b34 -> CAND_MP1/2/6 (MpFrac, MpZ, MpEr + ER) ; b38 -> b41 -> CAND_B41_bbw / bbw_range / bbw_zH1 / ao_chop ; b40 = b41 + UseVolRegimeGate
b37 = b36 + SlopeTable.mqh (slope/hour/weekday/ER logging, off). GEN2 mutations (g2b_*): none beat parent.
Inherited core DNA (kept in every descendant): M15 slope/momentum entry, stochastic position, MMR (Nasif Hossain 2019), UseSellRegime (H1 SMA 1200), UseVirtualBuy, risk sizing. ER = Kaufman.

Verdicts so far (sp5, repaired history, 2026-10-13):
- GEN1 in-sample 8 periods: +75,254 vs +48,429 @8pt, better 7/8 (registry; re-verify on repaired data).
- GEN1 out-of-sample: 2015 -1735, 2018 -3638, 2023 -3998, 2024 -1976 (all lose). Not approved for live.
- Sell regime: protective (2023 regime-off -7416 vs -3998).
- MMR alone: weak/inconsistent gross edge (data/mmr_edge_result.txt). Proof gate in force.
- Red zones: data/RED_ZONES.md.

Self-improvement instructions for clones: read RED_ZONES.md + LINEAGE_DNA.md + loop_state.json first; test one change per candidate; early-abort on 2023; promote only if it beats base on >=3/4 OOS years AND stays positive/beats base on most of the 8 training periods, then spread 5 and 8; log everything in TEST_LOG; never overwrite ancestors, create a new .set instead.
