# Win Logic Name Map — Old vs New (created 2026-10-18)
# Convention: [entry_type]-[trigger]-[session]-[code]+[filters]
#
# Entry types:  MKT=market order  SS=sell stop  LMT=limit
# Triggers:     FL=flat-slope entry  PT=patient trigger  MOM=momentum
#               ATR14=ATR14 offset  07/08/14=entry hour UTC
# Session:      LO=London Open  NY=New York  LN=London→NY boundary
# Filters:      ZG=Z-gate  FB=FracBuy  DR=daily range  WPR=WPR gate
#               AtrTrl=ATR trail  AdpW=adaptive WPR  BE=break-even
#               NG=no gap up  SL###=stop loss pts  CCI###=CCI gate
# Code:         b31/b32/E7/v23/C64b etc = EA/logic version code

## MT4 b31 series (MKT, flat-slope trigger, London-NY session)
# Main entry: market order on flat-slope signal, blocks LO midday (11-14 UTC) and NY close (Fri 19 UTC)

| Old name | New convention name | Notes |
|---|---|---|
| b31_base | MKT-FL-LO-b31 | Base b31, flat slope, no extra filters |
| b31_zr | MKT-FL-LO-b31+ZG1.0 | + Z-gate ZMax=1.0 |
| b31_zr2 | MKT-FL-LO-b31+ZG2 | + Z-gate variant 2 |
| b31_zr3 | MKT-FL-LO-b31+ZG3 | + Z-gate variant 3 |
| b31_zrfb | MKT-FL-LO-b31+ZG+FB | + Z-gate + FracBuy — **WORKING BASE** (115 trades 2020) |
| b31_fb | MKT-FL-LO-b31+FB | + FracBuy only |
| b31_fb_sl150 | MKT-FL-LO-b31+FB+SL150 | + FracBuy + SL=150pts |
| b31_fb_noreg | MKT-FL-LO-b31+FB-NoReg | + FracBuy, regime off |
| b31_fb_w50 | MKT-FL-LO-b31+FB+WPR50 | + FracBuy + WPR≤-50 gate |
| b31_wpr50 | MKT-FL-LO-b31+WPR50 | + WPR≤-50 gate only |
| b31_wpr50_adapt | MKT-FL-LO-b31+WPR50+AdpW | + WPR50 + adaptive WPR after losses |
| b31_cci150 | MKT-FL-LO-b31+CCI150 | + CCI≤150 gate |
| b31_be200 | MKT-FL-LO-b31+BE200 | + break-even at 200pts |
| b31_be250L150 | MKT-FL-LO-b31+BE250L150 | + BE start=250, lock=150 |
| b31_rng080 | MKT-FL-LO-b31+DR0.8 | + daily range max=0.8×ATR |
| b31_rng090 | MKT-FL-LO-b31+DR0.9 | + daily range max=0.9×ATR |
| b31_rng100 | MKT-FL-LO-b31+DR1.0 | + daily range max=1.0×ATR |
| b31_rng110 | MKT-FL-LO-b31+DR1.1 | + daily range max=1.1×ATR |
| WIN_GEN1_ZGate_DailyRange_b31 | MKT-FL-LO-b31+ZG1.0+DR1.0 | **GEN1 WINNER** Z-gate ZMax=1.0 + daily range 1.0 |
| WIN_GEN2_ZGate_DailyRange_b32 | MKT-FL-LO-b32+ZG1.0+DR1.0 | GEN2 candidate |

## Adaptive sets (new 2026-10-18, based on MKT-FL-LO-b31+ZG+FB)

| Old name | New convention name | Notes |
|---|---|---|
| adapt_atrtrail_zrfb | MKT-FL-LO-b31+ZG+FB+AtrTrl | + ATR trailing stop (locks profits) |
| adapt_adaptwpr_zrfb | MKT-FL-LO-b31+ZG+FB+AdpW3 | + adaptive WPR shortens after 3 losses |
| adapt_wpr_trail_zrfb | MKT-FL-LO-b31+ZG+FB+AdpW3+AtrTrl | + both adaptive features |
| adapt_s2s4_zrfb | MKT-FL-LO-b31+ZG+FB+S2S4 | + extra S2+S4 entry signals |
| adapt_lowrev_zrfb | MKT-FL-LO-b31+ZG+FB+LowRev15 | + low-reversal buy at 15-bar swing low |
| adapt_atrbracket_b31 | MKT-FL-LO-b31+AtrBkt1.5 | + ATR-scaled SL/TP brackets (SLmult=1.5) |
| adapt_emacross_b31 | MKT-FL-LO-b31+EMA20x50 | + EMA 20/50 cross entry |
| adapt_fracbuy_b31 | MKT-FL-LO-b31+FB-Reg | + FracBuy with regime filter |

## Cloud coordinator branches (from win_logic_naming.md, session = LO 07:00 UTC)

| Cloud code | New convention name | Notes |
|---|---|---|
| v2.3 baseline | MKT-07-LO-v23 | Cloud baseline market entry |
| v2.3 + RSI14<50 | MKT-07-LO-v23+RSI14u50 | + RSI14 below 50 filter |
| v2.3 + RSI5<60 | MKT-07-LO-v23+RSI5u60 | + RSI5 below 60 filter |
| C64b | MKT-07-LO-C64b | Cloud C64b logic |
| C64b excl Q2 | MKT-07-LO-C64b-XQ2 | + exclude Q2 (Apr-Jun) |
| RSI14+no_gap | MKT-07-LO-v23+RSI14u50+NG | + RSI14 + no overnight gap up |
| v2.4 candidate | MKT-08-LO-v24 | 08:00 trigger variant |
| E7 base | SS-PT-ATR14-LO-E7 | Sell-stop, patient trigger, ATR14 offset, LO |
| E7+NG **(C67 cand.)** | SS-PT-ATR14-LO-E7+NG | + no gap up — **PF=7.54 WR=56.7% n=30** needs OOS |
| E7 + RSI5<60 | SS-PT-ATR14-LO-E7+RSI5u60 | + RSI5 filter |
| E7 + RSI14<50 | SS-PT-ATR14-LO-E7+RSI14u50 | + RSI14 filter |
| E7 + C64b | SS-PT-ATR14-LO-E7+C64b | + C64b logic layer |
| E7 + C64b excl Q2 | SS-PT-ATR14-LO-E7+C64b-XQ2 | + C64b + exclude Q2 |
| E7 + RSI5+NG | SS-PT-ATR14-LO-E7+RSI5u60+NG | + RSI5 + no gap |
| E7 + RSI14+NG | SS-PT-ATR14-LO-E7+RSI14u50+NG | + RSI14 + no gap |

## Notes
- Old filenames kept as-is on disk — this file is the reference map
- Use new convention names in all TEST_LOG entries and new result file tags
- Pattern: more filters = longer name, append +[FILTER] for each addition
- Omit session prefix only when timeframe replaces it (e.g. M1 local tests)
