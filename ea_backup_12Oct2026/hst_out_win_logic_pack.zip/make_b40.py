# make_b40.py - b40 = b41 + WinGates_b40.mqh: H1 volatility-regime gate for GEN4 branch G4-4 (OFF by default).
# Built on b41 (newest full build; b39 exists only as ChaosLab_b39.mqh). Usage: python make_b40.py <b41.mq4> <out_dir>
import sys,os
src=open(sys.argv[1],encoding='latin-1').read(); out=sys.argv[2]
def rep(a,b):
    global src
    assert src.count(a)==1,a[:50]; src=src.replace(a,b)
src=src.replace('1.00-claude_b41"','1.00-claude_b40"')
rep('#include "WinGates_b41.mqh"\n','#include "WinGates_b41.mqh"\n#include "WinGates_b40.mqh"\n')
rep('if(!Gates41()){ return(false); } /*b41*/','if(!Gates41()){ return(false); } /*b41*/ if(!Gates40()){ return(false); } /*b40*/')
inc='''// WinGates_b40.mqh - GEN4 volatility-regime gate (G4-4). OFF by default.
// Sell only in a calm regime: ATR(VrFast)/ATR(VrSlow) on VrTF <= VrMax  (2025-26: H1 14/200 <= 0.99).
extern bool   UseVolRegimeGate=0;
extern int    VrTF=60;
extern int    VrFast=14;
extern int    VrSlow=200;
extern double VrMax=0.99;
bool Gates40(){
   if(UseVolRegimeGate==1){ double s=iATR(Symbol(),VrTF,VrSlow,1); if(s>0 && iATR(Symbol(),VrTF,VrFast,1)/s>VrMax){ return(false); } }
   return(true); }
'''
open(os.path.join(out,'Strong2010b_claude_b40.mq4'),'w',encoding='latin-1').write(src)
open(os.path.join(out,'WinGates_b40.mqh'),'w',encoding='latin-1').write(inc); print('ok')
