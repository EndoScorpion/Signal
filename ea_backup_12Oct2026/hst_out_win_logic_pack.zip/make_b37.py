# make_b37.py - b37 = b36 + SlopeTable.mqh (M1 SMA2/5/10 average-slope keyed table, OFF). Usage: python make_b37.py <b36.mq4> <out_dir>
import sys,os
src=open(sys.argv[1],encoding='latin-1').read(); out=sys.argv[2]
def rep(a,b):
    global src
    assert src.count(a)==1,a[:50]; src=src.replace(a,b)
src=src.replace('1.00-claude_b36"','1.00-claude_b37"')
rep('#include "WinGates_b36.mqh"\n','#include "WinGates_b36.mqh"\n#include "SlopeTable.mqh"\n')
rep('void OnTick(){ ','void OnTick(){ if(UseSlopeTable==1){ SlopeTableTick(); } /*b37*/ ')
rep('void OnDeinit(const int reason){ ','void OnDeinit(const int reason){ if(UseSlopeTable==1){ SlopeTableDump(); } /*b37*/ ')
inc=r'''// SlopeTable.mqh - b37 keyed "hashtable" of average M1 SMA slopes. OFF by default. Logging only, never trades.
// Columns = SMA periods (STPer1..3, default 2,5,10). Slope = SMA(bar1) - SMA(bar2) in points, on closed M1 bars.
// Row key (STKeyMode): 0 = hour of day (24 rows), 1 = weekday (7), 2 = chaos ER(100) on M15 regime (5 buckets of 0.05). Last row = ALL.
extern bool   UseSlopeTable=0;
extern int    STKeyMode=0;
extern int    STPer1=2;
extern int    STPer2=5;
extern int    STPer3=10;
extern bool   STDumpCsv=1;      // write MQL4\Files\slope_table.csv on deinit
double stSum[25][3]; int stCnt[25][3]; datetime stLastBar=0;
int StRows(){ if(STKeyMode==1){ return(7); } if(STKeyMode==2){ return(5); } return(24); }
int StKey(){ datetime t=iTime(Symbol(),PERIOD_M1,1);
   if(STKeyMode==1){ return(TimeDayOfWeek(t)); }
   if(STKeyMode==2){ double s=0; for(int i=1;i<=100;i++){ s+=MathAbs(iClose(Symbol(),PERIOD_M15,i)-iClose(Symbol(),PERIOD_M15,i+1)); }
      double er=(s>0)?MathAbs(iClose(Symbol(),PERIOD_M15,1)-iClose(Symbol(),PERIOD_M15,101))/s:0; return((int)MathMin(4,MathFloor(er/0.05))); }
   return(TimeHour(t)); }
void SlopeTableTick(){ datetime b=iTime(Symbol(),PERIOD_M1,0); if(b==stLastBar){ return; } stLastBar=b;
   int k=StKey(), all=StRows(); int per[3]; per[0]=STPer1; per[1]=STPer2; per[2]=STPer3;
   for(int c=0;c<3;c++){ double sl=(iMA(Symbol(),PERIOD_M1,per[c],0,MODE_SMA,PRICE_CLOSE,1)-iMA(Symbol(),PERIOD_M1,per[c],0,MODE_SMA,PRICE_CLOSE,2))/Point;
      stSum[k][c]+=sl; stCnt[k][c]++; stSum[all][c]+=sl; stCnt[all][c]++; } }
double SlopeAvg(int row,int col){ return(stCnt[row][col]>0 ? stSum[row][col]/stCnt[row][col] : 0); }   // lookup: SlopeAvg(StKey(),0..2)
void SlopeTableDump(){ int rows=StRows(); string hd=StringFormat("key,SMA%d,SMA%d,SMA%d,n",STPer1,STPer2,STPer3); Print("b37 slope table (points/M1 bar) ",hd);
   int h=-1; if(STDumpCsv){ h=FileOpen("slope_table.csv",FILE_WRITE|FILE_TXT|FILE_ANSI); if(h!=INVALID_HANDLE){ FileWriteString(h,hd+"\n"); } }
   for(int r=0;r<=rows;r++){ string key=(r==rows)?"ALL":IntegerToString(r);
      string ln=StringFormat("%s,%.3f,%.3f,%.3f,%d",key,SlopeAvg(r,0),SlopeAvg(r,1),SlopeAvg(r,2),stCnt[r][0]); Print(ln); if(h!=INVALID_HANDLE){ FileWriteString(h,ln+"\n"); } }
   if(h!=INVALID_HANDLE){ FileClose(h); } }
'''
rep('if(!Gates36()){ return(false); } /*b36*/','if(!Gates36()){ return(false); } /*b36*/ if(!M1SlopeOK()){ return(false); } /*b37*/')
inc=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'SlopeTable.mqh'),encoding='latin-1').read()
open(os.path.join(out,'Strong2010b_claude_b37.mq4'),'w',encoding='latin-1').write(src)
print('ok')
