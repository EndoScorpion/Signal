import sys
src=open(sys.argv[1],encoding='latin-1').read()
def rep(a,b,n=1):
    global src
    assert src.count(a)==n, 'anchor count != %d: %s'%(n,a[:60])
    src=src.replace(a,b)
rep('extern double AtrTrailMult=1.0;\n','''extern double AtrTrailMult=1.0;
// b25 (ideas from 2026-10-11 material). All gates apply to NEW sell orders only; 0 = off.
// Session allow-window in server minutes of day (SellWinFrom..SellWinTo, e.g. 540..990 = 09:00-16:30)
extern int    SellWinFrom=0;
extern int    SellWinTo=0;
// Volume rising on completed bars: Volume[1] > Volume[2] on GateTF
extern bool   UseSellVolRise=0;
// Calculus momentum (backward, closed bars on GateTF): velocity (c1-c3)/2 < -MomMinPts points
extern bool   UseSellMomGate=0;
extern double MomMinPts=0;
// Least-squares slope of the last SlopeBars closed bars on GateTF must be below -SlopeMinPts points/bar
extern bool   UseSellSlopeGate=0;
extern int    SlopeBars=20;
extern double SlopeMinPts=0;
// Price z-score gate: z of close[1] vs last ZBars closes on GateTF must be below SellZMax (e.g. 0 = only sell below the mean)
extern bool   UseSellZGate=0;
extern int    ZBars=20;
extern double SellZMax=0;
extern int    GateTF=15;
// ATR brackets for sell stops/ladder: SL = ATR*AtrSLMult + spread, TP = SL*AtrRR (replaces SellStopSL/TP)
extern bool   UseAtrBrackets=0;
extern int    BrkAtrTF=60;
extern double AtrSLMult=1.5;
extern double AtrRR=1.0;
''')
rep('/*b24*/ if(UseSellRegime!=1){ return(true); }','/*b24*/ if(!SellGates25()){ return(false); } /*b25*/ if(UseSellRegime!=1){ return(true); }')
rep('lvl+SellStopSL*p','lvl+SSLpts()*p',2)
rep('lvl-SellStopTP*p','lvl-STPpts()*p',2)
src=src.rstrip()+'''

//---- b25 sell gates and ATR brackets (closed bars only, no look-ahead)
bool SellGates25(){ int tf=GateTF;
   if(SellWinTo>SellWinFrom){ int m=TimeHour(TimeCurrent())*60+TimeMinute(TimeCurrent()); if(m<SellWinFrom || m>=SellWinTo){ return(false); } }
   if(UseSellVolRise==1 && iVolume(Symbol(),tf,1)<=iVolume(Symbol(),tf,2)){ return(false); }
   if(UseSellMomGate==1 && (iClose(Symbol(),tf,1)-iClose(Symbol(),tf,3))/2.0 >= -MomMinPts*Point){ return(false); }
   if(UseSellSlopeGate==1){ int n=MathMax(3,SlopeBars); double sx=0,sy=0,sxy=0,sxx=0; for(int i=1;i<=n;i++){ double x=-i, y=iClose(Symbol(),tf,i); sx+=x; sy+=y; sxy+=x*y; sxx+=x*x; }
      double den=n*sxx-sx*sx; if(den==0 || (n*sxy-sx*sy)/den >= -SlopeMinPts*Point){ return(false); } }
   if(UseSellZGate==1){ int n=MathMax(3,ZBars); double m=0,v=0; for(int i=1;i<=n;i++){ m+=iClose(Symbol(),tf,i); } m/=n; for(int i=1;i<=n;i++){ v+=MathPow(iClose(Symbol(),tf,i)-m,2); }
      double sd=MathSqrt(v/n); if(sd<=0 || (iClose(Symbol(),tf,1)-m)/sd >= SellZMax){ return(false); } }
   return(true); }
int SSLpts(){ if(UseAtrBrackets!=1){ return(SellStopSL); } double a=iATR(Symbol(),BrkAtrTF,14,1); if(a<=0){ return(SellStopSL); } return((int)MathMax(MarketInfo(Symbol(),MODE_STOPLEVEL)+10, MathRound(a*AtrSLMult/Point+MarketInfo(Symbol(),MODE_SPREAD)))); }
int STPpts(){ if(UseAtrBrackets!=1){ return(SellStopTP); } return((int)MathMax(MarketInfo(Symbol(),MODE_STOPLEVEL)+10, MathRound(SSLpts()*AtrRR))); }
'''
src=src.replace('#property version   "1.00-claude_b24"','#property version   "1.00-claude_b25"')
open(sys.argv[2],'w',encoding='latin-1').write(src)
print('written',sys.argv[2])
