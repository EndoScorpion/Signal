# run_guarded.ps1 - serial MT4 tests with a RAM guard (Nasif 2026-10-12). Jobs: "Expert|set|period[|spread]" items.
# Before each test: free RAM >= 1024 MB (waits up to 20 min, else stops). During a test: if free RAM < 400 MB, kill the tester,
# re-create hst_out\MT4_PAUSE and stop. Stops at once if MT4_PAUSE reappears (anyone can pause). Logs to guarded.log.
param([string[]]$Jobs)
$H='C:\Users\endos\Desktop\hst_out'; $Log="$H\guarded.log"
$P=@{ '2013'=@('2013.01.01','2013.12.31'); '2014'=@('2014.01.01','2014.12.31'); '2015'=@('2015.01.01','2015.12.31'); '2016'=@('2016.01.01','2016.12.31'); '2018'=@('2018.01.01','2018.12.31') }
function Say($m){ Add-Content $Log ("{0:HH:mm:ss} {1}" -f (Get-Date),$m) }
function FreeMB { [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1024) }
function Pause($why){ Set-Content "$H\MT4_PAUSE" "MT4 PAUSED automatically $(Get-Date -Format 'yyyy-MM-dd HH:mm'): $why. Delete to resume." -Encoding ASCII; Say "PAUSED: $why"; Add-Content $Log 'GUARDED STOP'; exit 7 }
foreach($j in ($Jobs -join ',' -split ',')){
  $e,$set,$per,$sp = $j -split '\|'; if(-not $sp){ $sp=2 }; $tag = if($sp -eq 2){ "${set}_$per" } else { "${set}_s${sp}_$per" }
  if(Test-Path "$H\$tag.htm"){ Say "SKIP $tag"; continue }
  if(Test-Path "$H\MT4_PAUSE"){ Say "STOP: MT4_PAUSE present"; Add-Content $Log 'GUARDED STOP'; exit 6 }
  $t=Get-Date; while((FreeMB) -lt 1024){ if(((Get-Date)-$t).TotalMinutes -gt 20){ Pause "free RAM stayed under 1.0 GB for 20 min ($(FreeMB) MB)" }; Start-Sleep 30 }
  Say "START $tag (free RAM $(FreeMB) MB)"
  $p = Start-Process powershell -WindowStyle Hidden -PassThru -ArgumentList "-ExecutionPolicy Bypass -File $H\run_tester.ps1 -Expert $e -SetFile $set.set -Spread $sp -From $($P[$per][0]) -To $($P[$per][1]) -Tag $tag"
  while(-not $p.HasExited){ $f=FreeMB; if($f -lt 400){ Get-Process terminal -EA 0 | ? { $_.Path -like 'C:\Users\endos\Desktop\mt4_tester*' } | Stop-Process -Force; Stop-Process -Id $p.Id -Force -EA 0; Pause "free RAM fell to $f MB during $tag" }; Start-Sleep 5 }
  Say ("END {0} -> {1}" -f $tag, $(if(Test-Path "$H\$tag.htm"){'report ok'}else{'NO REPORT'}))
}
Add-Content $Log 'GUARDED DONE'
