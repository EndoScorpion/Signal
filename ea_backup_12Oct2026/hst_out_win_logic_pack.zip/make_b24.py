﻿# make_b24.py - builds Strong2010b_claude_b24.mq4 from the fixed b23 source.
import sys
src=open(sys.argv[1],encoding='latin-1').read()
def rep(a,b):
    global src
    assert src.count(a)==1, 'anchor not unique/missing: '+a[:60]
    src=src.replace(a,b)
n1=src.count('OrderSend('); n2=src.count('OrderModify(')
src=src.replace('OrderSend(','SendX(').replace('OrderModify(','ModifyX(')
print('wrapped',n1,'OrderSend and',n2,'OrderModify calls')
rep('extern double SellCCIMax=999;\n','''extern double SellCCIMax=999;
// b24: ECN two-step market orders: open with SL/TP 0, check the ticket, then attach SL/TP with ModifyX (0 = send SL/TP with the order, as b23)
extern bool   UseECNSend=0;
// b24: retries for requote/price-changed/busy errors (135,136,137,138,146) on every SendX/ModifyX
extern int    ExecRetries=3;
extern int    ExecRetryMs=200;
// b24: EMA trend gate for sells: new sell orders only when EMA EmaFast < EMA EmaSlow on EmaTF (closed bar). 0 = off
extern bool   UseSellEmaGate=0;
extern int    EmaFast=9;
extern int    EmaSlow=21;
extern int    EmaTF=1;
// b24: ATR trailing stop for ladder/sell-stop sells ("7"): once profit >= AtrTrailStart*ATR, SL = Ask + AtrTrailMult*ATR (only tightens). 0 = off
extern bool   UseAtrTrail=0;
extern int    AtrTF=15;
extern int    AtrPeriod=14;
extern double AtrTrailStart=1.0;
extern double AtrTrailMult=1.0;
// b24: extra sell gates from the 2026-10-11 material (all 0 = off)
// session window in server minutes (Hour*60+Minute): sells only inside [SessStartMin, SessEndMin]
extern bool   UseSessWindow=0;
extern int    SessStartMin=540;
extern int    SessEndMin=990;
// calculus gate on closed CalcTF bars, backward differences: 1 = velocity<0, 2 = acceleration<0, 3 = both
extern int    UseCalcGate=0;
extern int    CalcTF=15;
// multivariate z-score gate: 0.7*z(close)+0.3*z(volume) over ZPeriod closed ZTF bars must be < ZMax
extern bool   UseZGate=0;
extern int    ZTF=15;
extern int    ZPeriod=20;
extern double ZMax=1.0;
// volume velocity gate: last closed VolTF bar tick volume > the one before
extern bool   UseVolGate=0;
extern int    VolTF=15;
''')
rep('if(UseSellRegime!=1){ return(true); }','if(UseSellEmaGate==1 && iMA(Symbol(),EmaTF,EmaFast,0,MODE_EMA,PRICE_CLOSE,1)>=iMA(Symbol(),EmaTF,EmaSlow,0,MODE_EMA,PRICE_CLOSE,1)){ return(false); } if(!SellExtraOK()){ return(false); } /*b24*/ if(UseSellRegime!=1){ return(true); }')
rep('void OnTick(){ ','void OnTick(){ if(UseAtrTrail==1){ AtrTrailMng(); } /*b24*/ ')
rep('int OnInit(){ Print("init1");','int OnInit(){ Print("init1"); if(Digits==3 || Digits==5){ Print("b24: 5-digit pricing, 1 pip = 10 points; all point inputs are 5-digit points"); } else { slip=(int)MathMax(1,slip/10); Print("b24 WARNING: 4-digit pricing, slippage scaled to ",slip," but point inputs assume 5-digit"); }')
src=src.rstrip()+'''

//---- b24 execution wrappers: fresh prices, NormalizeDouble, error codes to the journal, retries on transient errors
bool ExecTransient(int e){ return(e==135 || e==136 || e==137 || e==138 || e==146); } // 128 timeout not retried: the order may exist
bool ModifyX(int tk,double pr,double sl,double tp,datetime ex,color c=clrNONE){
   for(int a=1;a<=MathMax(1,ExecRetries);a++){ if(!OrderSelect(tk,SELECT_BY_TICKET)){ Print("ModifyX #",tk," select err ",GetLastError()); return(false); } RefreshRates();
      pr=NormalizeDouble(pr,Digits); sl=NormalizeDouble(sl,Digits); tp=NormalizeDouble(tp,Digits); ResetLastError();
      if(OrderModify(tk,pr,sl,tp,ex,c)){ return(true); } int e=GetLastError(); Print("ModifyX #",tk," attempt ",a," err ",e);
      if(!ExecTransient(e)){ return(false); } Sleep(ExecRetryMs); } return(false); }
int SendX(string sy,int ty,double lt,double pr,int sp,double sl,double tp,string cm=NULL,int mg=0,datetime ex=0,color c=clrNONE){
   bool naked=(UseECNSend==1 && ty<=OP_SELL);
   for(int a=1;a<=MathMax(1,ExecRetries);a++){ RefreshRates(); if(ty==OP_BUY){ pr=Ask; } if(ty==OP_SELL){ pr=Bid; } // fresh market price on every attempt
      pr=NormalizeDouble(pr,Digits); sl=NormalizeDouble(sl,Digits); tp=NormalizeDouble(tp,Digits); ResetLastError();
      int t=OrderSend(sy,ty,lt,pr,sp,naked?0:sl,naked?0:tp,cm,mg,ex,c);
      if(t>0){ if(naked && (sl>0 || tp>0)){ int prev=OrderTicket(); bool ok=ModifyX(t,pr,sl,tp,0,c); // keep the caller's selected order (SendX is called inside OrderSelect loops)
            if(!ok){ Print("SendX #",t," SL/TP attach failed; closing naked position"); if(OrderSelect(t,SELECT_BY_TICKET)){ RefreshRates(); if(!OrderClose(t,OrderLots(),NormalizeDouble(ty==OP_BUY?Bid:Ask,Digits),sp,clrWhite)){ Print("SendX close err ",GetLastError()); } } }
            if(prev>0 && prev!=t){ if(!OrderSelect(prev,SELECT_BY_TICKET)){ Print("SendX reselect err ",GetLastError()); } }
            if(!ok){ return(-1); } } return(t); }
      int e=GetLastError(); Print("SendX type ",ty," attempt ",a," err ",e); if(!ExecTransient(e)){ return(-1); } Sleep(ExecRetryMs); } return(-1); }
//---- b24 extra sell gates
bool SellExtraOK(){
   if(UseSessWindow==1){ int m=TimeHour(TimeCurrent())*60+TimeMinute(TimeCurrent()); if(m<SessStartMin || m>SessEndMin){ return(false); } }
   if(UseCalcGate>0){ double c1=iClose(Symbol(),CalcTF,1), c2=iClose(Symbol(),CalcTF,2), c3=iClose(Symbol(),CalcTF,3); if(c1<=0 || c2<=0 || c3<=0){ return(false); }
      double vel=c1-c2, acc=c1-2*c2+c3; if((UseCalcGate==1 || UseCalcGate==3) && vel>=0){ return(false); } if((UseCalcGate==2 || UseCalcGate==3) && acc>=0){ return(false); } }
   if(UseZGate==1){ int n=MathMax(2,ZPeriod); double sp=0, sv=0, qp=0, qv=0; for(int k=1;k<=n;k++){ double c=iClose(Symbol(),ZTF,k), v=(double)iVolume(Symbol(),ZTF,k); sp+=c; sv+=v; qp+=c*c; qv+=v*v; }
      double mp=sp/n, mv=sv/n, dp=MathSqrt(MathMax(0,qp/n-mp*mp)), dv=MathSqrt(MathMax(0,qv/n-mv*mv)); if(dp<=0 || dv<=0){ return(false); }
      double z=0.7*(iClose(Symbol(),ZTF,1)-mp)/dp+0.3*((double)iVolume(Symbol(),ZTF,1)-mv)/dv; if(z>=ZMax){ return(false); } }
   if(UseVolGate==1 && iVolume(Symbol(),VolTF,1)<=iVolume(Symbol(),VolTF,2)){ return(false); }
   return(true); }
//---- b24 ATR trailing stop for "7" sells
void AtrTrailMng(){ double atr=iATR(Symbol(),AtrTF,AtrPeriod,1); if(atr<=0){ return; } RefreshRates(); double stp=MarketInfo(Symbol(),MODE_STOPLEVEL)*Point;
   for(int i=OrdersTotal()-1;i>=0;i--){ if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)){ continue; } if(OrderMagicNumber()!=magic || OrderSymbol()!=Symbol() || OrderType()!=OP_SELL || StringSubstr(OrderComment(),0,1)!="7"){ continue; }
      if(OrderOpenPrice()-Ask<AtrTrailStart*atr){ continue; } double nsl=NormalizeDouble(Ask+AtrTrailMult*atr,Digits);
      if(nsl-Ask<=stp || (OrderStopLoss()>0 && nsl>=OrderStopLoss()-0.5*Point)){ continue; }
      if(ModifyX(OrderTicket(),OrderOpenPrice(),nsl,OrderTakeProfit(),0,clrOrange)){ Print("ATR TRAIL #",OrderTicket()," SL ",DoubleToStr(nsl,Digits)); } } }
'''
src=src.replace('#property version   "1.00-claude_b23"','#property version   "1.00-claude_b24"')
open(sys.argv[2],'w',encoding='latin-1').write(src)
print('written',sys.argv[2])
