"""fib_tables.py - RLOG3 (fib distance / confluence) vs trade net, from the b15 runs of 2026-10-10.
RLOG3 lines live in the cumulative tester log; runs are split where ticket #1 restarts and mapped to tags in run order."""
import re, glob, os, html, collections
OUT = r'C:\Users\endos\Desktop\hst_out'
LOGS = r'C:\Users\endos\Desktop\mt4_tester\tester\logs'
ORDER = ['b15_T0_2019'] + ['b15_%s_%d' % (k, y) for k in ('T1', 'T2', 'T3', 'T4') for y in (2017, 2019, 2020, 2021)]
R3 = re.compile(r'RLOG3 #(\d+) fibS (\d+) fibL (\d+) conf (\d)')
runs, cur = [], None
for lp in sorted(glob.glob(os.path.join(LOGS, '*.log')), key=os.path.getmtime):
    for raw in open(lp, 'rb'):
        if b'RLOG3' not in raw: continue
        m = R3.search(raw.decode('latin-1'))
        if not m: continue
        if m.group(1) == '1' or cur is None:
            cur = {}; runs.append(cur)
        cur[m.group(1)] = (int(m.group(2)), int(m.group(3)), int(m.group(4)))
runs = runs[-len(ORDER):]
print('runs found', len(runs))
def deals(tag):
    h = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); o = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', h):
        c = [html.unescape(re.sub('<[^>]+>', '', x)).strip() for x in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(c) < 9 or not c[0].isdigit(): continue
        d = o.setdefault(c[3], {'side': None, 'net': None, 'lots': 0.01})
        if re.match(r'^(buy|sell)', c[2]) and d['side'] is None: d['side'] = c[2][:4].strip()
        if re.search(r't/p|s/l|close', c[2]): d['net'] = float(c[8]) - 9 * float(c[4])
    return o
T = []
for tag, rl in zip(ORDER, runs):
    if not (tag.startswith('b15_T0') or tag.startswith('b15_T2')): continue  # base-like runs only
    od = deals(tag)
    for tk, (fs, fl, cf) in rl.items():
        d = od.get(tk)
        if d and d['net'] is not None: T.append((tag[-4:], d['side'], fs, fl, cf, d['net']))
L = ['FIB tables (b15 T0 2019 + T2 2017-2021 runs, net after 0.09/0.01 lot). n=%d' % len(T)]
def bucket(name, f, edges):
    for side in ('buy', 'sell'):
        g = collections.defaultdict(list)
        for t in T:
            if t[1] != side: continue
            v = f(t); k = sum(v > e for e in edges); g[k].append(t)
        for k in sorted(g):
            G = g[k]
            if len(G) < 30: continue
            lab = ('<=%s' % edges[0]) if k == 0 else (('>%s' % edges[-1]) if k == len(edges) else '%s-%s' % (edges[k-1], edges[k]))
            ys = []
            for y in ('2017', '2019', '2020', '2021'):
                Y = [t[5] for t in G if t[0] == y]
                if len(Y) >= 10: ys.append('%s:%+.2f(%d)' % (y[2:], sum(Y)/len(Y), len(Y)))
            n = len(G); L.append('%-4s %-6s %-9s n=%5d win=%5.1f%% avg=%+.3f | %s' % (side, name, lab, n, 100.0*sum(x[5] > 0 for x in G)/n, sum(x[5] for x in G)/n, ' '.join(ys)))
bucket('fibS', lambda t: t[2], [10, 30, 60, 120])
bucket('fibL', lambda t: t[3], [20, 60, 150, 300])
bucket('conf', lambda t: t[4], [0])
open(os.path.join(OUT, 'FIB_TABLES.txt'), 'w').write('\n'.join(L))
print('\n'.join(L))
