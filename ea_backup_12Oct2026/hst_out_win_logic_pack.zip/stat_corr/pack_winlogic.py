"""pack_winlogic.py - copy-only: bundle hst_out win logic (EA sources, winner sets, scripts, results, logs of decisions) into one zip
and a plain folder copy for other sessions. Originals untouched. Verifies the zip."""
import os, glob, zipfile, shutil, hashlib
H = r'C:\Users\endos\Desktop\hst_out'; T = r'C:\Users\endos\Desktop\mt4_tester\tester'
OUT = os.path.join(H, 'WIN_LOGIC_PACK_12Oct2026'); os.makedirs(OUT, exist_ok=True)
files = []
for pat in ['Strong2010b_claude_b2[2-9].mq4*', 'Strong2010b_claude_b3*.mq4*', 'Strong2010b_claude_b22.mq4*', 'WinGates_*.mqh*', 'BranchSwitch.mqh*', 'SlopeTable.mqh*',
            'make_b*.py*', 'run_*.ps1', 'sync_status.ps1', 'compile_b2*.log', 'compile_b3*.log',
            'B2*_RESULTS.txt', 'B3*_RESULTS.txt', 'B28_B31_RESULTS.txt', 'WIN_LOGIC_LOG.txt', 'WIN_LOGIC_SUMMARY.txt', 'B22_THU.txt', 'B22_CHECKS.txt', 'B23_B24_RESUME.txt',
            'GEN*.txt', 'STATUS_ALL.txt', 'EMA_ATR_Scalper_M1.mq4', 'RUN_TESTER_README.txt', 'run_tester.ps1']:
    files += glob.glob(os.path.join(H, pat))
files += glob.glob(os.path.join(H, 'winners', '*')) + glob.glob(os.path.join(H, 'stat_corr', '*.py')) + glob.glob(os.path.join(H, 'gemini', '*.mq4'))
for pat in ['b22_thu.set', 'b31_zr.set', 'b31_base.set', 'b31_rng100.set', 'b24_z1.set', 'b22_off.set']:
    files += glob.glob(os.path.join(T, pat))
files = sorted(set(f for f in files if os.path.isfile(f)))
zp = os.path.join(OUT, 'win_logic_pack.zip')
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in files:
        arc = os.path.relpath(f, H) if f.startswith(H) else os.path.join('mt4_tester_sets', os.path.basename(f))
        z.write(f, arc)
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    n = len(z.namelist())
with open(os.path.join(OUT, 'README.txt'), 'w') as r:
    r.write('WIN LOGIC PACK (Claude hst_out session, 2026-10-12). Copies only; originals remain in hst_out.\n'
            'CURRENT BEST (PROVEN in MT4 backtests, NOT approved for live): b22_thu + Z-gate(ZMax 1.0, 20 M15 bars) + Daily range filter (1.0 x D1 ATR5).\n'
            'Set file: winners\\WIN_GEN1_ZGate_DailyRange_b31.set (EA Strong2010b_claude_b31). 8-period +75,254 vs b22 +48,429 at 8 pts/trade; holds at spread 5 and 8.\n'
            'Base b22_thu = UseSellBlock 28/2 + SessBlock 11-14 + DayBlock 4 (b22_thu.set). Rejected ideas: see TEST_LOG.txt / WIN_LOGIC_LOG.txt.\n'
            'Pending unseen-year check (2013-2016, 2018): needs MT4_PAUSE lifted by Nasif.\n%d files in win_logic_pack.zip\n' % n)
dst = r'C:\Users\endos\Signal\ea_backup_12Oct2026'
if os.path.isdir(dst):
    shutil.copy2(zp, os.path.join(dst, 'hst_out_win_logic_pack.zip')); shutil.copy2(os.path.join(OUT, 'README.txt'), os.path.join(dst, 'hst_out_WIN_LOGIC_README.txt'))
print('packed', n, 'files,', round(os.path.getsize(zp) / 1e6, 1), 'MB ->', zp)
