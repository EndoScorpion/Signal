E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b17.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('extern int    LadderSL=300;', 'extern int    LadderSL=300;' + NL +
    '// b18: seconds to wait after the signal before the ladder is placed (0 = at once, as b17)' + NL +
    'extern int    LadderDelaySec=0;' + NL + 'datetime ladderDue=0; bool ladderFire=false;')
rep('void PlaceLadder(){ if(LadderMode!=0 || LadderRegime!=0){ PlaceLadder2(); return; }',
    'void PlaceLadder(){ if(LadderDelaySec>0 && !ladderFire){ ladderDue=TimeCurrent()+LadderDelaySec; return; } ladderFire=false; //b18' + NL +
    '   if(LadderMode!=0 || LadderRegime!=0){ PlaceLadder2(); return; }')
rep('void OnTick(){ if(UseChartDraw==1){ ChartDraw(); }',
    'void OnTick(){ if(ladderDue>0 && TimeCurrent()>=ladderDue){ ladderDue=0; ladderFire=true; PlaceLadder(); } if(UseChartDraw==1){ ChartDraw(); }')
open(E + r'\Strong2010b_claude_b18.mq4', 'wb').write(t.encode('cp1252')); print('b18 ok')
