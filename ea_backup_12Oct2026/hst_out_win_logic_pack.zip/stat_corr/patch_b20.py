E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b19.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('datetime nbLastM15=0, nbLastH1=0;', 'datetime nbLastM15=0, nbLastH1=0;' + NL + NL.join([
 '// b20: sell block: no new sell orders (stops, ladder, hedges) when M15 ADX14 is above BlockADX or the server hour is below BlockHour',
 'extern bool   UseSellBlock=0;', 'extern int    BlockADX=28;', 'extern int    BlockHour=2;',
 '// b20: counter-hedge: when an open sell is CHTrigger pts against, open one opposite buy (mode 0 market, 1 buy stop 20 pts above) with CHTP/CHSL',
 'extern bool   UseCounterHedge=0;', 'extern int    CHTrigger=250;', 'extern int    CHMode=0;', 'extern int    CHTP=150;', 'extern int    CHSL=150;',
 'int chDone[256]; int chN=0;']))
rep('bool SellRegimeOK(){ if(!QuietOK()){ return(false); }',
    'bool SellRegimeOK(){ if(!QuietOK()){ return(false); } if(UseSellBlock==1 && (iADX(Symbol(),PERIOD_M15,14,PRICE_CLOSE,MODE_MAIN,1)>BlockADX || TimeHour(TimeCurrent())<BlockHour)){ return(false); }')
helper = NL.join([
 '//---- b20 counter-hedge ("H" orders: own TP/SL, excluded from OrderMng buy handling)',
 'bool CHHas(int tk){ for(int i=0;i<chN;i++){ if(chDone[i]==tk){ return(true); } } return(false); }',
 'void CHMng(){ RefreshRates(); for(int i=OrdersTotal()-1;i>=0;i--){ if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)){ continue; } if(OrderMagicNumber()!=magic || OrderSymbol()!=Symbol() || OrderType()!=OP_SELL){ continue; }',
 '   int tk=OrderTicket(); if(CHHas(tk) || Ask<OrderOpenPrice()+CHTrigger*p){ continue; } double lt=OrderLots(); if(!Guard(lt,CHSL)){ continue; }',
 '   if(chN>=256){ chN=0; } chDone[chN]=tk; chN++; int t=-1;',
 '   if(CHMode==0){ t=OrderSend(Symbol(),OP_BUY,lt,Ask,slip,NormalizeDouble(Ask-CHSL*p,Digits),NormalizeDouble(Ask+CHTP*p,Digits),"H",magic,0,clrAqua); }',
 '   else { double lv=NormalizeDouble(Ask+20*p,Digits); t=OrderSend(Symbol(),OP_BUYSTOP,lt,lv,slip,NormalizeDouble(lv-CHSL*p,Digits),NormalizeDouble(lv+CHTP*p,Digits),"H",magic,TimeCurrent()+7200,clrAqua); }',
 '   if(t>0){ Print("CHEDGE #",t," for sell #",tk); } else { Print("CHEDGE err ",GetLastError()); } } }', ''])
i = t.find('//---- b19 new buys'); t = t[:i] + helper + t[i:]
rep('void OnTick(){ if(UseLowRevBuy==1', 'void OnTick(){ if(UseCounterHedge==1){ CHMng(); } if(UseLowRevBuy==1')
rep('|| StringSubstr(OrderComment(),0,1)=="X"){ continue; }', '|| StringSubstr(OrderComment(),0,1)=="X" || StringSubstr(OrderComment(),0,1)=="H"){ continue; }')
rep('&& StringSubstr(OrderComment(),0,1)!="X"){ n++; }', '&& StringSubstr(OrderComment(),0,1)!="X" && StringSubstr(OrderComment(),0,1)!="H"){ n++; }')
open(E + r'\Strong2010b_claude_b20.mq4', 'wb').write(t.encode('cp1252')); print('b20 ok')
