﻿"""mksets24.py - b24 .set files with EVERY extern listed (tester keeps stale inputs otherwise).
base = b22_thu.set (= b23 base) + all b23/b24 flags off; each variant overrides a few keys."""
import re
SRC = r'C:\Users\endos\Desktop\hst_out\Strong2010b_claude_b24.mq4'
T = r'C:\Users\endos\Desktop\mt4_tester\tester'
src = open(SRC, encoding='latin-1').read()
defaults, order = {}, []
for m in re.finditer(r'^\s*extern\s+(\w+)\s+([^;]+);', src, re.M):
    for part in m.group(2).split(','):
        k, v = [x.strip() for x in part.split('=', 1)]
        defaults[k] = {'true': '1', 'false': '0'}.get(v.strip('"'), v.strip('"')); order.append(k)

def load(name):
    d = {}
    for l in open(T + '\\' + name, encoding='latin-1'):
        if '=' in l: k, v = l.strip().split('=', 1); d[k] = v
    return d

BASE = dict(defaults); BASE.update(load('b22_thu.set'))
BASE.update({'SellBEStart': '0', 'SellBELock': '10', 'SellCCIMax': '999'})   # b23 flags off; b24 flags are off by default

V = {
 'b24_base': {},
 'b24_ecn': {'UseECNSend': '1'},
 'b24_ema1': {'UseSellEmaGate': '1', 'EmaTF': '1'},
 'b24_ema5': {'UseSellEmaGate': '1', 'EmaTF': '5'},
 'b24_ema15': {'UseSellEmaGate': '1', 'EmaTF': '15'},
 'b24_atr10': {'UseAtrTrail': '1', 'AtrTrailStart': '1.0', 'AtrTrailMult': '1.0'},
 'b24_atr15': {'UseAtrTrail': '1', 'AtrTrailStart': '1.5', 'AtrTrailMult': '1.0'},
 'b24_atr20': {'UseAtrTrail': '1', 'AtrTrailStart': '2.0', 'AtrTrailMult': '1.5'},
 'b24_sess': {'UseSessWindow': '1', 'SessStartMin': '540', 'SessEndMin': '990'},      # 09:00-16:30
 'b24_sessw': {'UseSessWindow': '1', 'SessStartMin': '480', 'SessEndMin': '1080'},    # 08:00-18:00
 'b24_calcv': {'UseCalcGate': '1', 'CalcTF': '15'},
 'b24_calca': {'UseCalcGate': '2', 'CalcTF': '15'},
 'b24_calcva': {'UseCalcGate': '3', 'CalcTF': '15'},
 'b24_calcv5': {'UseCalcGate': '1', 'CalcTF': '5'},
 'b24_z1': {'UseZGate': '1', 'ZMax': '1.0'},
 'b24_z0': {'UseZGate': '1', 'ZMax': '0'},
 'b24_z075': {'UseZGate': '1', 'ZMax': '0.75'},
 'b24_z15': {'UseZGate': '1', 'ZMax': '1.5'},
 'b24_vol': {'UseVolGate': '1', 'VolTF': '15'},
}
for n, o in V.items():
    d = dict(BASE); d.update(o)
    bad = [k for k in d if k not in defaults]
    if bad: print('WARN keys not in EA', n, bad)
    with open(T + '\\' + n + '.set', 'w', newline='\r\n') as f:
        for k in order: f.write('%s=%s\n' % (k, d[k]))
print(len(V), 'sets,', len(order), 'inputs each')
