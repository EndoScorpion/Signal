E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b20.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('extern int    BlockHour=2;', 'extern int    BlockHour=2;' + NL +
    '// b21: session block: no new sell orders from SessBlockFrom up to (not incl.) SessBlockTo server hour (0/0 = off)' + NL +
    'extern int    SessBlockFrom=0;' + NL + 'extern int    SessBlockTo=0;')
rep('TimeHour(TimeCurrent())<BlockHour)){ return(false); }',
    'TimeHour(TimeCurrent())<BlockHour)){ return(false); } if(SessBlockTo>SessBlockFrom && TimeHour(TimeCurrent())>=SessBlockFrom && TimeHour(TimeCurrent())<SessBlockTo){ return(false); }')
open(E + r'\Strong2010b_claude_b21.mq4', 'wb').write(t.encode('cp1252')); print('b21 ok')
