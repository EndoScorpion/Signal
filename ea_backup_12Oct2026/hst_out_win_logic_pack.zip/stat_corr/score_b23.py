﻿"""score_b23.py - score tester reports like B22_THU.txt: sells, win%, pts after commission (net*100 - COMM/trade, COMM=8), max DD pts.
usage: python score_b23.py tag1 [tag2 ...]   (tags = report names in hst_out without .htm; glob patterns ok)
Safe chunk: each report is streamed in 5000-line blocks and reading stops as soon as the summary table is parsed
(the summary sits above the trade list), so memory stays flat however large the report is."""
import re, sys, glob, os
from itertools import islice
H = r'C:\Users\endos\Desktop\hst_out'
CHUNK = 5000
COMM = 8   # cost per trade in points. Rule from Nasif 2026-10-11 21:35: commission/cost max 8 pts per trade, regardless of balance or margin (was 9)
PAT = {'net': r'Total net profit</td><td[^>]*>([-\d.]+)', 'trades': r'Total trades</td><td[^>]*>(\d+)',
       'short': r'Short positions \(won %\)</td><td[^>]*>(\d+) \(([\d.]+)%\)', 'dd': r'Maximal drawdown</td><td[^>]*>([-\d.]+)'}

def score(path):
    got = {}
    with open(path, encoding='latin-1') as f:          # handle closed on any parse failure
        while len(got) < len(PAT):
            block = list(islice(f, CHUNK))
            if not block: break
            text = ''.join(block)
            for k, rx in PAT.items():
                if k not in got:
                    m = re.search(rx, text)
                    if m: got[k] = m.groups()
    if len(got) < len(PAT): raise ValueError('summary incomplete: missing ' + ','.join(k for k in PAT if k not in got))
    net, tr, dd = float(got['net'][0]), int(got['trades'][0]), float(got['dd'][0])
    return int(got['short'][0]), float(got['short'][1]), net * 100 - COMM * tr, dd * 100, tr

if __name__ == '__main__':
    args = sys.argv[1:]
    if args and args[0].startswith('--comm='): COMM = float(args.pop(0)[7:])
    for pat in args:
        for p in sorted(glob.glob(os.path.join(H, pat + '.htm'))):
            try:
                s, w, pts, dd, tr = score(p)
                print('%-22s sells %4d win %5.1f%%  pts %7.0f  DD %6.0f' % (os.path.basename(p)[:-4], s, w, pts, dd))
            except Exception as e:
                print('%-22s ERROR %s' % (os.path.basename(p)[:-4], e))
