"""rlog2_tables.py - bucket RLOG2 entry features vs trade net profit (after 9-pt commission).
Usage: python -I rlog2_tables.py   (run from anywhere; paths fixed below)
Journals are cumulative tester logs: only the LAST run (from the last 'open #1 ') is used.
Profit per order comes from the matching <tag>.htm deal table."""
import re, glob, os, struct, bisect, collections, html
OUT = r'C:\Users\endos\Desktop\hst_out'
HST = r'C:\Users\endos\Desktop\hst_work'
COMM = 0.09  # 9 points at 0.01 lot
KEEP = re.compile(r'RLOG|SELLSTOP|HEDGE|ROUNDLIMIT|LADDER|BRACKET| open #| close #|take profit #|stop loss #|delete')

def shrink(path):
    tag = os.path.basename(path)[8:-4]
    small = os.path.join(OUT, 'small_' + tag + '.log')
    if os.path.exists(small) and os.path.getmtime(small) > os.path.getmtime(path):
        return tag, small
    run = []
    with open(path, 'rb') as f:
        for raw in f:
            if b' open #1 ' in raw:  # new tester run starts
                keep_prev = [l for l in run[-6:] if 'RLOG' in l and '#1 ' in l]
                run = keep_prev
            if b'RLOG' in raw or b'#' in raw:
                l = raw.decode('latin-1', 'replace').rstrip()
                if KEEP.search(l):
                    run.append(l)
    with open(small, 'w', encoding='utf-8') as g:
        g.write('\n'.join(run))
    return tag, small

def deals(tag):
    p = os.path.join(OUT, tag + '.htm')
    if not os.path.exists(p):
        return {}
    h = open(p, 'rb').read().decode('latin-1')
    orders = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', h):
        c = [html.unescape(re.sub('<[^>]+>', '', x)).strip() for x in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(c) < 9 or not c[0].isdigit():
            continue
        ty, od = c[2], c[3]
        o = orders.setdefault(od, {'type': None, 'time': None, 'profit': None})
        if re.match(r'^(buy|sell)', ty) and o['type'] is None:
            o['type'] = ty
        if ty in ('buy', 'sell') and o['time'] is None:
            o['time'] = c[1]
        if re.search(r't/p|s/l|close', ty):
            try: o['profit'] = float(c[8])
            except ValueError: pass
    return orders

def load_h1():
    p = os.path.join(HST, 'EURUSD60.hst')
    b = open(p, 'rb').read()
    t, cl = [], []
    for off in range(148, len(b) - 59, 60):
        tm, o, hi, lo, c = struct.unpack_from('<qdddd', b, off)
        t.append(tm); cl.append(c)
    sma, s = [None] * len(cl), 0.0
    for i, c in enumerate(cl):
        s += c
        if i >= 1200: s -= cl[i - 1200]
        if i >= 1199: sma[i] = s / 1200
    return t, cl, sma

def ts(s):  # 'YYYY.MM.DD HH:MM' -> epoch (server time, treated as UTC)
    import calendar, time
    return calendar.timegm(time.strptime(s[:16], '%Y.%m.%d %H:%M'))

R2 = re.compile(r'RLOG2 #(\d+) tf15 adx ([-\d.]+) ([-\d.]+) ([-\d.]+) cci ([-\d.]+) rr ([-\d.]+) \| tf60 adx ([-\d.]+) ([-\d.]+) ([-\d.]+) cci ([-\d.]+) rr ([-\d.]+) \| volup (\d+) voldn (\d+) hour (\d+)')
FEAT = ['adx15', 'pdi15', 'mdi15', 'cci15', 'rr15', 'adx60', 'pdi60', 'mdi60', 'cci60', 'rr60', 'volratio', 'hour']

def main():
    ht, hc, hs = load_h1()
    trades = []
    for jp in sorted(glob.glob(os.path.join(OUT, 'journal_*.log'))):
        tag, small = shrink(jp)
        od = deals(tag)
        if not od: continue
        ym = re.search(r'(20\d\d)', tag); year = ym.group(1) if ym else '?'
        for l in open(small, encoding='utf-8'):
            m = R2.search(l)
            if not m: continue
            o = od.get(m.group(1))
            if not o or o['profit'] is None or not o['type']: continue
            v = [float(x) for x in m.groups()[1:12]]
            up, dn = float(m.group(12)), float(m.group(13))
            f = v[:10] + [up / dn if dn else 9.9, float(m.group(14))]
            side = 'buy' if o['type'].startswith('buy') else 'sell'
            reg = '?'
            if o['time']:
                i = bisect.bisect_right(ht, ts(o['time'])) - 1
                if i >= 0 and hs[i]: reg = 'up' if hc[i] > hs[i] else 'dn'
            trades.append(dict(zip(FEAT, f), tag=tag, year=year, side=side, reg=reg, net=o['profit'] - COMM))
    lines, flagged = [], []
    lines.append('RLOG2 tables: %d trades with features (net after %.2f commission). Variants overlap: same years appear in several tags.' % (len(trades), COMM))
    years = ['2017', '2019', '2020', '2021']
    for side in ('buy', 'sell'):
        for reg in ('all', 'up', 'dn'):
            T = [t for t in trades if t['side'] == side and (reg == 'all' or t['reg'] == reg)]
            if len(T) < 150: continue
            for ft in FEAT:
                vals = sorted(t[ft] for t in T)
                if ft == 'hour':
                    edges = None
                else:
                    edges = [vals[int(len(vals) * q / 5)] for q in range(1, 5)]
                groups = collections.defaultdict(list)
                for t in T:
                    k = t[ft] if edges is None else bisect.bisect_right(edges, t[ft])
                    groups[k].append(t)
                for k in sorted(groups):
                    G = groups[k]
                    if len(G) < 30: continue
                    lab = ('h%02d' % k) if edges is None else ('Q%d[%s..%s]' % (k + 1, '%.3g' % edges[k - 1] if k else 'min', '%.3g' % edges[k] if k < 4 else 'max'))
                    n = len(G); w = 100.0 * sum(t['net'] > 0 for t in G) / n; a = sum(t['net'] for t in G) / n
                    py, signs = [], []
                    for y in years:
                        Y = [t['net'] for t in G if t['year'] == y]
                        if len(Y) >= 10:
                            ay = sum(Y) / len(Y); py.append('%s:%+.2f(%d)' % (y[2:], ay, len(Y))); signs.append(ay > 0)
                    agree = max(signs.count(True), signs.count(False)) if signs else 0
                    s = '%-4s %-3s %-8s %-22s n=%5d win=%5.1f%% avg=%+.3f | %s' % (side, reg, ft, lab, n, w, a, ' '.join(py))
                    lines.append(s)
                    if len(signs) >= 3 and agree >= 3 and agree >= len(signs) - 1 and (a > 0) == (signs.count(True) >= 3):
                        flagged.append(('POS ' if a > 0 else 'NEG ') + s)
    open(os.path.join(OUT, 'RLOG2_TABLES.txt'), 'w').write('\n'.join(['FLAGGED (sign agrees >=3 of 4 years, n>=30):'] + flagged + ['', 'ALL BUCKETS:'] + lines))
    print(lines[0]); print('flagged', len(flagged), 'pos', sum(f.startswith('POS') for f in flagged))
    for f in flagged:
        if f.startswith('POS'): print(f)

main()
