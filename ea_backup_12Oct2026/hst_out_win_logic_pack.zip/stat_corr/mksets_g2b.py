"""mksets24.py - b24 .set files with EVERY extern listed (tester keeps stale inputs otherwise).
base = b22_thu.set (= b23 base) + all b23/b24 flags off; each variant overrides a few keys."""
import re
SRC = r'C:\Users\endos\Desktop\hst_out\Strong2010b_claude_b32.mq4'
T = r'C:\Users\endos\Desktop\mt4_tester\tester'
src = open(SRC, encoding='latin-1').read()
defaults, order = {}, []
for m in re.finditer(r'^\s*extern\s+(\w+)\s+([^;]+);', src, re.M):
    for part in m.group(2).split(','):
        k, v = [x.strip() for x in part.split('=', 1)]
        defaults[k] = {'true': '1', 'false': '0'}.get(v.strip('"'), v.strip('"')); order.append(k)

def load(name):
    d = {}
    for l in open(T + '\\' + name, encoding='latin-1'):
        if '=' in l: k, v = l.strip().split('=', 1); d[k] = v
    return d

BASE = dict(defaults); BASE.update(load('b22_thu.set'))
BASE.update({'SellBEStart': '0', 'SellBELock': '10', 'SellCCIMax': '999'})   # b23 flags off; b24 flags are off by default

V = {'g2b_base': {}, 'g2b_A0': {'UseZGate': '1', 'ZMax': '1.0'}, 'g2b_A1': {'UseZGate': '1', 'ZMax': '0.8'}, 'g2b_A2': {'UseZGate': '1', 'ZMax': '1.2'}, 'g2b_A3': {'UseZGate': '1', 'ZMax': '1.5'}, 'g2b_A4': {'UseZGate': '1', 'ZMax': '1.0', 'ZPeriod': '14'}, 'g2b_A5': {'UseZGate': '1', 'ZMax': '1.0', 'ZPeriod': '30'}, 'g2b_A6': {'UseZGate': '1', 'ZMax': '1.0', 'ZPeriod': '50'}, 'g2b_A7': {'UseZGate': '1', 'ZMax': '1.0', 'ZTF': '30'}, 'g2b_A8': {'UseZGate': '1', 'ZMax': '1.0', 'ZTF': '60'}, 'g2b_C0': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0'}, 'g2b_C1': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '0.8'}, 'g2b_C2': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '0.9'}, 'g2b_C3': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.1'}, 'g2b_C4': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0', 'RangeAtrPeriod': '10'}, 'g2b_C5': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0', 'RangeAtrPeriod': '20'}, 'g2b_X1': {'UseZGate': '1', 'ZMax': '1.0', 'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0'}, 'g2b_X5': {'UseZGate': '1', 'ZMax': '1.0', 'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0', 'UseChaosErGate': '1', 'ErPer': '100', 'ErMax': '0.09'}, 'g2b_X6': {'UseZGate': '1', 'ZMax': '1.0', 'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0', 'UseChaosErGate': '1', 'ErPer': '100', 'ErMax': '0.09', 'UseAHRateGate': '1', 'AHRateMax': '0.025'}}
for n, o in V.items():
    d = dict(BASE); d.update(o)
    bad = [k for k in d if k not in defaults]
    if bad: print('WARN keys not in EA', n, bad)
    with open(T + '\\' + n + '.set', 'w', newline='\r\n') as f:
        for k in order: f.write('%s=%s\n' % (k, d[k]))
print(len(V), 'sets,', len(order), 'inputs each')





