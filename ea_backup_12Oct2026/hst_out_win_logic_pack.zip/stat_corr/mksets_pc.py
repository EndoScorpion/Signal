﻿"""mksets24.py - b24 .set files with EVERY extern listed (tester keeps stale inputs otherwise).
base = b22_thu.set (= b23 base) + all b23/b24 flags off; each variant overrides a few keys."""
import re
SRC = r'C:\Users\endos\Desktop\hst_out\Strong2010b_claude_b38.mq4'
T = r'C:\Users\endos\Desktop\mt4_tester\tester'
src = open(SRC, encoding='latin-1').read()
for _m in ('WinGates_b34.mqh','WinGates_b36.mqh','SlopeTable.mqh','WinGates_b38.mqh','BranchSwitch.mqh'):
    src += '\n' + open(r'C:\Users\endos\Desktop\hst_out\\' + _m, encoding='latin-1').read()
defaults, order = {}, []
for m in re.finditer(r'^\s*extern\s+(\w+)\s+([^;]+);', src, re.M):
    for part in m.group(2).split(','):
        k, v = [x.strip() for x in part.split('=', 1)]
        defaults[k] = {'true': '1', 'false': '0'}.get(v.strip('"'), v.strip('"')); order.append(k)

def load(name):
    d = {}
    for l in open(T + '\\' + name, encoding='latin-1'):
        if '=' in l: k, v = l.strip().split('=', 1); d[k] = v
    return d

BASE = dict(defaults); BASE.update(load('b22_thu.set'))
BASE.update({'SellBEStart': '0', 'SellBELock': '10', 'SellCCIMax': '999'})   # b23 flags off; b24 flags are off by default

V = {'pc_base': {}, 'pc_B36_adx': {'UseAdxLowGate': '1', 'AdxTF': '5', 'AdxPer': '299', 'AdxMax': '7.6'}, 'pc_B36_chop': {'UseChopGate': '1', 'ChopTF': '5', 'ChopPer': '350', 'ChopMin': '47.2'}, 'pc_B36_chop_adx': {'UseChopGate': '1', 'ChopTF': '5', 'ChopPer': '350', 'ChopMin': '47.2', 'UseAdxLowGate': '1', 'AdxTF': '5', 'AdxPer': '299', 'AdxMax': '7.6'}, 'pc_B36_chop_zH1': {'UseChopGate': '1', 'ChopTF': '5', 'ChopPer': '350', 'ChopMin': '47.2', 'UseMpZGate': '1', 'MpZTF': '60', 'MpZPer': '75', 'MpZMax': '1.04'}, 'pc_B36_chop_zH1_cci': {'UseChopGate': '1', 'ChopTF': '5', 'ChopPer': '350', 'ChopMin': '47.2', 'UseMpZGate': '1', 'MpZTF': '60', 'MpZPer': '75', 'MpZMax': '1.04', 'UseCciFloorGate': '1', 'CciFTF': '15', 'CciFPer': '250', 'CciFMin': '-56'}, 'pc_B37_m1slope100': {'UseM1SlopeGate': '1', 'M1SlopePer': '100', 'M1SlopeMin': '-0.20'}, 'pc_B38_smooth_jitter': {'UseSlopeJitterGate': '1', 'JitTF': '15', 'JitPer': '100', 'JitN': '10', 'JitMin': '0.177'}, 'pc_B38_smooth_jitter_adx': {'UseSlopeJitterGate': '1', 'JitTF': '15', 'JitPer': '100', 'JitN': '10', 'JitMin': '0.177', 'UseAdxLowGate': '1', 'AdxTF': '5', 'AdxPer': '299', 'AdxMax': '7.6'}, 'pc_B38_smooth_samesign': {'UseSameSignGate': '1', 'SsTF': '60', 'SsPer': '20', 'SsN': '10', 'SsMax': '0.90'}, 'pc_B38_smooth_samesign_er': {'UseSameSignGate': '1', 'SsTF': '60', 'SsPer': '5', 'SsN': '10', 'SsMax': '0.80', 'UseChaosErGate': '1', 'ErPer': '100', 'ErMax': '0.08'}, 'pc_G4_1_er_dr': {'UseChaosErGate': '1', 'ErPer': '150', 'ErMax': '0.074', 'ErMode': '0', 'UseDailyRangeFilter': '1', 'RangeAtrPeriod': '30', 'MaxRangeAtrMultiplier': '0.93'}, 'pc_G4_2_er100_dr': {'UseChaosErGate': '1', 'ErPer': '100', 'ErMax': '0.064', 'ErMode': '0', 'UseDailyRangeFilter': '1', 'RangeAtrPeriod': '10', 'MaxRangeAtrMultiplier': '0.82'}, 'pc_G4_3_er_dr_nofri': {'UseChaosErGate': '1', 'ErPer': '150', 'ErMax': '0.074', 'ErMode': '0', 'UseDailyRangeFilter': '1', 'RangeAtrPeriod': '30', 'MaxRangeAtrMultiplier': '0.93', 'UseNoFriday': '1'}, 'pc_GEN3_B1_fd_ahrate': {'UseFdGate': '1', 'FdPer': '100', 'FdMin': '1.30', 'UseAHRateGate': '1', 'AHRPer': '50', 'AHRateMax': '0.025'}, 'pc_MP1_fracprox_er': {'UseMpFracGate': '1', 'MpFracTF': '15', 'MpFracPer': '150', 'MpFracMax': '10.4', 'UseChaosErGate': '1', 'ErPer': '100', 'ErMax': '0.08'}, 'pc_MP2_zH1_er': {'UseMpZGate': '1', 'MpZTF': '60', 'MpZPer': '75', 'MpZMax': '1.04', 'UseChaosErGate': '1', 'ErPer': '100', 'ErMax': '0.08'}, 'pc_MP6_erH1': {'UseMpErGate': '1', 'MpErTF': '60', 'MpErPer': '25', 'MpErMax': '0.16'}}
V['pc_zr_chopzH1']=dict(V['pc_B36_chop_zH1'], UseZGate='1', ZMax='1.0', UseDailyRangeFilter='1', MaxRangeAtrMultiplier='1.0')
V['pc_zr_chop']=dict(V['pc_B36_chop'], UseZGate='1', ZMax='1.0', UseDailyRangeFilter='1', MaxRangeAtrMultiplier='1.0')
for n, o in V.items():
    d = dict(BASE); d.update(o)
    bad = [k for k in d if k not in defaults]
    if bad: print('WARN keys not in EA', n, bad)
    with open(T + '\\' + n + '.set', 'w', newline='\r\n') as f:
        for k in order: f.write('%s=%s\n' % (k, d[k]))
print(len(V), 'sets,', len(order), 'inputs each')






