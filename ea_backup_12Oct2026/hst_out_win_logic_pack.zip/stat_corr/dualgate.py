"""dualgate.py - Williams fractal + Williams %R leaving an extreme, as (A) filter on b22 sells and (B) stand-alone entry
(sell and mirrored buy), H1 and M15, %R periods 7/14/28, lookback for the fractal 3/5/10 bars. Costs 11 pts, worst-case intrabar.
Not-NO-MEMORY condition: Shannon entropy of last 96 M15 returns below its median (more structure) - optional."""
import re, os, html, time, numpy as np
exec(open(r'C:\Users\endos\Desktop\hst_out\stat_corr\recombine.py').read().split('base = {')[0])
OUT = r'C:\Users\endos\Desktop\hst_out'
def roll(a, n, f):
    from numpy.lib.stride_tricks import sliding_window_view as sw; o = np.full(len(a), np.nan); o[n-1:] = f(sw(a, n), 1); return o
def wpr(a, n): hh, ll = roll(a['h'], n, np.max), roll(a['l'], n, np.min); return -100 * (hh - a['c']) / np.where(hh > ll, hh - ll, np.nan)
def frac(a):  # confirmed 5-bar fractal at bar k-2 (known at close of k)
    h, l = a['h'], a['l']; up = np.zeros(len(h), bool); dn = np.zeros(len(h), bool)
    up[4:] = (h[2:-2] > h[:-4]) & (h[2:-2] > h[1:-3]) & (h[2:-2] > h[3:-1]) & (h[2:-2] > h[4:]); dn[4:] = (l[2:-2] < l[:-4]) & (l[2:-2] < l[1:-3]) & (l[2:-2] < l[3:-1]) & (l[2:-2] < l[4:]); return up, dn
def recent(flag, k): return roll(flag.astype(float), k, np.max) > 0
d = np.diff(np.log(M15['c']), prepend=0.0)
def ent_at(i, n=96):
    h, _ = np.histogram(d[i-n+1:i+1], bins=10); p = h[h > 0] / h.sum(); return -(p * np.log2(p)).sum()
TT = []
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        dd = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in dd: dd['t0'] = ts(x[1])
        if re.search(r't/p|s/l|close', x[2]): dd['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for dd in od.values():
        if 't0' in dd and 'net' in dd: TT.append(dict(p=lab, net=dd['net'], t0=dd['t0']))
P = [lab for lab, _ in TAGS]; base = {p: sum(t['net'] for t in TT if t['p'] == p) for p in P}
for t in TT: i = np.searchsorted(M15['t'], t['t0']) - 1; t['ent'] = ent_at(i)
emed = np.median([t['ent'] for t in TT])
L = ['DUALGATE: fractal + %R leaving extreme. (A) filters on b22 sells; (B) stand-alone entries. pts after 11-pt cost.', 'base b22: ' + ' | '.join('%s %+.0f' % (p, base[p]) for p in P), '']
tried = 0; surv = []
for tfn, a in (('M15', M15), ('H1', H1)):
    up, dn = frac(a); idx = [np.searchsorted(a['t'], t['t0']) - 1 for t in TT]
    for n in (7, 14, 28):
        w = wpr(a, n); xdn = (np.roll(w, 1) > -20) & (w <= -20)
        for k in (3, 5, 10):
            gate = recent(up, k) & recent(xdn, k)
            for ent in (False, True):
                tried += 1; keep = lambda t, j: gate[j] and (not ent or t['ent'] < emed)
                r = {p: sum(t['net'] for t, j in zip(TT, idx) if t['p'] == p and keep(t, j)) for p in P}; kp = sum(1 for t, j in zip(TT, idx) if keep(t, j)) / len(TT)
                b = sum(r[p] > base[p] for p in P)
                s = '(A) %s %%R%d k=%d%s REQUIRE gate: better %d/8 kept %.0f%% | ' % (tfn, n, k, ' +lowEntropy' if ent else '', b, 100 * kp) + ' '.join('%s %+.0f' % (p, r[p]) for p in P); L.append(s)
                if b >= 6 and kp >= 0.6: surv.append(s)
# (B) stand-alone entries, TP 300 / SL 150, time stop 24 H1 bars / 48 M15
def sim(a, ix, side, tp, sl, hold):
    o, h, l, c = a['o'], a['h'], a['l'], a['c']; out = []
    for i in ix:
        if i + 2 >= len(c): continue
        e = o[i+1]; r = None
        for k2 in range(i+1, min(i+1+hold, len(c))):
            if side < 0:
                if h[k2] >= e + sl: r = -sl; break
                if l[k2] <= e - tp: r = tp; break
            else:
                if l[k2] <= e - sl: r = -sl; break
                if h[k2] >= e + tp: r = tp; break
        if r is None: r = side * (c[min(i+hold, len(c)-1)] - e)
        out.append((i, r / 1e-5 - 11))
    return out
yr = {tfn: np.array([time.gmtime(x).tm_year for x in a['t']]) for tfn, a in (('M15', M15), ('H1', H1))}
YRS = [2011, 2012, 2017, 2019, 2020, 2021, 2022, 2025, 2026]
L.append(''); L.append('(B) stand-alone entries (avg pts per trade by year):')
for tfn, a, hold in (('M15', M15, 48), ('H1', H1, 24)):
    up, dn = frac(a)
    for n in (7, 14, 28):
        w = wpr(a, n); xdn = (np.roll(w, 1) > -20) & (w <= -20); xup = (np.roll(w, 1) < -80) & (w >= -80)
        for side, g in ((-1, recent(up, 5) & xdn), (1, recent(dn, 5) & xup)):
            tried += 1; ix = np.nonzero(g & np.isin(yr[tfn], YRS))[0]; res = sim(a, ix, side, 300e-5, 150e-5, hold)
            by = {}
            for i, v in res: by.setdefault(yr[tfn][i], []).append(v)
            pos = sum(np.mean(v) > 0 for v in by.values()); allv = [v for _, v in res]
            L.append('(B) %s %s %%R%d: n=%d avg %+.1f | positive years %d/%d | ' % (tfn, 'SELL' if side < 0 else 'BUY ', n, len(allv), np.mean(allv) if allv else 0, pos, len(by)) + ' '.join('%d:%+.0f(%d)' % (y % 100, np.mean(v), len(v)) for y, v in sorted(by.items())))
L.insert(2, 'combos tried: %d' % tried); L += ['', '(A) SURVIVORS (>=6/8, kept>=60%):'] + (surv or ['none'])
open(os.path.join(OUT, 'DUALGATE.txt'), 'w').write('\n'.join(L)); print('\n'.join([x for x in L if x.startswith('(B)') or 'SURVIVORS' in x or 'combos' in x] + L[-max(1, len(surv)):]))
