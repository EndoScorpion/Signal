E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b21.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('extern int    SessBlockTo=0;', 'extern int    SessBlockTo=0;' + NL + '// b22: weekday block: no new sell orders on this server weekday (0=Sun .. 6=Sat, -1 = off)' + NL + 'extern int    DayBlock=-1;')
rep('if(SessBlockTo>SessBlockFrom && ', 'if(DayBlock>=0 && DayOfWeek()==DayBlock){ return(false); } if(SessBlockTo>SessBlockFrom && ')
open(E + r'\Strong2010b_claude_b22.mq4', 'wb').write(t.encode('cp1252')); print('b22 ok')
