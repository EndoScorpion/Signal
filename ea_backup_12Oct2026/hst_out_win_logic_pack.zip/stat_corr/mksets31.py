﻿"""mksets24.py - b24 .set files with EVERY extern listed (tester keeps stale inputs otherwise).
base = b22_thu.set (= b23 base) + all b23/b24 flags off; each variant overrides a few keys."""
import re
SRC = r'C:\Users\endos\Desktop\hst_out\Strong2010b_claude_b31.mq4'
T = r'C:\Users\endos\Desktop\mt4_tester\tester'
src = open(SRC, encoding='latin-1').read()
defaults, order = {}, []
for m in re.finditer(r'^\s*extern\s+(\w+)\s+([^;]+);', src, re.M):
    for part in m.group(2).split(','):
        k, v = [x.strip() for x in part.split('=', 1)]
        defaults[k] = {'true': '1', 'false': '0'}.get(v.strip('"'), v.strip('"')); order.append(k)

def load(name):
    d = {}
    for l in open(T + '\\' + name, encoding='latin-1'):
        if '=' in l: k, v = l.strip().split('=', 1); d[k] = v
    return d

BASE = dict(defaults); BASE.update(load('b22_thu.set'))
BASE.update({'SellBEStart': '0', 'SellBELock': '10', 'SellCCIMax': '999'})   # b23 flags off; b24 flags are off by default

V = {
 'b31_base': {},
 'b31_fb': {'UseFracBuy': '1'},
 'b31_fb_noreg': {'UseFracBuy': '1', 'FracBuyRegime': '0'},
 'b31_fb_sl150': {'UseFracBuy': '1', 'FracBuySL': '150'},
 'b31_fb_w50': {'UseFracBuy': '1', 'FracWprBuy': '-50'},
 'b31_wpr50': {'UseWprGate': '1', 'WprMax': '-50'},
 'b31_wpr50_adapt': {'UseWprGate': '1', 'WprMax': '-50', 'UseAdaptWpr': '1'},
 'b31_cci150': {'SellCCIMax': '150'},
 'b31_be200': {'SellBEStart': '200'},
 'b31_be250L150': {'SellBEStart': '250', 'SellBELock': '150'},
 'b31_rng100': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0'},
 'b31_rng090': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '0.9'},
 'b31_rng080': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '0.8'},
 'b31_rng110': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.1'},
 'b31_zr': {'UseZGate': '1', 'ZMax': '1.0', 'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0'},
 'b31_zr2': {'UseZGate': '1', 'ZMax': '0.75', 'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '0.9'},
 'b31_zr3': {'UseZGate': '1', 'ZMax': '1.5', 'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '0.9'},
 'b31_zrfb': {'UseZGate': '1', 'ZMax': '1.0', 'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0', 'UseFracBuy': '1', 'FracBuyRegime': '0'},
}
for n, o in V.items():
    d = dict(BASE); d.update(o)
    bad = [k for k in d if k not in defaults]
    if bad: print('WARN keys not in EA', n, bad)
    with open(T + '\\' + n + '.set', 'w', newline='\r\n') as f:
        for k in order: f.write('%s=%s\n' % (k, d[k]))
print(len(V), 'sets,', len(order), 'inputs each')





