"""era2.py - trailing-only block rules for b20 sells. Score per year vs b20; survivor = better in >=5 of 6 years."""
import re, os, html, time, calendar, numpy as np
OUT = r'C:\Users\endos\Desktop\hst_out'; HST = r'C:\Users\endos\Desktop\hst_work'
def load(sym, tf):
    p = r'%s\%s%d.hst' % (HST, sym, tf)
    if not os.path.exists(p): return None
    b = open(p, 'rb').read(); n = (len(b) - 148) // 60
    return np.frombuffer(b, dtype=np.dtype([('t','<i8'),('o','<f8'),('h','<f8'),('l','<f8'),('c','<f8'),('v','<i8'),('s','<i4'),('rv','<i8')]), count=n, offset=148)
def sma(x, p):
    c = np.cumsum(np.insert(x, 0, 0.0)); o = np.full(len(x), np.nan); o[p-1:] = (c[p:] - c[:-p]) / p; return o
D = load('EURUSD', 1440); dt, dc, dh, dl = D['t'], D['c'], D['h'], D['l']
s50, s200 = sma(dc, 50), sma(dc, 200)
H4 = {k: load(k, 240) for k in ('EURUSD', 'GBPUSD', 'USDCHF', 'USDJPY')}
def ts(s): return calendar.timegm(time.strptime(s[:16], '%Y.%m.%d %H:%M'))
def at(a, t0):  # index of last CLOSED bar before t0
    return np.searchsorted(a['t'] if not isinstance(a, np.ndarray) or a.dtype.names else a, t0) - 2
T = []
for y in (2011, 2012, 2017, 2019, 2020, 2021):
    hd = open(os.path.join(OUT, 'b20_blk_%d.htm' % y), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in d: d['t0'] = ts(x[1]); d['px'] = float(x[5])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100; d['t1'] = ts(x[1])
    for d in od.values():
        if 't0' not in d or 'net' not in d: continue
        i = np.searchsorted(dt, d['t0']) - 1  # last completed D1 bar
        e = dict(y=y, t0=d['t0'], t1=d['t1'], net=d['net'], dow=time.gmtime(d['t0']).tm_wday, mon=time.gmtime(d['t0']).tm_mon, wom=(time.gmtime(d['t0']).tm_mday - 1) // 7)
        e['slope50'] = (s50[i] - s50[i-5]) / dc[i] * 100 if i > 5 else np.nan        # D1 SMA50 5-day slope, %
        e['dist200'] = (dc[i] - s200[i]) / s200[i] * 100                               # distance from D1 SMA200, %
        e['d1rng'] = np.mean((dh[i-19:i+1] - dl[i-19:i+1]) / dc[i-19:i+1]) * 100       # 20-day avg daily range %
        usd = []
        for k, a in H4.items():
            if a is None: continue
            j = np.searchsorted(a['t'], d['t0']) - 1
            if j > 30: r = (a['c'][j] - a['c'][j-30]) / a['c'][j-30]; usd.append(-r if k in ('EURUSD', 'GBPUSD') else r)
        e['usd5d'] = np.mean(usd) * 100 if usd else np.nan                              # USD strength, 5-day (30 H4 bars)
        T.append(e)
T.sort(key=lambda e: e['t0']); YRS = (2011, 2012, 2017, 2019, 2020, 2021)
base = {y: sum(e['net'] for e in T if e['y'] == y) for y in YRS}
L = ['ERA_ANALYSIS2 (trailing info only). b20 block-on, pts after 11-pt cost. base: ' + ' | '.join('%d %+.0f' % (y, base[y]) for y in YRS), '']
surv = []
def score(name, keep):
    r = {y: sum(e['net'] for e in T if e['y'] == y and keep(e)) for y in YRS}; n = {y: sum(1 for e in T if e['y'] == y and keep(e)) for y in YRS}
    better = sum(r[y] > base[y] for y in YRS); pos = sum(r[y] > 0 for y in YRS)
    s = '%-34s ' % name + ' | '.join('%d %+6.0f(%d)' % (y % 100, r[y], n[y]) for y in YRS) + '  better %d/6 pos %d/6' % (better, pos)
    L.append(s)
    if better >= 5: surv.append(s)
for th in (0, 0.1): score('D1 SMA50 slope <= -%.1f%% (down)' % th, lambda e, th=th: e['slope50'] <= -th)
score('D1 SMA50 slope < 0.2%', lambda e: e['slope50'] < 0.2)
for th in (0, 2, -2): score('close below D1 SMA200 by > %d%%' % th, lambda e, th=th: e['dist200'] < -th if th >= 0 else e['dist200'] < 2)
for th in (0.6, 0.8, 1.0): score('20d daily range < %.1f%%' % th, lambda e, th=th: e['d1rng'] < th)
for th in (0, 0.5): score('USD 5d strength > -%.1f%% (not weakening)' % th, lambda e, th=th: e['usd5d'] > -th)
score('USD 5d strength > 0.5% (strong USD)', lambda e: e['usd5d'] > 0.5)
for dd in range(5): score('skip weekday %d (0=Mon)' % dd, lambda e, dd=dd: e['dow'] != dd)
score('skip week-of-month 0 (days 1-7)', lambda e: e['wom'] != 0)
score('skip Jan + Aug + Dec', lambda e: e['mon'] not in (1, 8, 12))
def consec(n, hours):  # pause after n consecutive CLOSED losses (closed before the signal), for `hours`
    keep = set()
    for e in T:
        done = [x for x in T if x['y'] == e['y'] and x['t1'] < e['t0']]; done.sort(key=lambda x: x['t1'])
        last = done[-n:]
        if len(last) == n and all(x['net'] <= 0 for x in last) and e['t0'] - last[-1]['t1'] < hours * 3600: continue
        keep.add(id(e))
    return keep
for n, hr in ((3, 24), (3, 72), (5, 72)):
    ks = consec(n, hr); score('pause %dh after %d closed losses' % (hr, n), lambda e, ks=ks: id(e) in ks)
def expect(w):
    keep = set()
    for e in T:
        done = sorted([x for x in T if x['y'] == e['y'] and x['t1'] < e['t0']], key=lambda x: x['t1'])[-w:]
        if len(done) < w or np.mean([x['net'] for x in done]) > 0: keep.add(id(e))
    return keep
ks = expect(50); score('closed 50-trade expectancy > 0', lambda e: id(e) in ks)
L += ['', 'SURVIVORS (better than b20 in >= 5 of 6 years):'] + (surv or ['none'])
L += ['', 'Ladder-leg split not possible from the reports (deal table has no order comment); needs a tester run with leg tagging.']
open(os.path.join(OUT, 'ERA_ANALYSIS2.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
