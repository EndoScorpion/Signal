"""days.py - b20 (block on) sells by weekday (Fri/Sun focus), news day vs normal day, and session overlaps (server time GMT+2/+3)."""
import re, os, html, time
OUT = r'C:\Users\endos\Desktop\hst_out'
TAGS = [('2011', 'b20_blk_2011'), ('2012', 'b20_blk_2012'), ('2017', 'b20_blk_2017'), ('2019', 'b20_blk_2019'), ('2020', 'b20_blk_2020'),
        ('2021', 'b20_blk_2021'), ('22', 'legs_2022'), ('25-26', 'legs_2526')]
e1 = open(os.path.join(OUT, 'stat_corr', 'b15_e1.txt')).read()
NEWS = set()
for k in ('NFPd', 'CPId', 'FOMCd'): NEWS |= set(re.search(k + r'="([^"]+)"', e1).group(1).split())
# server-time session map: Sydney 00-09, Tokyo 02-11, London 10-19, New York 15-24
def zone(h):
    s = []
    if 0 <= h < 9: s.append('Syd')
    if 2 <= h < 11: s.append('Tok')
    if 10 <= h < 19: s.append('Lon')
    if 15 <= h < 24: s.append('NY')
    return '+'.join(s) if s else 'none'
rows = []
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 'tm' not in d: d['tm'] = x[1]
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for d in od.values():
        if 'tm' in d and 'net' in d:
            st = time.strptime(d['tm'][:16], '%Y.%m.%d %H:%M')
            rows.append(dict(p=lab, net=d['net'], wd=('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')[st.tm_wday], news=d['tm'][:10] in NEWS, z=zone(st.tm_hour)))
def line(name, sel):
    g = [r for r in rows if sel(r)]
    if not g: return '%-28s no trades' % name
    per = {}
    for r in g: per.setdefault(r['p'], []).append(r['net'])
    pos = sum(sum(v) > 0 for v in per.values())
    return '%-28s tot %+7.0f n=%5d win %4.1f%% avg %+6.1f | positive %d/%d | ' % (name, sum(r['net'] for r in g), len(g), 100.0 * sum(r['net'] > 0 for r in g) / len(g), sum(r['net'] for r in g) / len(g), pos, len(per)) + ' '.join('%s:%+.0f(%d)' % (k, sum(v), len(v)) for k, v in per.items())
L = ['DAYS / NEWS / OVERLAPS: b20 block-on sells, pts after commission, 8 periods (2011,2012,2017,2019,2020,2021,2022 Jan-Sep,2025-09..2026-09)', '', 'WEEKDAY:']
for w in ('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'): L.append(line(w, lambda r, w=w: r['wd'] == w))
L += ['', 'FRIDAY x NEWS (news = NFP / CPI / FOMC date):', line('Fri news day', lambda r: r['wd'] == 'Fri' and r['news']), line('Fri normal day', lambda r: r['wd'] == 'Fri' and not r['news']),
      line('Any news day', lambda r: r['news']), line('Any normal day', lambda r: not r['news'])]
L += ['', 'SESSION OVERLAPS (server time: Syd 00-09, Tok 02-11, Lon 10-19, NY 15-24):']
for z in sorted(set(r['z'] for r in rows)): L.append(line(z, lambda r, z=z: r['z'] == z))
open(os.path.join(OUT, 'DAYS_SESSIONS.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
