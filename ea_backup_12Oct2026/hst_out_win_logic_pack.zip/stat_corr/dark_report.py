"""dark_report.py TAG [TAG ...] - writes hst_out\dark_reports\<TAG>.htm: black/green copy of the tester report
with a balance chart (gridlines, price axis, trade-number axis) beside the summary. Original report untouched."""
import re, sys, os, html
OUT = r'C:\Users\endos\Desktop\hst_out'; DST = os.path.join(OUT, 'dark_reports'); os.makedirs(DST, exist_ok=True)
CSS = ('<style>body,table,td,th{background:#000 !important;color:#33ff66 !important;font-family:Arial,sans-serif}a{color:#7fc8ff !important}'
       'img{display:none}.wrap{display:flex;gap:16px;align-items:flex-start}.left{flex:1;min-width:0;overflow:auto;max-height:95vh}.right{position:sticky;top:8px}</style>')
def chart(bal, tag):
    W, H, L, R, T, B = 700, 420, 70, 15, 30, 40
    mn, mx = min(bal), max(bal); pad = (mx - mn) * 0.05 or 1; mn -= pad; mx += pad
    X = lambda i: L + (W - L - R) * i / max(1, len(bal) - 1); Y = lambda v: T + (H - T - B) * (mx - v) / (mx - mn)
    g = []
    for k in range(6):
        v = mn + (mx - mn) * k / 5; y = Y(v)
        g.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="#1f5f2f" stroke-dasharray="3,3"/><text x="%d" y="%.1f" fill="#9fffb5" font-size="12" text-anchor="end">%.0f</text>' % (L, y, W - R, y, L - 6, y + 4, v))
    for k in range(6):
        i = int((len(bal) - 1) * k / 5); x = X(i)
        g.append('<line x1="%.1f" y1="%d" x2="%.1f" y2="%d" stroke="#1f5f2f" stroke-dasharray="3,3"/><text x="%.1f" y="%d" fill="#9fffb5" font-size="12" text-anchor="middle">%d</text>' % (x, T, x, H - B, x, H - B + 16, i))
    pts = ' '.join('%.1f,%.1f' % (X(i), Y(v)) for i, v in enumerate(bal))
    return ('<svg width="%d" height="%d" style="background:#000;border:1px solid #33ff66">%s<polyline fill="none" stroke="#33ff66" stroke-width="1.6" points="%s"/>'
            '<text x="%d" y="18" fill="#7fc8ff" font-size="13">%s balance: start %.2f, end %.2f, min %.2f, max %.2f</text>'
            '<text x="%d" y="%d" fill="#9fffb5" font-size="12" text-anchor="middle">trade number</text></svg>') % (W, H, ''.join(g), pts, L, tag, bal[0], bal[-1], min(bal), max(bal), (W + L) // 2, H - 6)
for tag in sys.argv[1:]:
    h = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1')
    bal = []
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', h):
        c = [html.unescape(re.sub('<[^>]+>', '', x)).strip() for x in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(c) >= 10 and c[0].isdigit() and re.match(r'^[\d.]+$', c[9]): bal.append(float(c[9]))
    body = re.search(r'(?is)<body[^>]*>(.*)</body>', h); body = body.group(1) if body else h
    page = '<html><head><meta charset="utf-8"><title>%s</title>%s</head><body><div class="wrap"><div class="left">%s</div><div class="right">%s</div></div></body></html>' % (tag, CSS, body, chart(bal, tag) if len(bal) > 1 else '')
    open(os.path.join(DST, tag + '.htm'), 'w', encoding='utf-8').write(page); print('saved', tag, len(bal), 'balance points')
