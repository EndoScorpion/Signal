"""recombine.py - failed-idea pieces reused as extra filters on the proven b22 sells (trade lists b22_thu_*).
Pieces computed from history at the last CLOSED bar before entry (no look-ahead):
 lowrev   = M15 close at 15-bar low with <=6 bullish of 15 (b19 trigger)       -> as BLOCK (selling into a low) or REQUIRE
 emaup    = H1 EMA20 > EMA50 (b19 cross state)                                -> as BLOCK (uptrend) or REQUIRE
 quiet    = H1 20-bar range / (20*ATR14) < 0.17 (b13 gate)                    -> as REQUIRE
 fibnear  = within 30 pts of a 0.382/0.5/0.618 level of the last 48 H1 bars (fib idea) -> as REQUIRE / BLOCK
Score: per period pts after commission; survivor = better than b22 in >=5 of 8 periods with >=60% of trades kept."""
import re, os, html, time, calendar, numpy as np
OUT = r'C:\Users\endos\Desktop\hst_out'; HST = r'C:\Users\endos\Desktop\hst_work'
def load(tf):
    b = open(r'%s\EURUSD%d.hst' % (HST, tf), 'rb').read(); n = (len(b) - 148) // 60
    return np.frombuffer(b, dtype=np.dtype([('t','<i8'),('o','<f8'),('h','<f8'),('l','<f8'),('c','<f8'),('v','<i8'),('s','<i4'),('rv','<i8')]), count=n, offset=148)
def ema(x, p):
    k = 2.0 / (p + 1); o = np.empty_like(x); o[0] = x[0]
    for i in range(1, len(x)): o[i] = o[i-1] + k * (x[i] - o[i-1])
    return o
M15, H1 = load(15), load(60)
h1c, h1h, h1l = H1['c'], H1['h'], H1['l']; e20, e50 = ema(h1c, 20), ema(h1c, 50)
tr = np.maximum(h1h[1:] - h1l[1:], np.maximum(abs(h1h[1:] - h1c[:-1]), abs(h1l[1:] - h1c[:-1]))); tr = np.insert(tr, 0, h1h[0] - h1l[0]); atr = ema(tr, 27)
TAGS = [('2011', 'b22_thu_2011'), ('2012', 'b22_thu_2012'), ('2017', 'b22_thu_2017'), ('2019', 'b22_thu_2019'), ('2020', 'b22_thu_2020'), ('2021', 'b22_thu_2021'), ('22', 'b22_thu_2022'), ('25-26', 'b22_thu_2526')]
def ts(s): return calendar.timegm(time.strptime(s[:16], '%Y.%m.%d %H:%M'))
T = []
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in d: d['t0'] = ts(x[1]); d['px'] = float(x[5])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for d in od.values():
        if 't0' not in d or 'net' not in d: continue
        i = np.searchsorted(M15['t'], d['t0']) - 1; j = np.searchsorted(H1['t'], d['t0']) - 1
        lo = M15['l'][i-14:i+1].min(); bull = int((M15['c'][i-14:i+1] > M15['o'][i-14:i+1]).sum())
        rr = (h1h[j-19:j+1].max() - h1l[j-19:j+1].min()) / (20 * atr[j]) if atr[j] > 0 else 9
        hi48, lo48 = h1h[j-47:j+1].max(), h1l[j-47:j+1].min(); lv = [hi48 - (hi48 - lo48) * r for r in (0.382, 0.5, 0.618)]
        T.append(dict(p=lab, net=d['net'], lowrev=M15['c'][i] <= lo and bull <= 6, emaup=e20[j] > e50[j], quiet=rr < 0.17,
                      fibnear=min(abs(d['px'] - v) for v in lv) < 30e-5))
base = {lab: sum(t['net'] for t in T if t['p'] == lab) for lab, _ in TAGS}; nb = {lab: sum(1 for t in T if t['p'] == lab) for lab, _ in TAGS}
L = ['RECOMBINE on b22 sells (pts after commission). base b22: ' + ' | '.join('%s %+.0f(%d)' % (k, base[k], nb[k]) for k, _ in TAGS), '']
surv = []
rules = {'BLOCK lowrev': lambda t: not t['lowrev'], 'REQUIRE lowrev': lambda t: t['lowrev'], 'BLOCK emaup (H1 EMA20>50)': lambda t: not t['emaup'],
         'REQUIRE emaup': lambda t: t['emaup'], 'REQUIRE quiet': lambda t: t['quiet'], 'BLOCK quiet': lambda t: not t['quiet'],
         'REQUIRE fibnear': lambda t: t['fibnear'], 'BLOCK fibnear': lambda t: not t['fibnear'],
         'BLOCK emaup + BLOCK lowrev': lambda t: not t['emaup'] and not t['lowrev'], 'BLOCK emaup + REQUIRE fibnear': lambda t: not t['emaup'] and t['fibnear']}
for n, f in rules.items():
    r = {k: sum(t['net'] for t in T if t['p'] == k and f(t)) for k, _ in TAGS}; c = {k: sum(1 for t in T if t['p'] == k and f(t)) for k, _ in TAGS}
    better = sum(r[k] > base[k] for k, _ in TAGS); keep = sum(c.values()) / max(1, sum(nb.values()))
    s = '%-30s ' % n + ' | '.join('%s %+.0f(%d)' % (k, r[k], c[k]) for k, _ in TAGS) + '  better %d/8 kept %.0f%%' % (better, 100 * keep)
    L.append(s)
    if better >= 5 and keep >= 0.6: surv.append(s)
L += ['', 'SURVIVORS (>=5/8 better, >=60% trades kept):'] + (surv or ['none'])
open(os.path.join(OUT, 'RECOMBINE.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
