"""sweep.py - indicator x period x timeframe block-filter sweep on b22 sells, with plateau and shuffled controls."""
import re, os, html, numpy as np
exec(open(r'C:\Users\endos\Desktop\hst_out\stat_corr\recombine.py').read().split('base = {')[0])
OUT = r'C:\Users\endos\Desktop\hst_out'
M5 = load(5); H4 = load(240); TFS = {'M5': M5, 'M15': M15, 'H1': H1, 'H4': H4}
TT = []
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in d: d['t0'] = ts(x[1])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for d in od.values():
        if 't0' in d and 'net' in d: TT.append((lab, d['net'], d['t0']))
labs = np.array([t[0] for t in TT]); net = np.array([t[1] for t in TT]); t0 = np.array([t[2] for t in TT])
P = [lab for lab, _ in TAGS]; base = np.array([net[labs == p].sum() for p in P])
def roll_max(x, n): from numpy.lib.stride_tricks import sliding_window_view as sw; o = np.full(len(x), np.nan); o[n-1:] = sw(x, n).max(1); return o
def roll_min(x, n): from numpy.lib.stride_tricks import sliding_window_view as sw; o = np.full(len(x), np.nan); o[n-1:] = sw(x, n).min(1); return o
def sma(x, n): c = np.cumsum(np.insert(x, 0, 0.0)); o = np.full(len(x), np.nan); o[n-1:] = (c[n:] - c[:-n]) / n; return o
PER = [2, 5, 10, 15, 20, 25, 30, 50, 75, 100, 200, 300, 400, 500]
def indicators(a, n):
    h, l, c, v = a['h'], a['l'], a['c'], a['v'].astype(float)
    hh, ll = roll_max(h, n), roll_min(l, n); wr = -100 * (hh - c) / np.where(hh > ll, hh - ll, np.nan)
    d = np.diff(c, prepend=c[0]); up = sma(np.maximum(d, 0), n); dn = sma(np.maximum(-d, 0), n); rsi = 100 - 100 / (1 + up / np.where(dn > 0, dn, np.nan))
    tp = (h + l + c) / 3; m = sma(tp, n); md = sma(np.abs(tp - np.nan_to_num(m)), n); cci = (tp - m) / (0.015 * np.where(md > 0, md, np.nan))
    s = sma(c, n); slope = (s - np.roll(s, max(1, n // 5))) / c * 1e4; vr = v / sma(v, n)
    return {'%R>-20': wr > -20, '%R<-80': wr < -80, 'RSI>70': rsi > 70, 'RSI<30': rsi < 30, 'CCI>100': cci > 100, 'CCI<-100': cci < -100,
            'slope>0': slope > 0, 'vol>1.5x': vr > 1.5}
res = {}; tried = 0
for tf, a in TFS.items():
    idx = np.searchsorted(a['t'], t0) - 1
    for n in PER:
        if n * (240 if tf == 'H4' else 1) > 5000: continue
        for name, flag in indicators(a, n).items():
            blk = np.nan_to_num(flag[idx]).astype(bool); keep = ~blk; tried += 1
            r = np.array([net[(labs == p) & keep].sum() for p in P]); res[(tf, name, n)] = (int((r > base).sum()), keep.mean(), r)
rng = np.random.default_rng(7); ctrl = []
for k in range(300):
    keep = rng.random(len(net)) > rng.uniform(0.05, 0.4); r = np.array([net[(labs == p) & keep].sum() for p in P]); ctrl.append(int((r > base).sum()))
c95 = int(np.percentile(ctrl, 95))
L = ['SWEEP on b22 sells: %d combos (4 TF x 14 periods x 8 block rules). Shuffled-control: random blocks reach >= %d/8 better in 5%% of cases.' % (tried, c95),
     'Survivor = better than b22 in >= max(6, control95+1) of 8, keeps >= 60%, AND both neighbouring periods also >= 5/8 (plateau). Base: ' + ' | '.join('%s %+.0f' % (p, b) for p, b in zip(P, base)), '']
need = max(6, c95 + 1); surv = []
for (tf, name, n), (b, k, r) in sorted(res.items(), key=lambda x: (-x[1][0], -x[1][2].sum())):
    if b < need or k < 0.6: continue
    i = PER.index(n); nb = [res.get((tf, name, PER[j])) for j in (i - 1, i + 1) if 0 <= j < len(PER)]
    plateau = all(x is not None and x[0] >= 5 for x in nb)
    s = '%-4s BLOCK %-9s n=%-3d better %d/8 kept %3.0f%% plateau %-3s | ' % (tf, name, n, b, 100 * k, 'yes' if plateau else 'no') + ' '.join('%s %+.0f' % (p, x) for p, x in zip(P, r))
    L.append(s)
    if plateau: surv.append(s)
L += ['', 'SURVIVORS (plateau):'] + (surv or ['none'])
open(os.path.join(OUT, 'SWEEP.txt'), 'w').write('\n'.join(L)); print('\n'.join(L[:3] + ['...'] + L[-(len(surv) + 2):]))
