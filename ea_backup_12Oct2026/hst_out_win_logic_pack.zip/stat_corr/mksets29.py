"""mksets24.py - b24 .set files with EVERY extern listed (tester keeps stale inputs otherwise).
base = b22_thu.set (= b23 base) + all b23/b24 flags off; each variant overrides a few keys."""
import re
SRC = r'C:\Users\endos\Desktop\hst_out\Strong2010b_claude_b29.mq4'
T = r'C:\Users\endos\Desktop\mt4_tester\tester'
src = open(SRC, encoding='latin-1').read()
defaults, order = {}, []
for m in re.finditer(r'^\s*extern\s+(\w+)\s+([^;]+);', src, re.M):
    for part in m.group(2).split(','):
        k, v = [x.strip() for x in part.split('=', 1)]
        defaults[k] = {'true': '1', 'false': '0'}.get(v.strip('"'), v.strip('"')); order.append(k)

def load(name):
    d = {}
    for l in open(T + '\\' + name, encoding='latin-1'):
        if '=' in l: k, v = l.strip().split('=', 1); d[k] = v
    return d

BASE = dict(defaults); BASE.update(load('b22_thu.set'))
BASE.update({'SellBEStart': '0', 'SellBELock': '10', 'SellCCIMax': '999'})   # b23 flags off; b24 flags are off by default

V = {
 'b29_base': {},
 'b29_fa20_p14': {'UseFracBreakGate': '1', 'FracWprSell': '-20', 'FracWprPeriod': '14'},
 'b29_fa30_p14': {'UseFracBreakGate': '1', 'FracWprSell': '-30', 'FracWprPeriod': '14'},
 'b29_fa50_p14': {'UseFracBreakGate': '1', 'FracWprSell': '-50', 'FracWprPeriod': '14'},
 'b29_fa20_p7': {'UseFracBreakGate': '1', 'FracWprSell': '-20', 'FracWprPeriod': '7'},
 'b29_fa30_p7': {'UseFracBreakGate': '1', 'FracWprSell': '-30', 'FracWprPeriod': '7'},
 'b29_fa50_p7': {'UseFracBreakGate': '1', 'FracWprSell': '-50', 'FracWprPeriod': '7'},
 'b29_fc4': {'UseFracFailGate': '1', 'FracRecent': '4'},
 'b29_fc8': {'UseFracFailGate': '1', 'FracRecent': '8'},
 'b29_fc16': {'UseFracFailGate': '1', 'FracRecent': '16'},
 'b29_dd1': {'UseDailyDDFreeze': '1', 'DailyDDPct': '1'},
 'b29_dd2': {'UseDailyDDFreeze': '1', 'DailyDDPct': '2'},
 'b29_dd3': {'UseDailyDDFreeze': '1', 'DailyDDPct': '3'},
}
for n, o in V.items():
    d = dict(BASE); d.update(o)
    bad = [k for k in d if k not in defaults]
    if bad: print('WARN keys not in EA', n, bad)
    with open(T + '\\' + n + '.set', 'w', newline='\r\n') as f:
        for k in order: f.write('%s=%s\n' % (k, d[k]))
print(len(V), 'sets,', len(order), 'inputs each')


