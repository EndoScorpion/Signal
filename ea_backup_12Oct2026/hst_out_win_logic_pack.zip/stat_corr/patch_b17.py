E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b16.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (a, t.count(a)); t = t.replace(a, b)
rep('extern int    VTPpts=10;', 'extern int    VTPpts=10;' + NL +
    '// b17: ladder order type. 0 = sell stops below (b12), 1 = buy stops above, 2 = buy limits below, 3 = one market buy with LadderTP/LadderSL' + NL +
    'extern int    LadderMode=0;' + NL +
    '// b17: ladder regime gate. 0 = H1 below SMA (sell regime, b12), 1 = H1 above SMA (up regime)' + NL +
    'extern int    LadderRegime=0;' + NL +
    '// b17: take profit and stop loss points for ladder modes 1-3' + NL +
    'extern int    LadderTP=300;' + NL + 'extern int    LadderSL=300;')
old = 'void PlaceLadder(){ if(!SellRegimeOK()){ Print("LADDER skipped: regime up"); return; }'
new = 'void PlaceLadder(){ if(LadderMode!=0 || LadderRegime!=0){ PlaceLadder2(); return; } if(!SellRegimeOK()){ Print("LADDER skipped: regime up"); return; }'
rep(old, new)
helper = ('//---- b17 inverted ladder' + NL +
 'void PlaceLadder2(){ bool ok=(LadderRegime==0)?SellRegimeOK():BuyRegimeOK(); if(!ok){ Print("LADDER2 skipped: regime"); return; } if(!Guard(LotSize(LadderSL)*3,LadderSL)){ return; } int lv[3]; lv[0]=Ladder1; lv[1]=Ladder2; lv[2]=Ladder3; RefreshRates();' + NL +
 '   if(LadderMode==3){ int tm=OrderSend(Symbol(),OP_BUY,LotSize(LadderSL),Ask,slip,NormalizeDouble(Ask-LadderSL*p,Digits),NormalizeDouble(Ask+LadderTP*p,Digits),"7",magic,0,clrBlue); if(tm>0){ RatioLog2(tm); } else { Print("LADDER2 err ",GetLastError()); } return; }' + NL +
 '   for(int i=0;i<3;i++){ if(lv[i]<=0){ continue; } int ty=(LadderMode==1)?OP_BUYSTOP:OP_BUYLIMIT; double lvl=(LadderMode==1)?NormalizeDouble(Ask+lv[i]*p,Digits):NormalizeDouble(Ask-lv[i]*p,Digits);' + NL +
 '      int t=OrderSend(Symbol(),ty,LotSize(LadderSL),lvl,slip,NormalizeDouble(lvl-LadderSL*p,Digits),NormalizeDouble(lvl+LadderTP*p,Digits),"7",magic,TimeCurrent()+SellStopExpiryMin*60,clrBlue);' + NL +
 '      if(t>0){ Print("LADDER2 #",t," at ",DoubleToStr(lvl,Digits)); } else { Print("LADDER2 err ",GetLastError()); } } }' + NL)
rep('if(StringSubstr(OrderComment(),0,1)=="B"){ continue; }', 'if(StringSubstr(OrderComment(),0,1)=="B" || StringSubstr(OrderComment(),0,1)=="7"){ continue; }')
rep('StringSubstr(OrderComment(),0,1)!="B"){ n++; }', 'StringSubstr(OrderComment(),0,1)!="B" && StringSubstr(OrderComment(),0,1)!="7"){ n++; }')
i = t.find('void PlaceLadder(){'); t = t[:i] + helper + t[i:]
open(E + r'\Strong2010b_claude_b17.mq4', 'wb').write(t.encode('cp1252')); print('b17 ok')

