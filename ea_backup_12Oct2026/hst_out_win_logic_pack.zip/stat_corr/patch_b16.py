import re, sys
E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
src = open(E + r'\Strong2010b_claude_b15v.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in src else '\n'
t = src

def fix(s):
    return s.strip('\n').replace('\n', NL)

def after(anchor, text):
    global t
    i = t.find(anchor); assert i >= 0 and t.count(anchor) == 1, ('AFTER', anchor, t.count(anchor))
    j = t.find(NL, i + len(anchor)); j = len(t) if j < 0 else j + len(NL)
    t = t[:j] + fix(text) + NL + t[j:]

def before(anchor, text):
    global t
    assert t.count(anchor) == 1, ('BEFORE', anchor, t.count(anchor))
    i = t.find(anchor); ls = t.rfind(NL, 0, i); ls = 0 if ls < 0 else ls + len(NL)
    t = t[:ls] + fix(text) + NL + t[ls:]

def rep(anchor, text, n=1):
    global t
    assert t.count(anchor) == n, ('REPLACE', anchor, t.count(anchor))
    t = t.replace(anchor, text)

after('datetime parkUntil=0; int parkN=0;', open(r'C:\Users\endos\Desktop\hst_out\stat_corr\b15_e1.txt').read())
before('//---- b12 helpers', open(r'C:\Users\endos\Desktop\hst_out\stat_corr\b15_e2.txt').read())
rep('int OnInit(){ Print("init1");', 'int OnInit(){ Print("init1"); magic=MagicNumber;')
rep('void OnDeinit(const int reason){ ', 'void OnDeinit(const int reason){ DrawDeinit(); ')
rep('void OnTick(){ if(UseVirtualBuy==1){ VirtualMng(); }', 'void OnTick(){ if(UseChartDraw==1){ ChartDraw(); } NewsMng(); if(UseVirtualBuy==1){ VirtualMng(); }')
rep('double vPrice=0, vTP=0, vSL=0; int vHedged=0, vN=0;', 'double vPrice=0, vTP=0, vSL=0; int vHedged=0, vN=0;'+NL+'// b16: virtual buy exit. 0 = TP BuyTPpts (b15v), 1 = close at first profit of VFirstPts, 2 = TP VTPpts'+NL+'extern int    VExitMode=0;'+NL+'// b16: first-profit points for VExitMode 1'+NL+'extern int    VFirstPts=2;'+NL+'// b16: take profit points for VExitMode 2'+NL+'extern int    VTPpts=10;')
rep('if(Bid>=vTP || Bid<=vSL){ vPrice=0; return; } //b15', 'double vt=vTP; if(VExitMode==1){ vt=vPrice+VFirstPts*Point; } if(VExitMode==2){ vt=vPrice+VTPpts*Point; } if(Bid>=vt || Bid<=vSL){ vPrice=0; return; } //b15 b16')
rep('bool SellRegimeOK(){ if(!QuietOK()){ return(false); }', 'bool SellRegimeOK(){ if(!QuietOK()){ return(false); } if(UseNewsDayBlock==1 && NewsNear(NewsBlockHours)){ return(false); }')
rep('void PlaceSellStop(){ if(!SellRegimeOK()){ Print("SELLSTOP skipped: regime up"); return; }', 'void PlaceSellStop(){ if(!SellRegimeOK()){ Print("SELLSTOP skipped: regime up"); return; } if(!Guard(LotSize(SellStopSL),SellStopSL)){ return; }')
rep('void PlaceLadder(){ if(!SellRegimeOK()){ Print("LADDER skipped: regime up"); return; }', 'void PlaceLadder(){ if(!SellRegimeOK()){ Print("LADDER skipped: regime up"); return; } if(!Guard(LotSize(SellStopSL)*3,SellStopSL)){ return; }')
rep('OP_SELLSTOP,0.01,lvl,', 'OP_SELLSTOP,LotSize(SellStopSL),lvl,', 2)
rep('int ht=OrderSend(Symbol(),OP_SELL,0.01,Bid,', 'int ht=-1; if(Guard(LotSize(HedgeSL),HedgeSL)){ ht=OrderSend(Symbol(),OP_SELL,LotSize(HedgeSL),Bid,', 2)
rep('"8",magic,0,clrRed);', '"8",magic,0,clrRed); }', 2)
rep('RefreshRates(); return(OrderSend(Symbol(),OP_BUY,0.01,Ask,slip,', 'if(!Guard(LotSize(BuySLpts()),BuySLpts())){ return(-1); } RefreshRates(); return(OrderSend(Symbol(),OP_BUY,LotSize(BuySLpts()),Ask,slip,')
rep('ra15e2 "+DoubleToStr(RA15e2(),2); Print(ln); }', 'ra15e2 "+DoubleToStr(RA15e2(),2); Print(ln); FibCalc(); Print("RLOG3 #",ticket," fibS ",DoubleToStr(FibDistS(),0)," fibL ",DoubleToStr(FibDistL(),0)," conf ",IntegerToString(FibConf())); }')
open(E + r'\Strong2010b_claude_b16.mq4', 'wb').write(t.encode('cp1252'))
print('all 13 edits ok')


