E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b18.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('datetime ladderDue=0; bool ladderFire=false;', 'datetime ladderDue=0; bool ladderFire=false;' + NL + NL.join([
 '// b19: M15 low-reversal buy: close at the LowRevBars low with at most LowRevMaxBull bullish candles, market buy, own TP/SL, time stop',
 'extern bool   UseLowRevBuy=0;', 'extern int    LowRevBars=15;', 'extern int    LowRevMaxBull=6;',
 '// b19: H1 EMA cross buy: EMA fast crosses above EMA slow on the last closed H1 bar',
 'extern bool   UseEmaCrossBuy=0;', 'extern int    CrossFast=20;', 'extern int    CrossSlow=50;',
 '// b19: take profit, stop loss (points), time stop (hours) and max open orders for both new buys',
 'extern int    NBuyTP=300;', 'extern int    NBuySL=150;', 'extern int    NBuyHoldH=12;', 'extern int    NBuyMax=3;', '// b19: close new buys at/after this server hour to avoid swap (0 = off)', 'extern int    NBuyCloseHour=0;',
 'datetime nbLastM15=0, nbLastH1=0;']))
helper = NL.join([
 '//---- b19 new buys ("L" low reversal, "X" ema cross); own TP/SL, excluded from OrderMng buy handling',
 'int CountC(string c){ int n=0; for(int i=0;i<OrdersTotal();i++){ if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)){ if(OrderMagicNumber()==magic && OrderSymbol()==Symbol() && OrderType()==OP_BUY && StringSubstr(OrderComment(),0,1)==c){ n++; } } } return n; }',
 'void NBuySend(string c){ if(CountC(c)>=NBuyMax){ return; } if(!Guard(LotSize(NBuySL),NBuySL)){ return; } RefreshRates(); int t=OrderSend(Symbol(),OP_BUY,LotSize(NBuySL),Ask,slip,NormalizeDouble(Ask-NBuySL*p,Digits),NormalizeDouble(Ask+NBuyTP*p,Digits),c,magic,0,clrLime); if(t>0){ RatioLog2(t); } else { Print("NBUY ",c," err ",GetLastError()); } }',
 'void NBuyMng(){ for(int i=OrdersTotal()-1;i>=0;i--){ if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)){ string c=StringSubstr(OrderComment(),0,1); if(OrderMagicNumber()==magic && OrderSymbol()==Symbol() && OrderType()==OP_BUY && (c=="L" || c=="X") && (TimeCurrent()-OrderOpenTime()>=NBuyHoldH*3600 || (NBuyCloseHour>0 && TimeHour(TimeCurrent())>=NBuyCloseHour))){ if(!OrderClose(OrderTicket(),OrderLots(),Bid,slip,clrGray)){ Print("NBUY close err ",GetLastError()); } } } }',
 '   datetime m15=iTime(Symbol(),PERIOD_M15,0); if(UseLowRevBuy==1 && m15!=nbLastM15){ nbLastM15=m15; int lo=iLowest(Symbol(),PERIOD_M15,MODE_LOW,LowRevBars,1); int bull=0; for(int k=1;k<=LowRevBars;k++){ if(iClose(Symbol(),PERIOD_M15,k)>iOpen(Symbol(),PERIOD_M15,k)){ bull++; } }',
 '      if(iClose(Symbol(),PERIOD_M15,1)<=iLow(Symbol(),PERIOD_M15,lo) && bull<=LowRevMaxBull){ NBuySend("L"); } }',
 '   datetime h1=iTime(Symbol(),PERIOD_H1,0); if(UseEmaCrossBuy==1 && h1!=nbLastH1){ nbLastH1=h1; double f1=iMA(Symbol(),PERIOD_H1,CrossFast,0,MODE_EMA,PRICE_CLOSE,1), s1=iMA(Symbol(),PERIOD_H1,CrossSlow,0,MODE_EMA,PRICE_CLOSE,1), f2=iMA(Symbol(),PERIOD_H1,CrossFast,0,MODE_EMA,PRICE_CLOSE,2), s2=iMA(Symbol(),PERIOD_H1,CrossSlow,0,MODE_EMA,PRICE_CLOSE,2);',
 '      if(f1>s1 && f2<=s2){ NBuySend("X"); } } }', ''])
i = t.find('//---- b17 inverted ladder'); t = t[:i] + helper + t[i:]
rep('void OnTick(){ if(ladderDue>0', 'void OnTick(){ if(UseLowRevBuy==1 || UseEmaCrossBuy==1){ NBuyMng(); } if(ladderDue>0')
rep('if(StringSubstr(OrderComment(),0,1)=="B" || StringSubstr(OrderComment(),0,1)=="7"){ continue; }',
    'if(StringSubstr(OrderComment(),0,1)=="B" || StringSubstr(OrderComment(),0,1)=="7" || StringSubstr(OrderComment(),0,1)=="L" || StringSubstr(OrderComment(),0,1)=="X"){ continue; }')
rep('StringSubstr(OrderComment(),0,1)!="B" && StringSubstr(OrderComment(),0,1)!="7"){ n++; }',
    'StringSubstr(OrderComment(),0,1)!="B" && StringSubstr(OrderComment(),0,1)!="7" && StringSubstr(OrderComment(),0,1)!="L" && StringSubstr(OrderComment(),0,1)!="X"){ n++; }')
open(E + r'\Strong2010b_claude_b19.mq4', 'wb').write(t.encode('cp1252')); print('b19 ok')


