"""signal_lab.py - offline scan of new buy (and mirrored sell) entries on EURUSD history.
Costs: spread 2 pts + commission 9 pts = 11 pts per trade. 1 pt = 0.00001.
Exit: TP/SL in ATR14 multiples or fixed pts, worst case if both hit in one bar, time stop MaxHold bars.
Tune year 2017, judge 2018-2021 untouched. Output: hst_out/SIGNAL_LAB.txt"""
import struct, numpy as np, time, itertools
HST = r'C:\Users\endos\Desktop\hst_work'; OUT = r'C:\Users\endos\Desktop\hst_out\SIGNAL_LAB.txt'
COST = 11.0; PT = 1e-5; YEARS = [2017, 2018, 2019, 2020, 2021]
def load(tf):
    b = open(r'%s\EURUSD%d.hst' % (HST, tf), 'rb').read(); n = (len(b) - 148) // 60
    a = np.frombuffer(b, dtype=np.dtype([('t', '<i8'), ('o', '<f8'), ('h', '<f8'), ('l', '<f8'), ('c', '<f8'), ('v', '<i8'), ('s', '<i4'), ('rv', '<i8')]), count=n, offset=148)
    return a['t'].copy(), a['o'].copy(), a['h'].copy(), a['l'].copy(), a['c'].copy()
def ema(x, p):
    k = 2.0 / (p + 1); o = np.empty_like(x); o[0] = x[0]
    for i in range(1, len(x)): o[i] = o[i-1] + k * (x[i] - o[i-1])
    return o
def sma(x, p):
    c = np.cumsum(np.insert(x, 0, 0.0)); o = np.full_like(x, np.nan); o[p-1:] = (c[p:] - c[:-p]) / p; return o
def atr(h, l, c, p=14):
    tr = np.maximum(h[1:] - l[1:], np.maximum(abs(h[1:] - c[:-1]), abs(l[1:] - c[:-1]))); tr = np.insert(tr, 0, h[0] - l[0]); return ema(tr, 2 * p - 1)
def sim(o, h, l, c, idx, side, tpd, sld, hold):
    res = np.empty(len(idx))
    for j, i in enumerate(idx):
        e = o[i + 1] if i + 1 < len(o) else c[i]
        tp = e + side * tpd[j]; sl = e - side * sld[j]; r = None
        for k in range(i + 1, min(i + 1 + hold, len(c))):
            if side > 0:
                if l[k] <= sl: r = -sld[j]; break
                if h[k] >= tp: r = tpd[j]; break
            else:
                if h[k] >= sl: r = -sld[j]; break
                if l[k] <= tp: r = tpd[j]; break
        if r is None: k = min(i + hold, len(c) - 1); r = side * (c[k] - e)
        res[j] = r / PT - COST
    return res
lines = []; t0 = time.time()
for tf, hold in ((15, 48), (60, 24)):
    t, o, h, l, c = load(tf)
    yr = np.array([time.gmtime(x).tm_year for x in t]); A = atr(h, l, c)
    # H1 regime mapped onto this timeframe: close vs SMA(1200 H1) ~ SMA(1200*60/tf)
    rp = int(1200 * 60 / tf); reg = np.where(np.isnan(sma(c, rp)), 0, np.sign(c - np.nan_to_num(sma(c, rp))))
    E = {p: ema(c, p) for p in (9, 20, 30, 50)}; S = {p: sma(c, p) for p in (20, 30, 50)}
    up15 = np.convolve((c > o).astype(float), np.ones(15), 'full')[:len(c)]
    lo15 = np.array([c[i] <= l[max(0, i-14):i+1].min() for i in range(len(c))]); hi15 = np.array([c[i] >= h[max(0, i-14):i+1].max() for i in range(len(c))])
    sig = {}
    for p in (20, 30, 50):
        sig['ema%d_reclaim' % p] = (c > E[p]) & (np.roll(c, 1) <= np.roll(E[p], 1))
        sig['ema%d_touch_up' % p] = (l <= E[p]) & (c > E[p]) & (E[p] > np.roll(E[p], 5))
    for f, s in (('e9', 'e30'), ('e20', 's50'), ('s20', 's50'), ('e20', 'e50')):
        a = E[int(f[1:])] if f[0] == 'e' else S[int(f[1:])]; b2 = E[int(s[1:])] if s[0] == 'e' else S[int(s[1:])]
        sig['x_%s_%s' % (f, s)] = (a > b2) & (np.roll(a, 1) <= np.roll(b2, 1))
    sig['c15_bull10'] = (up15 >= 10) & (np.roll(up15, 1) < 10)
    sig['c15_low_rev'] = lo15 & (up15 <= 6)
    sig['c15_high_brk'] = hi15 & (up15 >= 9)
    exits = {'atr1:1': (1, 1), 'atr2:1': (2, 1), 'atr1:2': (1, 2), 'pts150:150': None, 'pts300:150': None}
    for name, m in sig.items():
        m = m.copy(); m[:max(rp, 60)] = False; m[-hold-2:] = False
        for side in (1, -1):  # buy, and the mirrored sell on the same signal
            for rf in ('any', 'up', 'dn'):
                mm = m & ((reg > 0) if rf == 'up' else (reg < 0) if rf == 'dn' else True) & np.isin(yr, YEARS)
                idx = np.nonzero(mm)[0]
                if len(idx) < 150: continue
                for en, ex in exits.items():
                    if ex: tpd, sld = A[idx] * ex[0], A[idx] * ex[1]
                    else: a_, b_ = map(int, en[3:].split(':')); tpd = np.full(len(idx), a_ * PT); sld = np.full(len(idx), b_ * PT)
                    r = sim(o, h, l, c, idx, side, tpd, sld, hold); ys = yr[idx]
                    per = {y: (r[ys == y].mean() if (ys == y).sum() >= 20 else np.nan, int((ys == y).sum())) for y in YEARS}
                    pos = sum(1 for y in YEARS[1:] if per[y][0] > 0)
                    lines.append((per[2017][0], 'M%d %-4s %-3s %-16s %-10s n=%5d win=%4.1f%% avg=%+6.1f | %s | oos+ %d/4' % (tf, 'BUY' if side > 0 else 'SELL', rf, name, en, len(r), 100 * (r > 0).mean(), r.mean(),
                        ' '.join('%d:%+.1f(%d)' % (y % 100, per[y][0], per[y][1]) for y in YEARS), pos), pos, side))
    print('tf', tf, 'done', round(time.time() - t0), 's')
good = [x for x in lines if x[0] == x[0] and x[0] > 0 and x[2] >= 3]
good.sort(key=lambda x: (-x[2], -x[0]))
hdr = ['SIGNAL_LAB: avg net points per trade after 11-pt cost (spread 2 + comm 9). Tune 2017, OOS 2018-2021.',
       'Candidates: 2017 avg > 0 AND >= 3 of 4 OOS years positive:'] + [x[1] for x in good[:40]] + ['', 'Top 2017 buys regardless of OOS:'] + [x[1] for x in sorted([x for x in lines if x[3] > 0 and x[0] == x[0]], key=lambda x: -x[0])[:15]]
open(OUT, 'w').write('\n'.join(hdr + ['', 'ALL:'] + [x[1] for x in lines]))
print('\n'.join(hdr))
