"""bigloss.py - what separates big-loss sells from winners (b12 ladder runs, same sell logic as b18).
Big loss = net <= -2.0 USD at 0.01 lot (-200 pts or worse). Features from RLOG2 at entry."""
import re, os, html, collections, statistics as st
OUT = r'C:\Users\endos\Desktop\hst_out'
R2 = re.compile(r'RLOG2 #(\d+) tf15 adx ([-\d.]+) ([-\d.]+) ([-\d.]+) cci ([-\d.]+) rr ([-\d.]+) \| tf60 adx ([-\d.]+) ([-\d.]+) ([-\d.]+) cci ([-\d.]+) rr ([-\d.]+) \| volup (\d+) voldn (\d+) hour (\d+)')
F = ['adx15', 'pdi15', 'mdi15', 'cci15', 'rr15', 'adx60', 'pdi60', 'mdi60', 'cci60', 'rr60', 'volratio', 'hour', 'dur_h']
T = []
for y in (2017, 2019, 2020, 2021):
    tag = 'b12_ladder_%d' % y
    h = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', h):
        c = [html.unescape(re.sub('<[^>]+>', '', x)).strip() for x in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(c) < 9 or not c[0].isdigit(): continue
        d = od.setdefault(c[3], {})
        if c[2] in ('buy', 'sell') and 'side' not in d: d['side'] = c[2]; d['t0'] = c[1]; d['px'] = float(c[5])
        if re.search(r't/p|s/l|close', c[2]): d['net'] = float(c[8]) - 0.09; d['t1'] = c[1]; d['how'] = c[2]
    import time
    def ts(s): return time.mktime(time.strptime(s[:16], '%Y.%m.%d %H:%M'))
    for l in open(os.path.join(OUT, 'small_' + tag + '.log'), encoding='utf-8'):
        m = R2.search(l)
        if not m: continue
        d = od.get(m.group(1))
        if not d or d.get('side') != 'sell' or 'net' not in d: continue
        v = [float(x) for x in m.groups()[1:11]]; up, dn = float(m.group(12)), float(m.group(13))
        T.append(dict(zip(F, v + [up / dn if dn else 9.9, float(m.group(14)), (ts(d['t1']) - ts(d['t0'])) / 3600.0]), year=y, net=d['net'], how=d['how'], t0=d['t0'], t1=d['t1'], px=d['px']))
big = [t for t in T if t['net'] <= -2.0]; win = [t for t in T if t['net'] > 0]
L = ['BIGLOSS: sells from b12_ladder 2017/19/20/21 (same sell logic as b18). n=%d, big losses (<= -200 pts net) %d, winners %d' % (len(T), len(big), len(win)),
     'by year: ' + ' '.join('%d: %d/%d big' % (y, sum(t['year'] == y for t in big), sum(t['year'] == y for t in T)) for y in (2017, 2019, 2020, 2021)),
     'exit type of big losses: ' + str(collections.Counter(t['how'] for t in big)), '',
     'feature      median_big  median_win   big-rate by quintile Q1..Q5 (share of trades in that quintile that are big losses)']
base = len(big) / len(T)
for f in F:
    vals = sorted(t[f] for t in T); e = [vals[int(len(vals) * q / 5)] for q in range(1, 5)]
    g = collections.defaultdict(list)
    for t in T: g[sum(t[f] > x for x in e)].append(t['net'] <= -2.0)
    rates = ' '.join('%4.0f%%' % (100.0 * sum(g[k]) / len(g[k])) for k in range(5) if g[k])
    L.append('%-10s %10.3g %11.3g   %s   edges %s' % (f, st.median(t[f] for t in big), st.median(t[f] for t in win), rates, ' '.join('%.3g' % x for x in e)))
L.append(''); L.append('overall big-loss rate %.1f%%' % (100 * base))
# simple 2-feature rule search: block sells where feature a in worst quintile AND feature b in worst quintile
import struct, bisect, calendar, numpy as np
b = open(r'C:\Users\endos\Desktop\hst_work\EURUSD1.hst', 'rb').read(); n = (len(b) - 148) // 60
a = np.frombuffer(b, dtype=np.dtype([('t','<i8'),('o','<f8'),('h','<f8'),('l','<f8'),('c','<f8'),('v','<i8'),('s','<i4'),('rv','<i8')]), count=n, offset=148)
tt = a['t']; hh = a['h']
def cts(s): return calendar.timegm(time.strptime(s[:16], '%Y.%m.%d %H:%M'))
for t in T:
    i0 = np.searchsorted(tt, cts(t['t0'])); i1 = max(i0 + 1, np.searchsorted(tt, cts(t['t1'])) + 1)
    t['mae'] = (hh[i0:i1].max() - t['px']) / 1e-5 if i1 > i0 else 0
mw = sorted(t['mae'] for t in T if t['net'] > 0); ml = sorted(t['mae'] for t in T if t['net'] <= 0)
q = lambda v, p: v[min(len(v) - 1, int(len(v) * p))]
L.append(''); L.append('MAE (max adverse pts, from M1): winners median %.0f p75 %.0f p90 %.0f | losers median %.0f p90 %.0f' % (q(mw, .5), q(mw, .75), q(mw, .9), q(ml, .5), q(ml, .9)))
L.append('share of winners that went >= 100 / 150 / 200 pts against first: %.0f%% / %.0f%% / %.0f%%' % tuple(100.0 * sum(x >= k for x in mw) / len(mw) for k in (100, 150, 200)))
L.append(''); L.append('BLOCK RULES (net pts per year at 0.01 lot = USD*100; tune 2017, judge 19/20/21):')
rules = {'none': lambda t: False, 'adx15>27.7': lambda t: t['adx15'] > 27.7, 'adx15>24': lambda t: t['adx15'] > 24, 'hour<2': lambda t: t['hour'] < 2, 'hour<7': lambda t: t['hour'] < 7,
         'pdi60>21.5': lambda t: t['pdi60'] > 21.5, 'adx15>27.7|hour<2': lambda t: t['adx15'] > 27.7 or t['hour'] < 2, 'adx15>24|pdi60>21.5': lambda t: t['adx15'] > 24 or t['pdi60'] > 21.5}
for rn, f in rules.items():
    L.append('%-22s ' % rn + ' | '.join('%d: %+6.0f (%d)' % (y, 100 * sum(t['net'] for t in T if t['year'] == y and not f(t)), sum(1 for t in T if t['year'] == y and not f(t))) for y in (2017, 2019, 2020, 2021)))
open(os.path.join(OUT, 'BIGLOSS.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
