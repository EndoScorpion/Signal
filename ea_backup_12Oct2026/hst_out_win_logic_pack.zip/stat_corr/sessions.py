"""sessions.py - b20 (block on) sell results by trading session of the entry, server time (FXOpen ~GMT+2/+3)."""
import re, os, html, time, calendar
OUT = r'C:\Users\endos\Desktop\hst_out'
TAGS = [('2011', 'b20_blk_2011'), ('2012', 'b20_blk_2012'), ('2017', 'b20_blk_2017'), ('2019', 'b20_blk_2019'), ('2020', 'b20_blk_2020'),
        ('2021', 'b20_blk_2021'), ('22', 'legs_2022'), ('25-26', 'legs_2526')]
SESS = [('off 23-02', range(23, 26)), ('Asia 02-09', range(2, 9)), ('London open 09-11', range(9, 11)), ('London mid 11-14', range(11, 14)),
        ('NY open/overlap 14-17', range(14, 17)), ('NY mid 17-20', range(17, 20)), ('NY end 20-23', range(20, 23))]
def sess(h):
    for n, r in SESS:
        if h in r or h + 24 in r: return n
R = {}
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 'h' not in d: d['h'] = int(x[1][11:13])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for d in od.values():
        if 'h' in d and 'net' in d: R.setdefault(sess(d['h']), {}).setdefault(lab, []).append(d['net'])
L = ['SESSIONS: b20 block-on sells by entry session (server time). pts after commission; per period: total (trades, win%)', '']
for n, _ in SESS:
    row = R.get(n, {}); allv = [v for p in row.values() for v in p]
    if not allv: L.append('%-22s no trades (blocked or none)' % n); continue
    pos = sum(1 for lab, _ in TAGS if row.get(lab) and sum(row[lab]) > 0); have = sum(1 for lab, _ in TAGS if row.get(lab))
    L.append('%-22s all: %+7.0f n=%5d win=%4.1f%% avg=%+5.1f | positive in %d/%d periods' % (n, sum(allv), len(allv), 100.0 * sum(v > 0 for v in allv) / len(allv), sum(allv) / len(allv), pos, have))
    L.append('   ' + ' | '.join('%s %+.0f(%d,%d%%)' % (lab, sum(row[lab]), len(row[lab]), 100 * sum(v > 0 for v in row[lab]) // len(row[lab])) for lab, _ in TAGS if row.get(lab)))
open(os.path.join(OUT, 'SESSIONS.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
