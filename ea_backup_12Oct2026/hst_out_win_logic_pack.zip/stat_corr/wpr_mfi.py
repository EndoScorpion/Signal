"""wpr_mfi.py - Williams %R, Market Facilitation Index and phase-space (velocity/acceleration) filters on b22 sells."""
import re, os, html, numpy as np
exec(open(r'C:\Users\endos\Desktop\hst_out\stat_corr\recombine.py').read().split('base = {')[0])
OUT = r'C:\Users\endos\Desktop\hst_out'
TT = []
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in d: d['t0'] = ts(x[1])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for d in od.values():
        if 't0' in d and 'net' in d: TT.append(dict(p=lab, net=d['net'], i=np.searchsorted(M15['t'], d['t0']) - 1, j=np.searchsorted(H1['t'], d['t0']) - 1))
def wpr(h, l, c, k, n): hh = h[k-n+1:k+1].max(); ll = l[k-n+1:k+1].min(); return -100 * (hh - c[k]) / (hh - ll) if hh > ll else -50
src = {'M15': (M15['h'], M15['l'], M15['c'], M15['v'], 'i'), 'H1': (h1h, h1l, h1c, H1['v'], 'j')}
for t in TT:
    for tf, (h, l, c, v, key) in src.items():
        k = t[key]
        for n in (7, 14, 28):
            t['w%s%d' % (tf, n)] = wpr(h, l, c, k, n); t['w%s%dp' % (tf, n)] = wpr(h, l, c, k - 1, n)
        mfi = (h[k] - l[k]) / max(v[k], 1); mfp = (h[k-1] - l[k-1]) / max(v[k-1], 1)
        t['mfi_' + tf] = ('green' if mfi > mfp and v[k] > v[k-1] else 'fade' if mfi < mfp and v[k] < v[k-1] else 'fake' if mfi > mfp else 'squat')
        vel = (c[k] - c[k-5]) / c[k] * 1e4; acc = vel - (c[k-5] - c[k-10]) / c[k-5] * 1e4
        cv = [(c[q] - c[q-5]) / c[q] * 1e4 for q in range(k-100, k)]; ca = [cv[q] - cv[q-5] for q in range(5, len(cv))]
        t['ps_' + tf] = np.hypot(vel - np.mean(cv), acc - np.mean(ca)) / (np.std(cv) + 1e-9); t['vel_' + tf] = vel
base = {k: sum(t['net'] for t in TT if t['p'] == k) for k, _ in TAGS}
L = ['WPR / MFI / PHASE-SPACE on b22 sells, pts after commission. base: ' + ' | '.join('%s %+.0f' % (k, base[k]) for k, _ in TAGS), '']; surv = []
def score(n, f):
    r = {k: sum(t['net'] for t in TT if t['p'] == k and f(t)) for k, _ in TAGS}; keep = sum(1 for t in TT if f(t)) / len(TT)
    better = sum(r[k] > base[k] for k, _ in TAGS)
    s = '%-34s ' % n + ' | '.join('%s %+.0f' % (k, r[k]) for k, _ in TAGS) + '  better %d/8 kept %.0f%%' % (better, 100 * keep); L.append(s)
    if better >= 5 and keep >= 0.6: surv.append(s)
for tf in ('M15', 'H1'):
    for n in (7, 14, 28):
        w = 'w%s%d' % (tf, n)
        score('BLOCK %%R%s(%d) < -80 (oversold)' % (tf, n), lambda t, w=w: not t[w] < -80)
        score('BLOCK %%R%s(%d) > -20 (overbought)' % (tf, n), lambda t, w=w: not t[w] > -20)
        score('REQUIRE %%R%s(%d) cross down -20' % (tf, n), lambda t, w=w: t[w + 'p'] > -20 >= t[w])
for tf in ('M15', 'H1'):
    for st in ('green', 'fade', 'fake', 'squat'): score('BLOCK MFI %s %s' % (tf, st), lambda t, tf=tf, st=st: t['mfi_' + tf] != st)
    score('BLOCK phase-space dist > 2 sd (%s)' % tf, lambda t, tf=tf: not t['ps_' + tf] > 2)
    score('BLOCK velocity up (%s)' % tf, lambda t, tf=tf: not t['vel_' + tf] > 0)
L += ['', 'SURVIVORS (>=5/8 better, >=60% kept):'] + (surv or ['none'])
open(os.path.join(OUT, 'WPR_MFI.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
