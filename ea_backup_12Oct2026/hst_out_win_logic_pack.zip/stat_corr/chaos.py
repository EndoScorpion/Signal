"""chaos.py - EMA-trend block neighbours + chaos / Bill Williams features as filters on b22 sells. Closed-bar info only."""
import re, os, html, time, calendar, numpy as np
exec(open(r'C:\Users\endos\Desktop\hst_out\stat_corr\recombine.py').read().split('base = {')[0])   # reuse loaders and trade list T (with px/t0 added below)
OUT = r'C:\Users\endos\Desktop\hst_out'
# rebuild trades with entry index so we can compute more features
TT = []
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in d: d['t0'] = ts(x[1])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for d in od.values():
        if 't0' in d and 'net' in d: TT.append(dict(p=lab, net=d['net'], i=np.searchsorted(M15['t'], d['t0']) - 1, j=np.searchsorted(H1['t'], d['t0']) - 1))
mc = M15['c']; mh, ml = M15['h'], M15['l']; med = (h1h + h1l) / 2
def sma(x, p): c = np.cumsum(np.insert(x, 0, 0.0)); o = np.full(len(x), np.nan); o[p-1:] = (c[p:] - c[:-p]) / p; return o
ao = sma(med, 5) - sma(med, 34); ac = ao - sma(np.nan_to_num(ao), 5)
jaw, teeth, lips = sma(med, 13), sma(med, 8), sma(med, 5)   # Alligator (SMA approximation, shifts 8/5/3 applied by index)
EM = {(f, s): (ema(h1c, f), ema(h1c, s)) for f, s in ((20, 50), (16, 40), (24, 60))}
def hurst(x):
    r = np.diff(np.log(x)); n = len(r); out = []
    for m in (8, 16, 32, 64):
        k = n // m; rs = []
        for q in range(k):
            s = r[q*m:(q+1)*m]; z = np.cumsum(s - s.mean()); sd = s.std()
            if sd > 0: rs.append((z.max() - z.min()) / sd)
        if rs: out.append((np.log(m), np.log(np.mean(rs))))
    a = np.array(out); return np.polyfit(a[:, 0], a[:, 1], 1)[0] if len(a) > 1 else np.nan
def katz(x):
    d = np.abs(np.diff(x)); L = d.sum(); a = d.mean(); dist = np.max(np.abs(x - x[0]))
    return np.log10(L / a) / (np.log10(dist / a) + np.log10(L / a) - np.log10(L / a) + np.log10(L / a) * 0 + 0) if dist > 0 and a > 0 else np.nan
def shannon(x):
    r = np.diff(x); h, _ = np.histogram(r, bins=10); p = h[h > 0] / h.sum(); return -(p * np.log2(p)).sum()
def lyap(x):  # divergence proxy: mean log growth of nearest-neighbour distance over 5 steps on 1-D embedding of returns
    r = np.diff(np.log(x)); e = np.column_stack([r[:-2], r[1:-1], r[2:]]); n = len(e) - 6; s = []
    for a in range(0, n, 5):
        dd = np.linalg.norm(e[:n] - e[a], axis=1); dd[max(0, a-3):a+4] = np.inf; b = int(np.argmin(dd))
        d0 = dd[b]; d1 = np.linalg.norm(e[a+5] - e[b+5]) if b + 5 < len(e) else np.nan
        if d0 > 0 and d1 == d1 and d1 > 0: s.append(np.log(d1 / d0))
    return np.mean(s) if s else np.nan
for t in TT:
    i, j = t['i'], t['j']; w = mc[i-128:i+1]
    t['hurst'] = hurst(w); t['katz'] = katz(mc[i-63:i+1]); t['ent'] = shannon(mc[i-96:i+1]); t['lyap'] = lyap(mc[i-200:i+1])
    t['ao'] = ao[j]; t['ac'] = ac[j]; t['allig_up'] = lips[j-3] > teeth[j-5] > jaw[j-8]; t['allig_dn'] = lips[j-3] < teeth[j-5] < jaw[j-8]
    t['frac_up'] = h1h[j-2] == h1h[j-4:j+1].max()   # fractal high confirmed 2 bars ago (Williams up fractal)
    for k, (f, s) in EM.items(): t['up%d_%d' % k] = f[j] > s[j]
base = {k: sum(t['net'] for t in TT if t['p'] == k) for k, _ in TAGS}; nb = {k: sum(1 for t in TT if t['p'] == k) for k, _ in TAGS}
L = ['CHAOS + EMA neighbours on b22 sells (pts after commission). base: ' + ' | '.join('%s %+.0f' % (k, base[k]) for k, _ in TAGS), '']
surv = []
def score(n, f):
    r = {k: sum(t['net'] for t in TT if t['p'] == k and f(t)) for k, _ in TAGS}; c = sum(1 for t in TT if f(t))
    better = sum(r[k] > base[k] for k, _ in TAGS); keep = c / len(TT)
    s = '%-28s ' % n + ' | '.join('%s %+.0f' % (k, r[k]) for k, _ in TAGS) + '  better %d/8 kept %.0f%%' % (better, 100 * keep); L.append(s)
    if better >= 5 and keep >= 0.6: surv.append(s)
for k in EM: score('BLOCK H1 EMA%d>EMA%d' % k, lambda t, k=k: not t['up%d_%d' % k])
md = {f: np.nanmedian([t[f] for t in TT]) for f in ('hurst', 'katz', 'ent', 'lyap')}
L.append('feature medians: ' + ', '.join('%s %.3f' % kv for kv in md.items()))
for f, th in (('hurst', 0.5), ('katz', round(md['katz'], 1)), ('ent', round(md['ent'], 1)), ('lyap', 0.0)):
    score('ALLOW %s < %s' % (f, th), lambda t, f=f, th=th: t[f] < th); score('ALLOW %s > %s' % (f, th), lambda t, f=f, th=th: t[f] > th)
score('BLOCK AO > 0', lambda t: not t['ao'] > 0); score('BLOCK AC > 0', lambda t: not t['ac'] > 0)
score('BLOCK Alligator up', lambda t: not t['allig_up']); score('REQUIRE Alligator down', lambda t: t['allig_dn'])
score('BLOCK fresh up-fractal', lambda t: not t['frac_up'])
score('BLOCK EMA20>50 + BLOCK AO>0', lambda t: not t['up20_50'] and not t['ao'] > 0)
score('BLOCK EMA20>50 + Hurst<0.5', lambda t: not t['up20_50'] and t['hurst'] < 0.5)
L += ['', 'SURVIVORS (>=5/8 better, >=60% kept):'] + (surv or ['none'])
open(os.path.join(OUT, 'CHAOS.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
