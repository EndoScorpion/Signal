E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b22.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('extern int    DayBlock=-1;', 'extern int    DayBlock=-1;' + NL + '// b23: trend block: no new sell orders while H1 EMA(TrendFast) is above EMA(TrendSlow) on the last closed bar' + NL + 'extern bool   UseTrendBlock=0;' + NL + 'extern int    TrendFast=20;' + NL + 'extern int    TrendSlow=50;')
rep('if(DayBlock>=0 && DayOfWeek()==DayBlock){ return(false); }', 'if(DayBlock>=0 && DayOfWeek()==DayBlock){ return(false); } if(UseTrendBlock==1 && iMA(Symbol(),PERIOD_H1,TrendFast,0,MODE_EMA,PRICE_CLOSE,1)>iMA(Symbol(),PERIOD_H1,TrendSlow,0,MODE_EMA,PRICE_CLOSE,1)){ return(false); }')
open(E + r'\Strong2010b_claude_b23.mq4', 'wb').write(t.encode('cp1252')); print('b23 ok')
