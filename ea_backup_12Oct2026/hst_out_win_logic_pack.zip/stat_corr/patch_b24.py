E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b22.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('extern int    DayBlock=-1;', 'extern int    DayBlock=-1;' + NL + '// b24: chaos regime module (all switches inside default off), see hst_out\\ChaosRegime_MATH.txt' + NL + '#include <ChaosRegime.mqh>')
rep('if(DayBlock>=0 && DayOfWeek()==DayBlock){ return(false); }', 'if(DayBlock>=0 && DayOfWeek()==DayBlock){ return(false); } if(!CR_SellAllowed()){ return(false); }')
rep('void OnTick(){ if(UseCounterHedge==1)', 'void OnTick(){ if(CR_Circuit(magic)){ return; } CR_BESlide(magic); if(UseCounterHedge==1)')
rep('double LotSize(int slpts){ if(UseLotSim!=1){ return(0.01); }', 'double LotSize(int slpts){ if(UseLotSim!=1){ return(CR_AdaptiveLot(magic,0.01)); }')
open(E + r'\Strong2010b_claude_b24.mq4', 'wb').write(t.encode('cp1252')); print('b24 ok')

