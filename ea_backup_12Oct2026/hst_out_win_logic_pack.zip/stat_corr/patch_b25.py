E = r'C:\Users\endos\AppData\Roaming\MetaQuotes\Terminal\6278E353D77D4E501C6775ACEC85F415\MQL4\Experts'
t = open(E + r'\Strong2010b_claude_b24.mq4', 'rb').read().decode('cp1252')
NL = '\r\n' if '\r\n' in t else '\n'
def rep(a, b):
    global t
    assert t.count(a) == 1, (a, t.count(a)); t = t.replace(a, b)
rep('#include <ChaosRegime.mqh>', '#include <ChaosRegime.mqh>' + NL + '// b25: overbought block: no new sell orders while Williams %R(WprN) on WprTF (minutes) is above WprLevel (last closed bar)' + NL + 'extern bool   UseWprBlock=0;' + NL + 'extern int    WprTF=240;' + NL + 'extern int    WprN=14;' + NL + 'extern double WprLevel=-20;')
rep('if(!CR_SellAllowed()){ return(false); }', 'if(!CR_SellAllowed()){ return(false); } if(UseWprBlock==1 && iWPR(Symbol(),WprTF,WprN,1)>WprLevel){ return(false); }')
open(E + r'\Strong2010b_claude_b25.mq4', 'wb').write(t.encode('cp1252')); print('b25 ok')
