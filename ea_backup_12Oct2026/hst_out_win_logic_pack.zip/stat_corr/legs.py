"""legs.py - per-leg results of b20 block-on runs, tickets tagged from journal prints."""
import re, os, html, collections
OUT = r'C:\Users\endos\Desktop\hst_out'
L = ['LEGS: b20 block-on, spread 2, pts after commission (0.09 USD per 0.01 lot = 9 pts). type: L20/L50/L100 ladder legs, SS sell stop, H hedge, VH virtual hedge']
tot = collections.defaultdict(dict)
for tag in ('legs_2011', 'legs_2012', 'legs_2019', 'legs_2021', 'legs_2022', 'legs_2526'):
    lp = os.path.join(OUT, 'legs_%s.log' % tag); hp = os.path.join(OUT, tag + '.htm')
    if not (os.path.exists(lp) and os.path.exists(hp)): L.append(tag + ' missing'); continue
    typ = {}; leg = 0; last = None
    for l in open(lp, encoding='latin-1'):
        m = re.search(r'(LADDER|VHEDGE sell|HEDGE sell|SELLSTOP) #(\d+)', l)
        if not m: continue
        k, tk = m.group(1), m.group(2)
        if k == 'LADDER':
            stamp = l.split('Strong')[0][-20:]
            leg = leg + 1 if stamp == last else 1; last = stamp
            typ[tk] = 'L' + ('20', '50', '100')[min(leg, 3) - 1]
        else: typ[tk] = {'SELLSTOP': 'SS', 'HEDGE sell': 'H', 'VHEDGE sell': 'VH'}[k]
    h = open(hp, 'rb').read().decode('latin-1'); g = collections.defaultdict(list)
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', h):
        c = [html.unescape(re.sub('<[^>]+>', '', x)).strip() for x in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(c) >= 9 and c[0].isdigit() and re.search(r't/p|s/l|close', c[2]):
            g[typ.get(c[3], '?')].append((float(c[8]) - 9 * float(c[4])) * 100)
    parts = []
    for k in ('L20', 'L50', 'L100', 'SS', 'H', 'VH', '?'):
        v = g.get(k)
        if v: parts.append('%s n=%d win=%.0f%% tot=%+.0f' % (k, len(v), 100.0 * sum(x > 0 for x in v) / len(v), sum(v))); tot[k][tag] = sum(v)
    L.append('%-10s total %+7.0f | ' % (tag, sum(sum(v) for v in g.values())) + ' | '.join(parts))
L.append(''); L.append('DROP-ONE-LEG estimate (total minus that leg, per period):')
names = ('legs_2011', 'legs_2012', 'legs_2019', 'legs_2021', 'legs_2022', 'legs_2526')
for k in ('L20', 'L50', 'L100', 'SS', 'H', 'VH'):
    if k in tot: L.append('drop %-4s ' % k + ' | '.join('%s %+.0f' % (n[5:], -tot[k].get(n, 0)) for n in names) + '   (change vs b20)')
open(os.path.join(OUT, 'LEGS.txt'), 'w').write('\n'.join(L)); print('\n'.join(L))
