﻿"""mksets24.py - b24 .set files with EVERY extern listed (tester keeps stale inputs otherwise).
base = b22_thu.set (= b23 base) + all b23/b24 flags off; each variant overrides a few keys."""
import re
SRC = r'C:\Users\endos\Desktop\hst_out\Strong2010b_claude_b28.mq4'
T = r'C:\Users\endos\Desktop\mt4_tester\tester'
src = open(SRC, encoding='latin-1').read()
defaults, order = {}, []
for m in re.finditer(r'^\s*extern\s+(\w+)\s+([^;]+);', src, re.M):
    for part in m.group(2).split(','):
        k, v = [x.strip() for x in part.split('=', 1)]
        defaults[k] = {'true': '1', 'false': '0'}.get(v.strip('"'), v.strip('"')); order.append(k)

def load(name):
    d = {}
    for l in open(T + '\\' + name, encoding='latin-1'):
        if '=' in l: k, v = l.strip().split('=', 1); d[k] = v
    return d

BASE = dict(defaults); BASE.update(load('b22_thu.set'))
BASE.update({'SellBEStart': '0', 'SellBELock': '10', 'SellCCIMax': '999'})   # b23 flags off; b24 flags are off by default

V = {
 'b28_base': {},
 'b28_wpr50': {'UseWprGate': '1', 'WprMax': '-50'},
 'b28_wpr80': {'UseWprGate': '1', 'WprMax': '-80'},
 'b28_wprob20': {'UseWprGate': '2', 'WprMin': '-20'},
 'b28_alli': {'UseAlligatorGate': '1'},
 'b28_ao': {'UseAOGate': '1'},
 'b28_ac': {'UseACGate': '1'},
 'b28_chop618': {'UseChopGate': '1', 'ChopMax': '61.8'},
 'b28_chop50': {'UseChopGate': '1', 'ChopMax': '50'},
 'b28_z1': {'UseZGate': '1', 'ZMax': '1.0'},
 'b28_rng100': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0'},
 'b28_atrb30': {'UseAtrBrackets': '1', 'AtrSLMult': '3.0', 'AtrRR': '1.0'},
 'b28_addiv': {'UseVolumeDivergenceGuard': '1'},
}
for n, o in V.items():
    d = dict(BASE); d.update(o)
    bad = [k for k in d if k not in defaults]
    if bad: print('WARN keys not in EA', n, bad)
    with open(T + '\\' + n + '.set', 'w', newline='\r\n') as f:
        for k in order: f.write('%s=%s\n' % (k, d[k]))
print(len(V), 'sets,', len(order), 'inputs each')


