"""era.py - why b20 (block on) loses in 2011/2012: monthly net vs market features, trailing era filters, data check."""
import re, os, html, time, calendar, collections, numpy as np
OUT = r'C:\Users\endos\Desktop\hst_out'; HST = r'C:\Users\endos\Desktop\hst_work'
def load(tf):
    b = open(r'%s\EURUSD%d.hst' % (HST, tf), 'rb').read(); n = (len(b) - 148) // 60
    a = np.frombuffer(b, dtype=np.dtype([('t','<i8'),('o','<f8'),('h','<f8'),('l','<f8'),('c','<f8'),('v','<i8'),('s','<i4'),('rv','<i8')]), count=n, offset=148)
    return a
H = load(60); t, h, l, c = H['t'], H['h'], H['l'], H['c']
tr = np.maximum(h[1:] - l[1:], np.maximum(abs(h[1:] - c[:-1]), abs(l[1:] - c[:-1]))); tr = np.insert(tr, 0, h[0] - l[0])
atrp = np.convolve(tr, np.ones(14) / 14, 'full')[:len(tr)] / c * 100          # H1 ATR14 % of price
atr20d = np.convolve(atrp, np.ones(480) / 480, 'full')[:len(atrp)]             # trailing 20 trading days
cs = np.cumsum(np.insert(c, 0, 0)); sma = np.full(len(c), np.nan); sma[1199:] = (cs[1200:] - cs[:-1200]) / 1200
mom = np.full(len(c), np.nan); mom[480:] = (c[480:] - c[:-480]) / c[:-480] * 100   # trailing 20-day % change
def ts(s): return calendar.timegm(time.strptime(s[:16], '%Y.%m.%d %H:%M'))
trades = []
for y in (2011, 2012, 2017, 2019, 2020, 2021):
    hd = open(os.path.join(OUT, 'b20_blk_%d.htm' % y), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in d: d['t0'] = ts(x[1])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100; d['t1'] = ts(x[1])
    for d in od.values():
        if 't0' in d and 'net' in d:
            i = max(0, np.searchsorted(t, d['t0']) - 1)
            trades.append(dict(y=y, t0=d['t0'], t1=d['t1'], net=d['net'], atr=atr20d[i], mom=mom[i], below=float(c[i] < sma[i]) if sma[i] == sma[i] else np.nan))
trades.sort(key=lambda d: d['t0'])
L = ['ERA ANALYSIS b20 block on, net pts after commission. trades=%d' % len(trades)]
# monthly table
M = collections.defaultdict(list)
for d in trades: M[time.strftime('%Y-%m', time.gmtime(d['t0']))].append(d)
L.append('month    trades  net_pts  ATR20d%  mom20d%  share_below_SMA')
for k in sorted(M):
    g = M[k]; L.append('%s  %5d %8.0f   %.3f   %+6.2f   %.2f' % (k, len(g), sum(x['net'] for x in g), np.mean([x['atr'] for x in g]), np.nanmean([x['mom'] for x in g]), np.nanmean([x['below'] for x in g])))
good = [np.mean([x['atr'] for x in g]) for g in M.values() if sum(x['net'] for x in g) > 0]; bad = [np.mean([x['atr'] for x in g]) for g in M.values() if sum(x['net'] for x in g) <= 0]
L.append('ATR20d%% median: good months %.3f | bad months %.3f' % (np.median(good), np.median(bad)))
gm = [np.nanmean([x['mom'] for x in g]) for g in M.values() if sum(x['net'] for x in g) > 0]; bm = [np.nanmean([x['mom'] for x in g]) for g in M.values() if sum(x['net'] for x in g) <= 0]
L.append('mom20d%% median: good months %+.2f | bad months %+.2f' % (np.median(gm), np.median(bm)))
# filters (trailing info only), scored per year
def score(name, keep):
    L.append('%-28s ' % name + ' | '.join('%d: %+7.0f (%d)' % (y, sum(d['net'] for d in trades if d['y'] == y and keep(d)), sum(1 for d in trades if d['y'] == y and keep(d))) for y in (2011, 2012, 2017, 2019, 2020, 2021)))
L.append(''); L.append('FILTERS (tune 2017+2011, test 2012/2019/2020/2021):')
score('none', lambda d: True)
for th in (0.08, 0.10, 0.12): score('ATR20d%% < %.2f' % th, lambda d, th=th: d['atr'] < th)
for th in (1.0, 2.0): score('|mom20d%%| < %.1f' % th, lambda d, th=th: abs(d['mom']) < th)
score('mom20d% < +1 (no strong rally)', lambda d: d['mom'] < 1.0)
# rolling 20-trade win-rate pause (uses only closed earlier trades of the same year)
def roll(thr):
    keep = set(); hist = []
    for k, d in enumerate(trades):
        if k and trades[k-1]['y'] != d['y']: hist = []
        wr = np.mean([x > 0 for x in hist[-20:]]) if len(hist) >= 20 else 1
        if wr >= thr: keep.add(id(d))
        hist.append(d['net'])  # shadow result still recorded, so trading can resume
    return keep
for thr in (0.4, 0.5):
    ks = roll(thr); score('roll20 winrate >= %.1f' % thr, lambda d, ks=ks: id(d) in ks)
# cooldown variant (no shadow trades): after real last-20 win rate < thr, pause new sells for D days, then reset history
def cool(thr, days):
    keep = set(); hist = []; until = 0; yr = None
    for d in trades:
        if d['y'] != yr: yr = d['y']; hist = []; until = 0
        if d['t0'] < until: continue
        keep.add(id(d)); hist.append(d['net'])
        if len(hist) >= 20 and np.mean([x > 0 for x in hist[-20:]]) < thr: until = d['t0'] + days * 86400; hist = []
    return keep
for thr, days in ((0.4, 3), (0.4, 7), (0.4, 14), (0.5, 7)):
    ks = cool(thr, days); score('cooldown wr<%.1f pause %dd' % (thr, days), lambda d, ks=ks: id(d) in ks)
# honest version: only trades CLOSED before the new signal count (real or shadow), same year
def roll_closed(thr, win=20):
    keep = set()
    for d in trades:
        done = sorted([x for x in trades if x['y'] == d['y'] and x['t1'] < d['t0']], key=lambda x: x['t1'])[-win:]
        if len(done) < win or np.mean([x['net'] > 0 for x in done]) >= thr: keep.add(id(d))
    return keep
for thr, win in ((0.4, 20), (0.35, 20), (0.45, 20), (0.4, 15), (0.4, 30)):
    ks = roll_closed(thr, win); score('CLOSED-ONLY wr>=%.2f win%d' % (thr, win), lambda d, ks=ks: id(d) in ks)
# data check 2011/2012 vs 2019 on M1
M1 = load(1)
for y in (2011, 2012, 2019, 2021):
    a0, a1 = calendar.timegm((y, 1, 1, 0, 0, 0)), calendar.timegm((y + 1, 1, 1, 0, 0, 0)); s = (M1['t'] >= a0) & (M1['t'] < a1)
    tt = M1['t'][s]; gaps = np.diff(tt); wk = ((gaps > 300) & (gaps < 172800)).sum()
    spk = (((M1['h'][s] - M1['l'][s]) / M1['c'][s]) > 0.005).sum(); zv = (M1['v'][s] == 0).sum()
    L.append('DATA %d: M1 bars %d | intraweek gaps >5min %d | bars with range >0.5%% %d | zero-volume bars %d' % (y, s.sum(), wk, spk, zv))
open(os.path.join(OUT, 'ERA_ANALYSIS.txt'), 'w').write('\n'.join(L))
print('\n'.join(x for x in L if not re.match(r'^\d{4}-\d\d ', x)))
