"""mksets24.py - b24 .set files with EVERY extern listed (tester keeps stale inputs otherwise).
base = b22_thu.set (= b23 base) + all b23/b24 flags off; each variant overrides a few keys."""
import re
SRC = r'C:\Users\endos\Desktop\hst_out\Strong2010b_claude_b27.mq4'
T = r'C:\Users\endos\Desktop\mt4_tester\tester'
src = open(SRC, encoding='latin-1').read()
defaults, order = {}, []
for m in re.finditer(r'^\s*extern\s+(\w+)\s+([^;]+);', src, re.M):
    for part in m.group(2).split(','):
        k, v = [x.strip() for x in part.split('=', 1)]
        defaults[k] = {'true': '1', 'false': '0'}.get(v.strip('"'), v.strip('"')); order.append(k)

def load(name):
    d = {}
    for l in open(T + '\\' + name, encoding='latin-1'):
        if '=' in l: k, v = l.strip().split('=', 1); d[k] = v
    return d

BASE = dict(defaults); BASE.update(load('b22_thu.set'))
BASE.update({'SellBEStart': '0', 'SellBELock': '10', 'SellCCIMax': '999'})   # b23 flags off; b24 flags are off by default

V = {
 'b27_base': {},
 'b27_rng100': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.0'},
 'b27_rng125': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.25'},
 'b27_rng150': {'UseDailyRangeFilter': '1', 'MaxRangeAtrMultiplier': '1.5'},
 'b27_h4bb18': {'UseH4TrendAnchor': '1', 'H4Deviation': '1.8'},
 'b27_h4bb20': {'UseH4TrendAnchor': '1', 'H4Deviation': '2.0'},
 'b27_h4bb23': {'UseH4TrendAnchor': '1', 'H4Deviation': '2.3'},
 'b27_sharp70': {'UseMomentumSharpnessFilter': '1', 'MinCloseToLowRatio': '0.70'},
 'b27_sharp75': {'UseMomentumSharpnessFilter': '1', 'MinCloseToLowRatio': '0.75'},
 'b27_sharp85': {'UseMomentumSharpnessFilter': '1', 'MinCloseToLowRatio': '0.85'},
 'b27_addiv': {'UseVolumeDivergenceGuard': '1'},
 'b27_lock240': {'UseAdverseExtensionLock': '1', 'LockoutMinutes': '240', 'AdverseThresholdPoints': '150'},
 'b27_lock720': {'UseAdverseExtensionLock': '1', 'LockoutMinutes': '720', 'AdverseThresholdPoints': '150'},
 'b27_lock1440': {'UseAdverseExtensionLock': '1', 'LockoutMinutes': '1440', 'AdverseThresholdPoints': '150'},
}
for n, o in V.items():
    d = dict(BASE); d.update(o)
    bad = [k for k in d if k not in defaults]
    if bad: print('WARN keys not in EA', n, bad)
    with open(T + '\\' + n + '.set', 'w', newline='\r\n') as f:
        for k in order: f.write('%s=%s\n' % (k, d[k]))
print(len(V), 'sets,', len(order), 'inputs each')


