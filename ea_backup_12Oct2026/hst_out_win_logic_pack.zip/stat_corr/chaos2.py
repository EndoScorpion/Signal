"""chaos2.py - real chaos-vs-noise tests per trade (M15 log-returns, last 256 closed bars), as filters on b22 sells.
 K01  : Gottwald-Melbourne 0-1 test (K near 1 = chaotic, near 0 = regular), median over c in (pi/5, 4pi/5)
 LLE  : largest Lyapunov exponent, Rosenstein (embedding m=3, lag 1, mean log divergence slope over 1..8 steps)
 CD   : correlation dimension (Grassberger-Procaccia slope, m=3)
 SURR : surrogate test: LLE(real) - mean LLE(5 shuffled series); > 0 means structure beyond noise
Survivor = better than b22 in >= 6 of 8, keeps >= 60%, and a looser/tighter threshold neighbour also >= 5/8."""
import re, os, html, numpy as np
exec(open(r'C:\Users\endos\Desktop\hst_out\stat_corr\recombine.py').read().split('base = {')[0])
OUT = r'C:\Users\endos\Desktop\hst_out'; rng = np.random.default_rng(3)
TT = []
for lab, tag in TAGS:
    hd = open(os.path.join(OUT, tag + '.htm'), 'rb').read().decode('latin-1'); od = {}
    for row in re.findall(r'(?is)<tr[^>]*>(.*?)</tr>', hd):
        x = [html.unescape(re.sub('<[^>]+>', '', z)).strip() for z in re.findall(r'(?is)<td[^>]*>(.*?)</td>', row)]
        if len(x) < 9 or not x[0].isdigit(): continue
        d = od.setdefault(x[3], {})
        if x[2] in ('buy', 'sell') and 't0' not in d: d['t0'] = ts(x[1])
        if re.search(r't/p|s/l|close', x[2]): d['net'] = (float(x[8]) - 9 * float(x[4])) * 100
    for d in od.values():
        if 't0' in d and 'net' in d: TT.append(dict(p=lab, net=d['net'], i=np.searchsorted(M15['t'], d['t0']) - 1))
def k01(x):
    x = (x - x.mean()) / (x.std() + 1e-12); n = len(x); j = np.arange(1, n + 1); ks = []
    for c in rng.uniform(np.pi / 5, 4 * np.pi / 5, 20):
        p = np.cumsum(x * np.cos(j * c)); q = np.cumsum(x * np.sin(j * c)); nc = n // 10
        M = np.array([np.mean((p[k:] - p[:-k]) ** 2 + (q[k:] - q[:-k]) ** 2) for k in range(1, nc)])
        ks.append(np.corrcoef(np.arange(1, nc), M)[0, 1])
    return np.median(ks)
def embed(x, m=3): return np.column_stack([x[i:len(x) - m + 1 + i] for i in range(m)])
def lle(x):
    e = embed(x); n = len(e) - 9; D = np.linalg.norm(e[:n, None, :] - e[None, :n, :], axis=2)
    for i in range(n): D[i, max(0, i - 5):i + 6] = np.inf
    nb = np.argmin(D, 1); div = []
    for k in range(1, 9):
        dk = np.linalg.norm(e[np.arange(n) + k] - e[nb + k], axis=1); div.append(np.mean(np.log(dk[dk > 0])))
    return np.polyfit(np.arange(1, 9), div, 1)[0]
def cdim(x):
    e = embed(x); d = np.linalg.norm(e[:, None, :] - e[None, :, :], axis=2)[np.triu_indices(len(e), 1)]
    r = np.quantile(d, [0.05, 0.1, 0.2, 0.3]); C = [np.mean(d < rr) for rr in r]
    return np.polyfit(np.log(r), np.log(C), 1)[0]
mc = M15['c']
for t in TT:
    r = np.diff(np.log(mc[t['i'] - 256:t['i'] + 1]))
    t['K01'] = k01(r); t['LLE'] = lle(r); t['CD'] = cdim(r)
    t['SURR'] = t['LLE'] - np.mean([lle(rng.permutation(r)) for _ in range(5)])
P = [lab for lab, _ in TAGS]; base = {p: sum(t['net'] for t in TT if t['p'] == p) for p in P}
L = ['CHAOS2 (0-1 test, Rosenstein LLE, correlation dimension, shuffle-surrogate) on b22 sells, pts after commission. base: ' + ' | '.join('%s %+.0f' % (p, base[p]) for p in P), '']
for f in ('K01', 'LLE', 'CD', 'SURR'): L.append('%s quartiles: %s' % (f, ' '.join('%.3f' % q for q in np.nanpercentile([t[f] for t in TT], [25, 50, 75]))))
def sc(f):
    r = {p: sum(t['net'] for t in TT if t['p'] == p and f(t)) for p in P}; return sum(r[p] > base[p] for p in P), sum(1 for t in TT if f(t)) / len(TT), r
surv = []
for f in ('K01', 'LLE', 'CD', 'SURR'):
    q = np.nanpercentile([t[f] for t in TT], [20, 30, 40, 60, 70, 80])
    for side in ('BLOCK above', 'BLOCK below'):
        res = []
        for th in q:
            g = (lambda t, th=th: not t[f] > th) if side == 'BLOCK above' else (lambda t, th=th: not t[f] < th)
            res.append((th,) + sc(g))
        for k, (th, b, kp, r) in enumerate(res):
            s = '%-4s %s %.3f: better %d/8 kept %.0f%% | ' % (f, side, th, b, 100 * kp) + ' '.join('%s %+.0f' % (p, r[p]) for p in P); L.append(s)
            nbs = [res[j][1] for j in (k - 1, k + 1) if 0 <= j < len(res)]
            if b >= 6 and kp >= 0.6 and any(x >= 5 for x in nbs): surv.append(s)
L += ['', 'SURVIVORS:'] + (surv or ['none'])
open(os.path.join(OUT, 'CHAOS2.txt'), 'w').write('\n'.join(L)); print('\n'.join(L[:6] + L[-(len(surv) + 2):]))
