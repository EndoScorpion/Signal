﻿// b52 (2026-10-14): CLEAN-history EA. Clock: MT4 SERVER time = UTC+2, UTC+3 in US DST. Rollover spread spike is about 23:00-01:00 server time, so RollFrom=23..RollTo=1 (window wraps midnight). Warm-up check now counts H1 bars (regime SMA needs RegimePeriod H1 bars).
//+------------------------------------------------------------------+
//| MR_RegimeSwitch_b62.mq4 - b59 plus Ehlers cycle gate, Kalman z, variance regime gate (default off); b59 = b58 plus split entries (partial take profit) and drawdown hedge (opposite order with stop and limit), default off |
//| Copyright (c) Nasif Hossain <EndoScorpion@gmail.com>. All rights  |
//| reserved. Concept: mean-reversion fade (sell stretch up, buy      |
//| stretch down) with the H1 SMA regime deciding which side is       |
//| allowed. New clone branch; ancestors (b31, b42, b43) untouched.   |
//+------------------------------------------------------------------+
#property strict
extern int    MagicNumber    = 5350062;
extern double Lots           = 0.16;     // fixed lot (base sim sizes ~0.16 at 0.5% risk)
extern int    ZTF            = 15;       // timeframe (minutes) of the z-score
extern int    ZPeriod        = 10;       // closes in the z-score window
extern double ZTrigger       = 2.5;      // |z| needed to fade
extern int    HoldBars       = 48;       // time exit in ZTF bars
extern int    SideMode       = 0;        // 0 both, 1 sell only, 2 buy only
extern bool   UseRegime      = true;     // sell only below H1 SMA, buy only above it
extern int    RegimePeriod   = 2400;     // H1 SMA length
extern int    SLPts          = 600;      // stop loss in points (0 = none)
extern int    TPPts          = 0;        // take profit in points (0 = none)
extern double AtrCapPts      = 0;        // >0: skip when M15 ATR14 (points) above this
extern bool   BlockRollover  = true;     // skip server hours RollFrom..RollTo (spread spike)
extern int    RollFrom       = 23;
extern int    RollTo         = 1;
extern int    MaxSpreadPts   = 30;       // skip when spread above this (points)
extern int    TrailStartPts  = 0;        // >0: once profit reaches this many points, trail the stop (0 = no trailing)
extern int    TrailDistPts   = 250;      // trailing distance behind price in points
// b51: ZGate-style volume blend trigger, MMR gate, calm-tape gate (all default off). (c) Nasif Hossain <EndoScorpion@gmail.com>
extern bool   UseZBlend      = false;    // trigger uses Z = 0.7*z(price) + 0.3*z(tick volume) instead of price z only
extern bool   UseMmrGate     = false;    // require MmrMin <= MMR <= MmrMax (MMR = max/|min| of OLS slopes over 6, 12, 18 bars)
extern double MmrMin         = -1000;
extern double MmrMax         = 1000;
extern double CalmRvolMax    = 0;        // >0: skip when std-dev of 1-bar returns over 20 bars (points) is above this
extern double CalmPEMax      = 0;        // >0: skip when permutation entropy (order 3, 64 bars) is above this
// b54 (2026-10-14) NEW THEORY BRANCHES, every input default off = identical to b52. (c) Nasif Hossain <EndoScorpion@gmail.com>
extern double QuietRvolMax   = 0;        // >0: when 20-bar return std-dev (points) <= this (quiet tape) use QuietZTrigger = more entries in quiet times
extern double QuietZTrigger  = 2.0;
extern double VolSpikeRatio  = 0;        // >0: when ATR14/ATR100 (M15) >= this, use VolRevZTrigger (volatility mean-reversion entry: fade sooner in a vol spike)
extern double VolRevZTrigger = 1.75;
extern int    SlopeGapMode   = 0;        // SMA20-SMA50 slope gap: 1 only when |gap| shrinks (converging), 2 only when it grows (diverging)
extern double SlopeSdMax     = 0;        // >0: skip when std-dev of SMA20 slope over 20 bars (pts/bar) is above this
extern double EmaSlopeAbsMax = 0;        // >0: skip when |EMA20 slope| (pts/bar) is above this
extern double ErMin          = 0;        // Kaufman ER20 smoothness band, active when ErMin>0 or ErMax<1
extern double ErMax          = 1;
extern int    FibMode        = 0;        // 1: entry only when price has retraced a 0.382/0.5/0.618 fraction of the last FibBars range
extern int    FibBars        = 48;
extern double FibTol         = 0.04;
extern int    StochMode      = 0;        // 1: require StochLo <= Stoch K <= StochHi (only winning-evidence ranges should be tried)
extern int    StochK         = 14;
extern double StochLo        = 0;
extern double StochHi        = 100;
extern int    WprMode        = 0;        // 1: Williams %R extreme: sell needs WPR >= WprSellMin, buy needs WPR <= WprBuyMax
extern int    WprPeriod      = 14;
extern double WprSellMin     = -20;
extern double WprBuyMax      = -80;
extern int    AlligatorMode  = 0;        // Bill Williams Alligator: 1 only when asleep (jaw/teeth/lips spread <= AllSpreadPts), 2 only when awake (>=)
extern double AllSpreadPts   = 60;
extern int    FractalMode    = 0;        // 1: sell only near a recent upper fractal high, buy only near a recent lower fractal low (fade at fractal S/R)
extern int    FracLook       = 30;
extern double FracTolPts     = 40;
extern int    SsrMode        = 0;        // SSR = slope(SMA SsrFast)/slope(SMA SsrSlow) on ZTF (Nasif Hossain): 1 only when SsrMin<=SSR<=SsrMax (converged = easier entries), 2 only when OUTSIDE the band (diverged = chaos)
extern int    SsrFast        = 20;
extern int    SsrSlow        = 200;
extern double SsrMin         = 0.2;
extern double SsrMax         = 5;
extern bool   BearBuyBlock   = false;    // true: never buy in a bear market (H1 close below the RegimePeriod SMA, or that SMA lower than BearSlopeBars H1 bars ago); applies to every buy path
extern int    BearSlopeBars  = 240;
extern bool   CrossUseGates  = false;    // true: SMA cross entries must also pass the smoothness/volatility/stoch/fib/slope/chaos gates above
extern bool   BuyUpConv      = false;    // true: buys only when the small SMA slope >= BuyMinSlope (pts/bar), the big SMA slope is rising, and their ratio is inside SsrMin..SsrMax (strong up slope with convergence)
extern double BuyMinSlope    = 8;
// b56 more gates, all default off: range, volume, ADX, CCI, accumulation/distribution, fractal dimension, Lyapunov (chaos / complex systems)
extern int    SlopeStackMode = 0;        // average SMA slope convergence: slopes of SMA 10/20/50/100/200 on ZTF; 1 only when their spread (std-dev) is shrinking (converging), 2 only when growing (diverging)
extern double SlopeStackSdMax = 0;       // >0: skip when the std-dev across the five slopes is above this (pts/bar)
extern double SlopeStackAbsMin = 0;      // >0: skip when the average of the five slopes is flatter than this (pts/bar)
// b57 new theories, all default off
// b58 win-rate and loss-reduction ideas plus confidence sizing (backtest practice only; all default off)
// b59: split entries, drawdown hedge and ONE shared risk budget for simultaneous orders (all default off)
extern int    SplitMode      = 0;        // 1: split the entry into two orders: half with a take profit of SplitTPPts, half runs to the normal exit
extern int    SplitTPPts     = 300;
extern int    HedgeTriggerPts = 0;       // >0: when the open trade's floating loss reaches this many points, open an OPPOSITE hedge order (magic+1) with its own stop and limit
extern double HedgeRatio     = 1.0;      // hedge lots = main lots x this
extern int    HedgeSLPts     = 300;
extern int    HedgeTPPts     = 0;
extern double TotalLotCap    = 0;        // >0: BUDGET: total open lots (main + split + hedge) never exceed this
extern double HedgeBudgetPct = 33;       // share of TotalLotCap reserved for the hedge when hedging is on (the main trade gets the rest)
extern int    BreakEvenStart = 0;       // >0: once floating profit reaches this many points, move the stop to the open price + BreakEvenLock
extern int    BreakEvenLock  = 20;
extern int    FastStopPts    = 0;        // >0: close at once if the floating loss reaches this many points within FastStopBars bars of entry (adverse excursion early exit)
extern int    FastStopBars   = 8;
extern int    CooldownBars   = 0;        // >0: after a losing close, no new entry for this many ZTF bars
extern bool   TurnConfirm    = false;    // true: enter only after the stretch has peaked (|price z| already falling versus the previous bar)
extern double LotVolRefAtr   = 0;        // >0: lots scaled by min(1, LotVolRefAtr / M15 ATR14 pts) (smaller size in high volatility)
extern int    ConfMode       = 0;        // 1: CONFIDENCE sizing: score = how many win-logic signals agree (gap converging, stack converging, SSR aligned, choppy ER, quiet tape, Hurst<=0.5, volume<=1.5x)
extern double ConfStep       = 0.25;     // lots = Lots x (1 + ConfStep x score), capped by ConfMaxMult, ConfMaxLots and ConfMarginPct
extern double ConfMaxMult    = 3.0;
extern double ConfMaxLots    = 1.0;
extern double ConfMarginPct  = 30;       // the trade may use at most this % of free margin (0 = ignore)
extern double ZExitLevel     = 0;       // >0: close a trade early once z has reverted to within this many std-devs of the mean (sell closes at z<=level, buy at z>=-level)
extern double AtrSLMult      = 0;        // >0: stop loss = AtrSLMult x M15 ATR14 (replaces SLPts)
extern double AtrTPMult      = 0;        // >0: take profit = AtrTPMult x M15 ATR14
extern int    HourFrom       = -1;       // >=0: only trade when server hour is in HourFrom..HourTo (wraps midnight)
extern int    HourTo         = 23;
extern double AcMax          = 0;        // >0: skip when lag-1 autocorrelation of the last 60 M15 returns is above this (positive = trending)
extern double AbsVolMin      = 0;        // >0: absorption (Wyckoff effort vs result): need last-bar volume >= AbsVolMin x 20-bar average ...
extern double AbsRangeMax    = 0.8;      // ... and last-bar range <= AbsRangeMax x ATR14
// b60 (2026-10-14) NEW THEORY GATES, all default off. (c) Nasif Hossain <EndoScorpion@gmail.com>
extern int    CycleMode      = 0;        // 1: Ehlers Cyber Cycle (alpha 0.07): sell only when cycle>0 and turning down, buy the mirror
extern double CycleAlpha     = 0.07;
extern bool   UseKalmanZ     = false;    // true: trigger z = last close vs 1-D Kalman level residual / residual std-dev (100 closes)
extern double KalQ           = 0.02;     // process noise (points^2)
extern double KalR           = 1.0;      // observation noise (points^2)
extern int    VarRegimeMode  = 0;        // 1: trade only when short EWMA vol <= VarRatioMax * long EWMA vol; 2: only when above
extern double VarRatioMax    = 1.0;
extern bool   UseRegZ        = false;  // true: trigger z = distance from the OLS regression line over ZPeriod closes (mean regression) instead of from the mean
extern double DayRangeMaxMult = 0;      // >0: skip when today's D1 range so far exceeds this x D1 ATR(RangeAtrPeriodB) (old daily-range filter idea)
extern int    RangeAtrPeriodB = 5;
extern double VolRelMin      = 0;        // tick volume of the last bar / its 20-bar average: skip below this
extern double VolRelMax      = 0;        // >0: skip above this
extern int    AdxPeriod      = 14;
extern double AdxMin         = 0;
extern double AdxMax         = 0;        // >0: skip when ADX above this (trending)
extern int    CciMode        = 0;        // 1: sell needs CCI >= CciSellMin, buy needs CCI <= -CciSellMin
extern int    CciPeriod      = 20;
extern double CciSellMin     = 100;
extern int    AdMode         = 0;        // accumulation/distribution over AdBars: 1 sell needs A/D falling (distribution), buy needs rising (accumulation); 2 requires price/AD divergence
extern int    AdBars         = 20;
extern double FdMin          = 0;        // Katz fractal dimension of the last 64 closes (1 = straight line, higher = noisier); band, active when FdMin>0 or FdMax>0
extern double FdMax          = 0;
extern double LyapMax        = 0;        // >0: skip when the estimated largest Lyapunov exponent (embedding 3, 100 closes, 5 step horizon) is above this (chaotic)
extern double SsrFlatMin     = 0;       // >0: SSR entries skipped when either SMA slope is flatter than this (pts/bar)
extern double SsrObK         = 0;        // >0: SSR entries skipped when Stoch K (StochK period) >= this (overbought)
// b62: notifications, remote disable (control file), heartbeat, daily loss stop. All default off. Live/demo only: the tester ignores mail, push and the common files.
extern bool   NotifyMail     = false;    // SendMail on entries, closes, drawdown alerts, daily summary (set up Tools > Options > Email in MT4 yourself; never put passwords in an EA)
extern bool   NotifyPush     = false;    // SendNotification to the MT4 phone app (set the MetaQuotes ID in Tools > Options > Notifications)
extern int    NotifyMinGapSec = 15;      // minimum seconds between two notifications (flood guard)
extern int    DDAlertPts     = 0;        // >0: notify once per trade when its floating loss reaches this many points
extern int    DailyMailHour  = -1;       // >=0: send a daily summary at this server hour
extern bool   UseControlFile = false;    // true: read ea_control.txt in the common files folder each new bar; a line DISABLE=1 blocks NEW entries (open trades keep their stops)
extern string ControlFileName = "ea_control.txt";
extern bool   CloseAllOnDisable = false; // true: DISABLE=1 also closes this EA's open trades once (risk reduction)
extern int    HeartbeatMin   = 0;        // >0: append equity, balance, open lots and flags to ea_heartbeat_<magic>.csv in the common files folder every N minutes
extern double DailyLossStopPct = 0;      // >0: no new entries for the rest of the server day once equity falls this % below the day's start
extern double OuHalfMax      = 0;       // b61: >0: Ornstein-Uhlenbeck half-life gate: skip unless the estimated mean-reversion half-life (ZTF bars, AR(1) over OuBars closes) is between OuHalfMin and OuHalfMax
extern double OuHalfMin      = 4;
extern int    OuBars         = 100;
extern double HurstMax       = 0;       // >0: chaos theory, require Hurst exponent (R/S, 128 bars) <= this (below 0.5 = mean reverting)
extern double VovMax         = 0;        // >0: complex systems, skip when volatility-of-volatility (cv of 20-bar return std-dev over last 10 bars) is above this
extern int    AccelMode      = 0;        // 1: calculus timing, sell needs EMA slope d1>0 with d2<0 (rise decelerating), buy the mirror
extern int    CalcPeriod     = 10;
extern int    EntryMode      = 0;        // 0 z-fade (as b52), 1 large SMA cross only, 2 either
extern int    CrossTF        = 60;
extern int    CrossFast      = 200;
extern int    CrossSlow      = 800;
datetime lastBar = 0, lastCross = 0;

int CountOpen(){ int c=0; for(int i=OrdersTotal()-1;i>=0;i--){ if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES) && OrderMagicNumber()==MagicNumber && OrderSymbol()==Symbol()){ c++; } } return(c); }

double ZScore();
void TimeExit(){
   for(int i=OrdersTotal()-1;i>=0;i--){
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES) || OrderMagicNumber()!=MagicNumber || OrderSymbol()!=Symbol()){ continue; }
      if(OrderType()>OP_SELL){ continue; }
      if(ZExitLevel>0){ double zx=ZScore(); if((OrderType()==OP_SELL && zx<=ZExitLevel) || (OrderType()==OP_BUY && zx>=-ZExitLevel)){ RefreshRates(); double pz=(OrderType()==OP_BUY)?Bid:Ask; if(OrderClose(OrderTicket(),OrderLots(),NormalizeDouble(pz,Digits),20,clrNONE)){ continue; } } }   // mean touched: exit
      { double fl=(OrderType()==OP_SELL)?(OrderOpenPrice()-Ask)/Point:(Bid-OrderOpenPrice())/Point;   // floating profit in points
        if(FastStopPts>0 && fl<=-FastStopPts && TimeCurrent()-OrderOpenTime()<=FastStopBars*ZTF*60){ RefreshRates(); double pf=(OrderType()==OP_BUY)?Bid:Ask; if(OrderClose(OrderTicket(),OrderLots(),NormalizeDouble(pf,Digits),20,clrNONE)){ continue; } }
        if(BreakEvenStart>0 && fl>=BreakEvenStart){ double nsl=(OrderType()==OP_SELL)?OrderOpenPrice()-BreakEvenLock*Point:OrderOpenPrice()+BreakEvenLock*Point; double cs=OrderStopLoss();
           bool better=(OrderType()==OP_SELL)?(cs==0 || nsl<cs):(cs==0 || nsl>cs); if(better){ if(!OrderModify(OrderTicket(),OrderOpenPrice(),NormalizeDouble(nsl,Digits),OrderTakeProfit(),0,clrNONE)){ Print("be err ",GetLastError()); } } } }
      if(TimeCurrent()-OrderOpenTime() >= HoldBars*ZTF*60){
         RefreshRates(); double px=(OrderType()==OP_BUY)?Bid:Ask;
         if(!OrderClose(OrderTicket(),OrderLots(),NormalizeDouble(px,Digits),20,clrNONE)){ Print("close err ",GetLastError()); } } } }

void TrailStops(){
   if(TrailStartPts<=0){ return; }
   for(int i=OrdersTotal()-1;i>=0;i--){
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES) || OrderMagicNumber()!=MagicNumber || OrderSymbol()!=Symbol() || OrderType()>OP_SELL){ continue; }
      double ns, cur=OrderStopLoss();
      if(OrderType()==OP_SELL){
         if(OrderOpenPrice()-Ask<TrailStartPts*Point){ continue; }
         ns=NormalizeDouble(Ask+TrailDistPts*Point,Digits);
         if(cur==0 || ns<cur){ if(!OrderModify(OrderTicket(),OrderOpenPrice(),ns,OrderTakeProfit(),0,clrNONE)){ Print("trail err ",GetLastError()); } }
      } else {
         if(Bid-OrderOpenPrice()<TrailStartPts*Point){ continue; }
         ns=NormalizeDouble(Bid-TrailDistPts*Point,Digits);
         if(cur==0 || ns>cur){ if(!OrderModify(OrderTicket(),OrderOpenPrice(),ns,OrderTakeProfit(),0,clrNONE)){ Print("trail err ",GetLastError()); } } } } }

double SlopePts(int w){ double sx=0,sy=0,sxy=0,sxx=0; for(int j=0;j<w;j++){ double y=iClose(Symbol(),ZTF,w-j); sx+=j; sy+=y; sxy+=j*y; sxx+=j*j; } double den=w*sxx-sx*sx; return(den==0?0:(w*sxy-sx*sy)/den/Point); }
double MmrNow(){ double a=SlopePts(6), b=SlopePts(12), c=SlopePts(18); double mx=MathMax(a,MathMax(b,c)), mn=MathMin(a,MathMin(b,c)); return(mn==0?EMPTY_VALUE:mx/MathAbs(mn)); }
double RvolNow(){ double sm=0,sq=0; for(int k=1;k<=20;k++){ double r=(iClose(Symbol(),ZTF,k)-iClose(Symbol(),ZTF,k+1))/Point; sm+=r; sq+=r*r; } double m=sm/20; return(MathSqrt(MathMax(0,sq/20-m*m))); }
double PermEntropyNow(){ int pc[8]; ArrayInitialize(pc,0); int tot=0; for(int s=1;s<=62;s++){ double pa=iClose(Symbol(),ZTF,s+2), pb=iClose(Symbol(),ZTF,s+1), pc2=iClose(Symbol(),ZTF,s); int code=(pa<pb?4:0)+(pb<pc2?2:0)+(pa<pc2?1:0); pc[code]++; tot++; } double h=0; for(int q=0;q<8;q++){ if(pc[q]>0){ double p=(double)pc[q]/tot; h-=p*MathLog(p); } } return(h/MathLog(6.0)); }
double KalmanZ();
double ZScore(){
   if(UseKalmanZ){ return(KalmanZ()); }
   if(UseZBlend){ int nb=MathMax(3,ZPeriod); double sp=0,qp=0,sv=0,qv=0; for(int k=1;k<=nb;k++){ double c=iClose(Symbol(),ZTF,k), v=(double)iVolume(Symbol(),ZTF,k); sp+=c; qp+=c*c; sv+=v; qv+=v*v; }
      double mp=sp/nb, mv=sv/nb, dp=MathSqrt(MathMax(0,qp/nb-mp*mp)), dv=MathSqrt(MathMax(0,qv/nb-mv*mv)); if(dp<=0||dv<=0){ return(0); }
      return(0.7*(iClose(Symbol(),ZTF,1)-mp)/dp+0.3*((double)iVolume(Symbol(),ZTF,1)-mv)/dv); }
   if(UseRegZ){ int nr=MathMax(5,ZPeriod); double sx=0,sy=0,sxy=0,sxx=0;   // mean regression: distance of the last close from the OLS regression line over nr closes, in residual std-devs
      for(int k=1;k<=nr;k++){ double x=nr-k, y=iClose(Symbol(),ZTF,k); sx+=x; sy+=y; sxy+=x*y; sxx+=x*x; }
      double den=nr*sxx-sx*sx; if(den==0){ return(0); } double sl=(nr*sxy-sx*sy)/den, ic=(sy-sl*sx)/nr, rs=0;
      for(int k=1;k<=nr;k++){ double e=iClose(Symbol(),ZTF,k)-(ic+sl*(nr-k)); rs+=e*e; } double sd2=MathSqrt(rs/nr); if(sd2<=0){ return(0); }
      return((iClose(Symbol(),ZTF,1)-(ic+sl*(nr-1)))/sd2); }
   int n=MathMax(3,ZPeriod); double s=0,q=0;
   for(int k=1;k<=n;k++){ double c=iClose(Symbol(),ZTF,k); s+=c; q+=c*c; }
   double m=s/n, sd=MathSqrt(MathMax(0,q/n-m*m)); if(sd<=0){ return(0); }
   return((iClose(Symbol(),ZTF,1)-m)/sd); }

double SmaSlope(int p,int sh){ return((iMA(Symbol(),ZTF,p,0,MODE_SMA,PRICE_CLOSE,sh)-iMA(Symbol(),ZTF,p,0,MODE_SMA,PRICE_CLOSE,sh+1))/Point); }
double SlopeSd(){ double s=0,q=0; for(int k=1;k<=20;k++){ double v=SmaSlope(20,k); s+=v; q+=v*v; } double m=s/20; return(MathSqrt(MathMax(0,q/20-m*m))); }
double ErNow(){ double net=MathAbs(iClose(Symbol(),ZTF,1)-iClose(Symbol(),ZTF,21)), path=0; for(int k=1;k<=20;k++){ path+=MathAbs(iClose(Symbol(),ZTF,k)-iClose(Symbol(),ZTF,k+1)); } return(path<=0?0:net/path); }
double RvolAt(int sh){ double sm=0,sq=0; for(int k=sh;k<sh+20;k++){ double r=(iClose(Symbol(),ZTF,k)-iClose(Symbol(),ZTF,k+1))/Point; sm+=r; sq+=r*r; } double m=sm/20; return(MathSqrt(MathMax(0,sq/20-m*m))); }
double VovNow(){ double s=0,q=0; for(int j=1;j<=10;j++){ double v=RvolAt(j); s+=v; q+=v*v; } double m=s/10; if(m<=0){ return(0); } return(MathSqrt(MathMax(0,q/10-m*m))/m); }
double HurstNow(){
   double rr[128]; for(int j=0;j<128;j++){ rr[j]=iClose(Symbol(),ZTF,j+1)-iClose(Symbol(),ZTF,j+2); }
   int sc[4]={8,16,32,64}; double lx[4], ly[4];
   for(int a=0;a<4;a++){ int n=sc[a], bl=128/n; double sumrs=0; int cnt=0;
      for(int b=0;b<bl;b++){ double mn=0; for(int i=0;i<n;i++){ mn+=rr[b*n+i]; } mn/=n; double cum=0,mx=0,mi=0,sq=0;
         for(int i=0;i<n;i++){ double d=rr[b*n+i]-mn; cum+=d; if(cum>mx){ mx=cum; } if(cum<mi){ mi=cum; } sq+=d*d; }
         double sd=MathSqrt(sq/n); if(sd>0){ sumrs+=(mx-mi)/sd; cnt++; } }
      if(cnt==0){ return(0.5); } lx[a]=MathLog((double)n); ly[a]=MathLog(sumrs/cnt); }
   double sx=0,sy=0,sxy=0,sxx=0; for(int a=0;a<4;a++){ sx+=lx[a]; sy+=ly[a]; sxy+=lx[a]*ly[a]; sxx+=lx[a]*lx[a]; }
   double den=4*sxx-sx*sx; return(den==0?0.5:(4*sxy-sx*sy)/den); }
bool FibOk(int ty){
   int hi=iHighest(Symbol(),ZTF,MODE_HIGH,FibBars,1), lo=iLowest(Symbol(),ZTF,MODE_LOW,FibBars,1); double H=iHigh(Symbol(),ZTF,hi), L=iLow(Symbol(),ZTF,lo), c=iClose(Symbol(),ZTF,1);
   if(H<=L){ return(false); } double r=(ty==OP_SELL)?(H-c)/(H-L):(c-L)/(H-L);
   return(MathAbs(r-0.382)<=FibTol || MathAbs(r-0.5)<=FibTol || MathAbs(r-0.618)<=FibTol); }
bool FractalOk(int ty){
   double c=iClose(Symbol(),ZTF,1);
   for(int k=3;k<=FracLook;k++){
      if(ty==OP_SELL){ double u=iFractals(Symbol(),ZTF,MODE_UPPER,k); if(u>0 && c>=u-FracTolPts*Point){ return(true); } }
      else { double d=iFractals(Symbol(),ZTF,MODE_LOWER,k); if(d>0 && c<=d+FracTolPts*Point){ return(true); } } }
   return(false); }
double KatzFd(){ int N=64; double L=0,dmax=0, c0=iClose(Symbol(),ZTF,N);
   for(int k=N-1;k>=1;k--){ double a=iClose(Symbol(),ZTF,k+1), b=iClose(Symbol(),ZTF,k); L+=MathAbs(b-a)/Point; double d=MathAbs(b-c0)/Point; if(d>dmax){ dmax=d; } }
   if(L<=0 || dmax<=0){ return(1.0); } double n=N-1; return(MathLog10(n)/(MathLog10(n)+MathLog10(dmax/L))); }
double LyapNow(){ int n=100,m=3,K=5; double x[]; ArrayResize(x,n+K); for(int i=0;i<n+K;i++){ x[i]=iClose(Symbol(),ZTF,n+K-i); }
   double sum=0; int cnt=0;
   for(int i=0;i<n-m;i++){ double best=1e18; int bj=-1;
      for(int j=0;j<n-m;j++){ if(MathAbs(i-j)<4){ continue; } double d=0; for(int t=0;t<m;t++){ double df=(x[i+t]-x[j+t])/Point; d+=df*df; } d=MathSqrt(d); if(d>0 && d<best){ best=d; bj=j; } }
      if(bj<0){ continue; } double dk=0; for(int t=0;t<m;t++){ double df=(x[i+K+t]-x[bj+K+t])/Point; dk+=df*df; } dk=MathSqrt(dk); if(dk>0){ sum+=MathLog(dk/best)/K; cnt++; } }
   return(cnt>0?sum/cnt:0); }
void SlopeStack(int sh,double &mean,double &sd){ int ps[5]={10,20,50,100,200}; double s=0,q=0; for(int a=0;a<5;a++){ double v=SmaSlope(ps[a],sh); s+=v; q+=v*v; } mean=s/5; sd=MathSqrt(MathMax(0,q/5-mean*mean)); }
double SsrNow(){ double sf=SmaSlope(SsrFast,1), ss=SmaSlope(SsrSlow,1); if(MathAbs(ss)<0.05){ return(EMPTY_VALUE); } return(MathMax(-10.0,MathMin(10.0,sf/ss))); }
bool CycleOk(int ty){ int N=60; double a=CycleAlpha, c1=(1-0.5*a)*(1-0.5*a), c2=2*(1-a), c3=(1-a)*(1-a);
   double sm[]; ArrayResize(sm,N+2); for(int i=0;i<N+2;i++){ int sh=N+2-i; sm[i]=(iClose(Symbol(),ZTF,sh)+2*iClose(Symbol(),ZTF,sh+1)+2*iClose(Symbol(),ZTF,sh+2)+iClose(Symbol(),ZTF,sh+3))/6.0; }
   double cy[]; ArrayResize(cy,N+2); cy[0]=0; cy[1]=0; for(int t=2;t<N+2;t++){ double dd=sm[t]-2*sm[t-1]+sm[t-2]; cy[t]=(t<4)?dd/4.0:c1*dd+c2*cy[t-1]-c3*cy[t-2]; }
   double c_1=cy[N+1], c_2=cy[N];   // cycle at shift 1 and 2
   if(ty==OP_SELL){ return(c_1>0 && c_1<c_2); } return(c_1<0 && c_1>c_2); }
double KalmanZ(){ int N=100; double x=iClose(Symbol(),ZTF,N), P=KalR*Point*Point, Q=KalQ*Point*Point, R=KalR*Point*Point, ss=0, inn=0;
   for(int k=N-1;k>=1;k--){ double y=iClose(Symbol(),ZTF,k); P+=Q; inn=y-x; ss+=inn*inn; double K=P/(P+R); x+=K*inn; P*=(1-K); }
   double sd=MathSqrt(ss/(N-1)); if(sd<=0){ return(0); } return(inn/sd); }
bool VarRegimeOk(){ int N=300; double vs=0,vl=0; for(int k=N;k>=1;k--){ double r=iClose(Symbol(),ZTF,k)-iClose(Symbol(),ZTF,k+1); if(k==N){ vs=r*r; vl=r*r; } else { vs=0.90*vs+0.10*r*r; vl=0.99*vl+0.01*r*r; } }
   if(vl<=0){ return(false); } double ratio=MathSqrt(vs/vl); if(VarRegimeMode==1){ return(ratio<=VarRatioMax); } return(ratio>VarRatioMax); }
bool GatesPass(int ty){
   if(SsrMode>0){ double r=SsrNow(); if(r==EMPTY_VALUE){ return(false); } bool inb=(r>=SsrMin && r<=SsrMax); if(SsrMode==1 && !inb){ return(false); } if(SsrMode==2 && inb){ return(false); }
      if(SsrFlatMin>0 && (MathAbs(SmaSlope(SsrFast,1))<SsrFlatMin || MathAbs(SmaSlope(SsrSlow,1))<SsrFlatMin)){ return(false); }   // flat slopes: ratio is noise
      if(SsrObK>0){ double sk=iStochastic(Symbol(),ZTF,StochK,3,3,MODE_SMA,0,MODE_MAIN,1); if(sk>=SsrObK){ return(false); } } }   // overbought: skip
   if(SlopeGapMode>0){ double g1=MathAbs(SmaSlope(20,1)-SmaSlope(50,1)), g2=MathAbs(SmaSlope(20,2)-SmaSlope(50,2)); if(SlopeGapMode==1 && g1>=g2){ return(false); } if(SlopeGapMode==2 && g1<=g2){ return(false); } }
   if(SlopeSdMax>0 && SlopeSd()>SlopeSdMax){ return(false); }
   if(EmaSlopeAbsMax>0){ double es=(iMA(Symbol(),ZTF,20,0,MODE_EMA,PRICE_CLOSE,1)-iMA(Symbol(),ZTF,20,0,MODE_EMA,PRICE_CLOSE,2))/Point; if(MathAbs(es)>EmaSlopeAbsMax){ return(false); } }
   if(ErMin>0 || ErMax<1){ double er=ErNow(); if(er<ErMin || er>ErMax){ return(false); } }
   if(StochMode==1){ double sk=iStochastic(Symbol(),ZTF,StochK,3,3,MODE_SMA,0,MODE_MAIN,1); if(sk<StochLo || sk>StochHi){ return(false); } }
   if(WprMode==1){ double w=iWPR(Symbol(),ZTF,WprPeriod,1); if(ty==OP_SELL && w<WprSellMin){ return(false); } if(ty==OP_BUY && w>WprBuyMax){ return(false); } }
   if(AlligatorMode>0){ double j=iAlligator(Symbol(),ZTF,13,8,8,5,5,3,MODE_SMMA,PRICE_MEDIAN,MODE_GATORJAW,1), t=iAlligator(Symbol(),ZTF,13,8,8,5,5,3,MODE_SMMA,PRICE_MEDIAN,MODE_GATORTEETH,1), l=iAlligator(Symbol(),ZTF,13,8,8,5,5,3,MODE_SMMA,PRICE_MEDIAN,MODE_GATORLIPS,1);
      double sp=(MathMax(j,MathMax(t,l))-MathMin(j,MathMin(t,l)))/Point; if(AlligatorMode==1 && sp>AllSpreadPts){ return(false); } if(AlligatorMode==2 && sp<AllSpreadPts){ return(false); } }
   if(FractalMode==1 && !FractalOk(ty)){ return(false); }
   if(HurstMax>0 && HurstNow()>HurstMax){ return(false); }
   if(VovMax>0 && VovNow()>VovMax){ return(false); }
   if(AccelMode==1){ double e1=iMA(Symbol(),ZTF,CalcPeriod,0,MODE_EMA,PRICE_CLOSE,1), e2=iMA(Symbol(),ZTF,CalcPeriod,0,MODE_EMA,PRICE_CLOSE,2), e3=iMA(Symbol(),ZTF,CalcPeriod,0,MODE_EMA,PRICE_CLOSE,3);
      double d1=e1-e2, d2=d1-(e2-e3); if(ty==OP_SELL && !(d1>0 && d2<0)){ return(false); } if(ty==OP_BUY && !(d1<0 && d2>0)){ return(false); } }
   if(SlopeStackMode>0){ double m1,s1,m2,s2; SlopeStack(1,m1,s1); SlopeStack(2,m2,s2);   // average slope of SMA 10/20/50/100/200 and how tightly the five slopes agree
      if(SlopeStackMode==1 && s1>=s2){ return(false); } if(SlopeStackMode==2 && s1<=s2){ return(false); }
      if(SlopeStackSdMax>0 && s1>SlopeStackSdMax){ return(false); } if(SlopeStackAbsMin>0 && MathAbs(m1)<SlopeStackAbsMin){ return(false); } }
   if(DayRangeMaxMult>0){ double dr=iHigh(Symbol(),PERIOD_D1,0)-iLow(Symbol(),PERIOD_D1,0), at=iATR(Symbol(),PERIOD_D1,RangeAtrPeriodB,1); if(at>0 && dr>DayRangeMaxMult*at){ return(false); } }
   if(VolRelMin>0 || VolRelMax>0){ double sv=0; for(int k=2;k<=21;k++){ sv+=(double)iVolume(Symbol(),ZTF,k); } double av=sv/20, vr=(av>0)?(double)iVolume(Symbol(),ZTF,1)/av:1; if(VolRelMax>0 && vr>VolRelMax){ return(false); } if(vr<VolRelMin){ return(false); } }
   if(AdxMin>0 || AdxMax>0){ double ax=iADX(Symbol(),ZTF,AdxPeriod,PRICE_CLOSE,MODE_MAIN,1); if(AdxMax>0 && ax>AdxMax){ return(false); } if(ax<AdxMin){ return(false); } }
   if(CciMode==1){ double cc=iCCI(Symbol(),ZTF,CciPeriod,PRICE_TYPICAL,1); if(ty==OP_SELL && cc<CciSellMin){ return(false); } if(ty==OP_BUY && cc>-CciSellMin){ return(false); } }
   if(AdMode>0){ double a1=iAD(Symbol(),ZTF,1), a2=iAD(Symbol(),ZTF,1+AdBars), p1=iClose(Symbol(),ZTF,1), p2=iClose(Symbol(),ZTF,1+AdBars);
      if(ty==OP_SELL && a1>=a2){ return(false); } if(ty==OP_BUY && a1<=a2){ return(false); }
      if(AdMode==2){ if(ty==OP_SELL && p1<=p2){ return(false); } if(ty==OP_BUY && p1>=p2){ return(false); } } }
   if(FdMin>0 || FdMax>0){ double fd=KatzFd(); if(fd<FdMin || (FdMax>0 && fd>FdMax)){ return(false); } }
   if(LyapMax>0 && LyapNow()>LyapMax){ return(false); }
   if(HourFrom>=0){ int hh=TimeHour(TimeCurrent()); bool okh=(HourFrom<=HourTo)?(hh>=HourFrom && hh<=HourTo):(hh>=HourFrom || hh<=HourTo); if(!okh){ return(false); } }
   if(AcMax>0){ double s0=0,s1=0; for(int k=1;k<=60;k++){ double r0=iClose(Symbol(),ZTF,k)-iClose(Symbol(),ZTF,k+1), r1=iClose(Symbol(),ZTF,k+1)-iClose(Symbol(),ZTF,k+2); s0+=r0*r1; s1+=r0*r0; } if(s1>0 && s0/s1>AcMax){ return(false); } }
   if(AbsVolMin>0){ double sv2=0; for(int k=2;k<=21;k++){ sv2+=(double)iVolume(Symbol(),ZTF,k); } double av2=sv2/20, at2=iATR(Symbol(),ZTF,14,1), rg=iHigh(Symbol(),ZTF,1)-iLow(Symbol(),ZTF,1);
      if(av2<=0 || at2<=0 || (double)iVolume(Symbol(),ZTF,1)<AbsVolMin*av2 || rg>AbsRangeMax*at2){ return(false); } }
   if(TurnConfirm){ double za=ZPriceAt(1), zb=ZPriceAt(2); if(ty==OP_SELL && !(zb>za)){ return(false); } if(ty==OP_BUY && !(zb<za)){ return(false); } }
   if(CycleMode==1 && !CycleOk(ty)){ return(false); }
   if(VarRegimeMode>0 && !VarRegimeOk()){ return(false); }
   if(OuHalfMax>0){ double hl=OuHalfLife(); if(hl<OuHalfMin || hl>OuHalfMax){ return(false); } }
   if(FibMode==1 && !FibOk(ty)){ return(false); }
   return(true); }
int CrossSignal(){
   datetime ct=iTime(Symbol(),CrossTF,0); if(ct==lastCross){ return(-1); }
   double f1=iMA(Symbol(),CrossTF,CrossFast,0,MODE_SMA,PRICE_CLOSE,1), f2=iMA(Symbol(),CrossTF,CrossFast,0,MODE_SMA,PRICE_CLOSE,2);
   double s1=iMA(Symbol(),CrossTF,CrossSlow,0,MODE_SMA,PRICE_CLOSE,1), s2=iMA(Symbol(),CrossTF,CrossSlow,0,MODE_SMA,PRICE_CLOSE,2);
   if(f2<=s2 && f1>s1){ lastCross=ct; return(OP_BUY); }
   if(f2>=s2 && f1<s1){ lastCross=ct; return(OP_SELL); }
   return(-1); }

double ZPriceAt(int sh){ int n=MathMax(3,ZPeriod); double s=0,q=0; for(int k=sh;k<sh+n;k++){ double c=iClose(Symbol(),ZTF,k); s+=c; q+=c*c; } double m=s/n, sd=MathSqrt(MathMax(0,q/n-m*m)); if(sd<=0){ return(0); } return((iClose(Symbol(),ZTF,sh)-m)/sd); }
int BarsSinceLoss(){ datetime lt=0; double lp=0; for(int i=OrdersHistoryTotal()-1;i>=0;i--){ if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY) || OrderMagicNumber()!=MagicNumber || OrderSymbol()!=Symbol() || OrderType()>OP_SELL){ continue; } if(OrderCloseTime()>lt){ lt=OrderCloseTime(); lp=OrderProfit()+OrderSwap()+OrderCommission(); } }
   if(lt==0 || lp>=0){ return(9999); } return((int)((TimeCurrent()-lt)/(ZTF*60))); }
int ConfScore(int ty){ int sc=0; double m1,s1,m2,s2;
   if(MathAbs(SmaSlope(20,1)-SmaSlope(50,1))<MathAbs(SmaSlope(20,2)-SmaSlope(50,2))){ sc++; }
   SlopeStack(1,m1,s1); SlopeStack(2,m2,s2); if(s1<s2){ sc++; }
   double r=SsrNow(); if(r!=EMPTY_VALUE && r>=0.2 && r<=5){ sc++; }
   if(ErNow()<=0.25){ sc++; }
   if(RvolNow()<=45.6){ sc++; }
   if(HurstNow()<=0.5){ sc++; }
   double sv=0; for(int k=2;k<=21;k++){ sv+=(double)iVolume(Symbol(),ZTF,k); } if(sv>0 && (double)iVolume(Symbol(),ZTF,1)<=1.5*sv/20){ sc++; }
   return(sc); }

double OpenLots(int magic){ double s=0; for(int i=OrdersTotal()-1;i>=0;i--){ if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES) || OrderSymbol()!=Symbol() || OrderType()>OP_SELL){ continue; } if(magic<0 ? (OrderMagicNumber()==MagicNumber || OrderMagicNumber()==MagicNumber+1) : OrderMagicNumber()==magic){ s+=OrderLots(); } } return(s); }
void ManageHedge(){
   if(HedgeTriggerPts<=0){ return; }
   int mainCnt=0, hedgeCnt=0, mainType=-1; double fl=0, mainLots=0;
   for(int i=OrdersTotal()-1;i>=0;i--){ if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES) || OrderSymbol()!=Symbol() || OrderType()>OP_SELL){ continue; }
      if(OrderMagicNumber()==MagicNumber){ mainCnt++; mainType=OrderType(); mainLots+=OrderLots(); fl+=(OrderType()==OP_SELL)?(OrderOpenPrice()-Ask)/Point:(Bid-OrderOpenPrice())/Point; }
      else if(OrderMagicNumber()==MagicNumber+1){ hedgeCnt++; } }
   if(mainCnt==0){ for(int j=OrdersTotal()-1;j>=0;j--){ if(OrderSelect(j,SELECT_BY_POS,MODE_TRADES) && OrderSymbol()==Symbol() && OrderMagicNumber()==MagicNumber+1 && OrderType()<=OP_SELL){ RefreshRates(); double pc=(OrderType()==OP_BUY)?Bid:Ask; if(!OrderClose(OrderTicket(),OrderLots(),NormalizeDouble(pc,Digits),20,clrNONE)){ Print("hedge close err ",GetLastError()); } } } return; }
   if(hedgeCnt>0 || fl/mainCnt>-HedgeTriggerPts){ return; }
   double stp=MarketInfo(Symbol(),MODE_LOTSTEP); if(stp<=0){ stp=0.01; } double hl=mainLots*HedgeRatio;
   if(TotalLotCap>0){ hl=MathMin(hl,TotalLotCap*HedgeBudgetPct/100.0); hl=MathMin(hl,TotalLotCap-OpenLots(-1)); }
   hl=MathFloor(hl/stp)*stp; if(hl<MarketInfo(Symbol(),MODE_MINLOT)){ return; }
   int ht=(mainType==OP_SELL)?OP_BUY:OP_SELL; RefreshRates(); double hp=(ht==OP_BUY)?Ask:Bid, hsl=0, htp=0;
   if(HedgeSLPts>0){ hsl=(ht==OP_BUY)?hp-HedgeSLPts*Point:hp+HedgeSLPts*Point; } if(HedgeTPPts>0){ htp=(ht==OP_BUY)?hp+HedgeTPPts*Point:hp-HedgeTPPts*Point; }
   if(OrderSend(Symbol(),ht,NormalizeDouble(hl,2),NormalizeDouble(hp,Digits),20,NormalizeDouble(hsl,Digits),NormalizeDouble(htp,Digits),"b60h",MagicNumber+1,0,clrNONE)<0){ Print("hedge err ",GetLastError()); } }

double OuHalfLife(){ int n=MathMax(30,OuBars); double sx=0,sy=0,sxy=0,sxx=0;   // regress dx(t) = a + b*x(t-1) over n closes, half-life = -ln2/ln(1+b)
   for(int k=1;k<=n;k++){ double xp=iClose(Symbol(),ZTF,k+1)/Point, xc=iClose(Symbol(),ZTF,k)/Point; double dx=xc-xp; sx+=xp; sy+=dx; sxy+=xp*dx; sxx+=xp*xp; }
   double den=n*sxx-sx*sx; if(den==0){ return(9999); } double b=(n*sxy-sx*sy)/den; if(b>=0 || b<=-1.0){ return(9999); } return(-MathLog(2.0)/MathLog(1.0+b)); }

bool g_off=false, g_dayStop=false; datetime g_lastNote=0, g_lastHb=0, g_lastScan=0, g_mailDay=0; double g_dayEq=0; int g_dayNo=-1, g_ddTicket=0;
void Notify(string subj,string body){
   if(IsTesting()){ return; } if(!NotifyMail && !NotifyPush){ return; }
   if(TimeCurrent()-g_lastNote<NotifyMinGapSec){ return; } g_lastNote=TimeCurrent();
   if(NotifyPush){ SendNotification(StringSubstr(subj+": "+body,0,255)); }
   if(NotifyMail){ SendMail(subj,body); } }
void NotifyEntry(int ty,double l,double p,double s,double t){ Notify("EA entry",Symbol()+(ty==OP_BUY?" BUY ":" SELL ")+DoubleToStr(l,2)+" lots @"+DoubleToStr(p,Digits)+" SL "+DoubleToStr(s,Digits)+" TP "+DoubleToStr(t,Digits)); }
void CloseAllEa(){ for(int i=OrdersTotal()-1;i>=0;i--){ if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES) || OrderSymbol()!=Symbol() || OrderType()>OP_SELL){ continue; } if(OrderMagicNumber()!=MagicNumber && OrderMagicNumber()!=MagicNumber+1){ continue; }
      RefreshRates(); double px=(OrderType()==OP_BUY)?Bid:Ask; if(!OrderClose(OrderTicket(),OrderLots(),NormalizeDouble(px,Digits),20,clrNONE)){ Print("close all err ",GetLastError()); } } }
void ReadControl(){
   if(!UseControlFile){ g_off=false; return; }
   int h=FileOpen(ControlFileName,FILE_READ|FILE_TXT|FILE_COMMON|FILE_SHARE_READ); if(h<0){ g_off=false; return; }
   bool off=false; while(!FileIsEnding(h)){ string s=FileReadString(h); StringTrimLeft(s); StringTrimRight(s); StringToUpper(s); if(s=="DISABLE=1"){ off=true; } } FileClose(h);
   if(off && !g_off){ Notify("EA remote disable","new entries blocked by the control file"); if(CloseAllOnDisable){ CloseAllEa(); } }
   g_off=off; }
void HouseKeeping(){
   ReadControl();
   if(g_dayNo!=TimeDay(TimeCurrent())){ g_dayNo=TimeDay(TimeCurrent()); g_dayEq=AccountEquity(); g_dayStop=false; }
   if(DailyLossStopPct>0 && !g_dayStop && AccountEquity()<=g_dayEq*(1.0-DailyLossStopPct/100.0)){ g_dayStop=true; Notify("EA daily loss stop","equity "+DoubleToStr(AccountEquity(),2)+" is "+DoubleToStr(DailyLossStopPct,1)+"% below the day start: no new entries today"); }
   if((NotifyMail||NotifyPush) && !IsTesting()){
      for(int i=OrdersHistoryTotal()-1;i>=0;i--){ if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY) || OrderSymbol()!=Symbol() || OrderType()>OP_SELL){ continue; } if(OrderMagicNumber()!=MagicNumber && OrderMagicNumber()!=MagicNumber+1){ continue; }
         if(OrderCloseTime()>g_lastScan){ Notify("EA closed",Symbol()+" "+DoubleToStr(OrderLots(),2)+" lots profit "+DoubleToStr(OrderProfit()+OrderSwap()+OrderCommission(),2)); } }
      g_lastScan=TimeCurrent();
      if(DDAlertPts>0){ for(int j=OrdersTotal()-1;j>=0;j--){ if(!OrderSelect(j,SELECT_BY_POS,MODE_TRADES) || OrderSymbol()!=Symbol() || OrderType()>OP_SELL){ continue; } if(OrderMagicNumber()!=MagicNumber && OrderMagicNumber()!=MagicNumber+1){ continue; }
            double fl=(OrderType()==OP_SELL)?(OrderOpenPrice()-Ask)/Point:(Bid-OrderOpenPrice())/Point; if(fl<=-DDAlertPts && OrderTicket()!=g_ddTicket){ g_ddTicket=OrderTicket(); Notify("EA drawdown alert",Symbol()+" trade floating "+DoubleToStr(fl,0)+" pts"); } } }
      if(DailyMailHour>=0 && TimeHour(TimeCurrent())==DailyMailHour && g_mailDay!=iTime(Symbol(),PERIOD_D1,0)){ g_mailDay=iTime(Symbol(),PERIOD_D1,0); Notify("EA daily summary","balance "+DoubleToStr(AccountBalance(),2)+" equity "+DoubleToStr(AccountEquity(),2)+" open lots "+DoubleToStr(OpenLots(-1),2)+(g_off?" DISABLED":"")); } }
   if(HeartbeatMin>0 && TimeCurrent()-g_lastHb>=HeartbeatMin*60 && !IsTesting()){ int hb=FileOpen("ea_heartbeat_"+IntegerToString(MagicNumber)+".csv",FILE_READ|FILE_WRITE|FILE_CSV|FILE_COMMON|FILE_SHARE_READ,',');
      if(hb>=0){ FileSeek(hb,0,SEEK_END); FileWrite(hb,TimeToStr(TimeCurrent(),TIME_DATE|TIME_SECONDS),DoubleToStr(AccountEquity(),2),DoubleToStr(AccountBalance(),2),DoubleToStr(OpenLots(-1),2),g_off?1:0,g_dayStop?1:0); FileClose(hb); } g_lastHb=TimeCurrent(); } }
bool EntriesBlocked(){ return(g_off || g_dayStop); }

int OnInit(){ g_lastScan=TimeCurrent(); return(INIT_SUCCEEDED); }

void OnTick(){
   if(iBars(Symbol(),PERIOD_H1)<RegimePeriod+10){ return; }
   TimeExit(); TrailStops(); ManageHedge();
   datetime bt=iTime(Symbol(),ZTF,0); if(bt==lastBar){ return; } lastBar=bt; HouseKeeping();   // evaluate once per new bar
   if(CountOpen()>0){ return; }
   if(CooldownBars>0 && BarsSinceLoss()<CooldownBars){ return; }
   if(EntriesBlocked()){ return; }
   if(MarketInfo(Symbol(),MODE_SPREAD)>MaxSpreadPts){ return; }
   if(BlockRollover){ int h=TimeHour(TimeCurrent()); bool inr=(RollFrom<=RollTo)?(h>=RollFrom && h<=RollTo):(h>=RollFrom || h<=RollTo); if(inr){ return; } }
   if(AtrCapPts>0 && iATR(Symbol(),PERIOD_M15,14,1)/Point>AtrCapPts){ return; }
   if(UseMmrGate){ double mm=MmrNow(); if(mm==EMPTY_VALUE || mm<MmrMin || mm>MmrMax){ return; } }
   if(CalmRvolMax>0 && RvolNow()>CalmRvolMax){ return; }
   if(CalmPEMax>0 && PermEntropyNow()>CalmPEMax){ return; }
   double z=ZScore(); bool below=true, above=true;
   if(UseRegime){ double ma=iMA(Symbol(),PERIOD_H1,RegimePeriod,0,MODE_SMA,PRICE_CLOSE,1), c1=iClose(Symbol(),PERIOD_H1,1); below=(c1<ma); above=(c1>ma); }
   int ty=-1;
   double trig=ZTrigger;
   if(QuietRvolMax>0 && RvolNow()<=QuietRvolMax){ trig=QuietZTrigger; }
   if(VolSpikeRatio>0){ double a100=iATR(Symbol(),PERIOD_M15,100,1); if(a100>0 && iATR(Symbol(),PERIOD_M15,14,1)/a100>=VolSpikeRatio){ trig=VolRevZTrigger; } }
   if(EntryMode!=1){
      if(z>=trig && SideMode!=2 && below){ ty=OP_SELL; }
      if(z<=-trig && SideMode!=1 && above){ ty=OP_BUY; }
      if(ty>=0 && !GatesPass(ty)){ ty=-1; } }
   if(ty<0 && EntryMode>=1){ int cs=CrossSignal(); if(cs==OP_SELL && SideMode!=2){ ty=OP_SELL; } if(cs==OP_BUY && SideMode!=1){ ty=OP_BUY; } if(ty>=0 && CrossUseGates && !GatesPass(ty)){ ty=-1; } }
   if(ty<0){ return; }
   if(ty==OP_BUY && BuyUpConv){ double bf=SmaSlope(SsrFast,1), bs=SmaSlope(SsrSlow,1);
      if(bf<BuyMinSlope || bs<=0){ return; } double br=bf/bs; if(br<SsrMin || br>SsrMax){ return; } }   // buys only on strong rising SMA slopes that are converged
   if(ty==OP_BUY && BearBuyBlock){ double mb=iMA(Symbol(),PERIOD_H1,RegimePeriod,0,MODE_SMA,PRICE_CLOSE,1), mp=iMA(Symbol(),PERIOD_H1,RegimePeriod,0,MODE_SMA,PRICE_CLOSE,1+BearSlopeBars);
      if(iClose(Symbol(),PERIOD_H1,1)<mb || mb<mp){ return; } }   // bear market: price below the regime SMA or the regime SMA is falling, so never buy
   RefreshRates(); double pr=(ty==OP_SELL)?Bid:Ask, sl=0, tp=0;
   double slp=SLPts; if(AtrSLMult>0){ slp=AtrSLMult*iATR(Symbol(),PERIOD_M15,14,1)/Point; }
   if(slp>0){ sl=(ty==OP_SELL)?pr+slp*Point:pr-slp*Point; }
   if(AtrTPMult>0){ double tpd=AtrTPMult*iATR(Symbol(),PERIOD_M15,14,1); tp=(ty==OP_SELL)?pr-tpd:pr+tpd; }
   if(TPPts>0){ tp=(ty==OP_SELL)?pr-TPPts*Point:pr+TPPts*Point; }
   double lt=Lots;
   if(ConfMode==1){ lt=MathMin(Lots*(1.0+ConfStep*ConfScore(ty)),Lots*ConfMaxMult); }
   if(LotVolRefAtr>0){ double aa=iATR(Symbol(),PERIOD_M15,14,1)/Point; if(aa>LotVolRefAtr){ lt=lt*LotVolRefAtr/aa; } }
   if(ConfMode==1 && ConfMarginPct>0){ double mrq=MarketInfo(Symbol(),MODE_MARGINREQUIRED); if(mrq>0){ double maxl=AccountFreeMargin()*ConfMarginPct/100.0/mrq; if(lt>maxl){ lt=maxl; } } }
   if(ConfMode==1){ lt=MathMin(lt,ConfMaxLots); }
   double stp=MarketInfo(Symbol(),MODE_LOTSTEP); if(stp<=0){ stp=0.01; } lt=MathFloor(lt/stp)*stp; lt=MathMax(MarketInfo(Symbol(),MODE_MINLOT),NormalizeDouble(lt,2));
   if(TotalLotCap>0){ double mcap=(HedgeTriggerPts>0)?TotalLotCap*(1.0-HedgeBudgetPct/100.0):TotalLotCap; lt=MathMin(lt,mcap-OpenLots(MagicNumber)); lt=MathMin(lt,TotalLotCap-OpenLots(-1)); lt=MathFloor(lt/stp)*stp; if(lt<MarketInfo(Symbol(),MODE_MINLOT)){ return; } }   // shared budget across main, split and hedge
   if(SplitMode==1 && SplitTPPts>0){ double ha=MathFloor(lt/2.0/stp)*stp; if(ha>=MarketInfo(Symbol(),MODE_MINLOT) && lt-ha>=MarketInfo(Symbol(),MODE_MINLOT)){
      double tpa=(ty==OP_SELL)?pr-SplitTPPts*Point:pr+SplitTPPts*Point; int ta=OrderSend(Symbol(),ty,NormalizeDouble(ha,2),NormalizeDouble(pr,Digits),20,NormalizeDouble(sl,Digits),NormalizeDouble(tpa,Digits),"b60a",MagicNumber,0,clrNONE); if(ta<0){ Print("split err ",GetLastError()); } lt=lt-ha; } }
   int t=OrderSend(Symbol(),ty,lt,NormalizeDouble(pr,Digits),20,NormalizeDouble(sl,Digits),NormalizeDouble(tp,Digits),"b62",MagicNumber,0,clrNONE);
   if(t<0){ Print("OrderSend err ",GetLastError()); } else { NotifyEntry(ty,lt,pr,sl,tp); } }

