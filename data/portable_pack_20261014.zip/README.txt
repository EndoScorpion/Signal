Portable pack. 1) Copy the .mq4/.ex4 into MQL4\Experts of an MT4 terminal and the .set files to a folder you load from the EA Inputs dialog (Load).
2) The clean history is FXOpen M1 bid with server clock UTC+2/+3; use the same data for comparable tests.
3) Everything is a BACKTEST lead; nothing here is approved for live trading. Remote disable: EAs b62+ with UseControlFile=true read ea_control.txt (DISABLE=1) from the common files folder.
4) Costs: commission max 5 pts per round trip plus average spread; check cost flags in manifest.json.
